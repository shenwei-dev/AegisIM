package com.family.chat.controller;

import com.family.chat.common.result.ApiResponse;
import com.family.chat.dto.QueryFriendRequestListDTO;
import com.family.chat.request.FriendApplyRequest;
import com.family.chat.service.FriendRequestService;
import com.family.chat.vo.FriendRequestVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/friend_request")
public class FriendRequestController {

    @Autowired
    private FriendRequestService friendRequestService;

    @PostMapping("/send")
    public ApiResponse<Void> sendFriendRequest(@RequestBody FriendApplyRequest friendApplyRequest) {
        friendRequestService.transmitFriendRequest(friendApplyRequest);
        return ApiResponse.success();
    }

    @GetMapping("/list")
    public ApiResponse<List<FriendRequestVO>> getFriendRequestList() {
        return ApiResponse.success(friendRequestService.getFriendRequestList());
    }

    @PostMapping("/accept/{id}")
    public ApiResponse<Void> acceptFriendRequest(@PathVariable("id") Long id) {
        friendRequestService.acceptFriendRequest(id);
        return ApiResponse.success();
    }
}
