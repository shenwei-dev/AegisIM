package com.family.chat.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import java.util.concurrent.Executor;

@Configuration
public class ThreadPoolConfig {

    /**
     * 构建专门用于大模型（LLM）对话网络 IO 的异步执行器
     */
    @Bean(name = "aiExecutor")
    public Executor aiExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(10);             // 核心线程数：10
        executor.setMaxPoolSize(20);              // 最大线程数：20
        executor.setQueueCapacity(100);           // 队列容量：100
        executor.setThreadNamePrefix("AI-Thread-"); // 线程名前缀，便于排查日志
        // 👈 【核心修改点】：注入我们写好的 MDC 任务装饰器，打通大模型异步线程的 TraceId 追踪！
        executor.setTaskDecorator(new MdcTaskDecorator());
        executor.initialize();
        return executor;
    }
}