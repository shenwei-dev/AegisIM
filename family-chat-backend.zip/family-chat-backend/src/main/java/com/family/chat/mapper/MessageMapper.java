package com.family.chat.mapper;

import com.family.chat.entity.Message;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface MessageMapper {

    @Insert("""
    INSERT INTO im_message
    (id, from_user_id, to_user_id, content, sequence, message_type, status, created_at, updated_at)
    VALUES
    (#{id}, #{fromUserId}, #{toUserId}, #{content}, #{sequence}, #{messageType}, #{status}, #{createdAt}, #{updatedAt})
""")
    int insert(Message message);

    @Update("""
    UPDATE im_message
    SET status = #{status},
        updated_at = #{updatedAt}
    WHERE id = #{id}
""")
    int updateStatus(@Param("id") Long id,
                     @Param("status") Integer status,
                     @Param("updatedAt") Long updatedAt);

    @Select("""
    SELECT * FROM im_message
    WHERE to_user_id = #{toUserId}
    AND status = 0
    ORDER BY created_at ASC
""")
    List<Message> selectUnread(@Param("toUserId") Long toUserId);

    @Select("""
        SELECT COUNT(*) 
        FROM im_message
        WHERE to_user_id = #{toUserId}
          AND status = 0
    """)
    int countUnread(@Param("toUserId") Long toUserId);

    /**
     * 【大厂级区间查询】：根据高水位线，向后查询最新的增量消息，用于客户端自愈
     */
    @Select("""
        SELECT * FROM im_message WHERE (
            (from_user_id = #{userId} AND to_user_id = #{friendId}) 
            OR 
            (from_user_id = #{friendId} AND to_user_id = #{userId})
        )
        AND sequence > #{localMaxSeq}
        ORDER BY sequence ASC LIMIT 100
    """)
    List<Message> selectDeltaMessages(@Param("userId") Long userId,
                                      @Param("friendId") Long friendId,
                                      @Param("localMaxSeq") Long localMaxSeq);

    /**
     * 【RAG 记忆体查询】：查询双方最近的 5 条聊天记录，并在外层将其按时间升序（正序）排列，完美对准大模型上下文规范
     */
    @Select("""
        SELECT * FROM (
            SELECT * FROM im_message 
            WHERE (
                (from_user_id = #{userId} AND to_user_id = #{friendId}) 
                OR 
                (from_user_id = #{friendId} AND to_user_id = #{userId})
            )
            ORDER BY created_at DESC LIMIT #{limit}
        ) AS temp_table 
        ORDER BY created_at ASC
    """)
    List<Message> selectRecentHistory(@Param("userId") Long userId,
                                      @Param("friendId") Long friendId,
                                      @Param("limit") int limit);

    // 在 MessageMapper.java 中增加：
    @Delete("""
        DELETE FROM im_message 
        WHERE (from_user_id = #{userId} AND to_user_id = #{friendId}) 
        OR (from_user_id = #{friendId} AND to_user_id = #{userId})
    """)
    void deleteChatHistory(@Param("userId") Long userId, @Param("friendId") Long friendId);
}
