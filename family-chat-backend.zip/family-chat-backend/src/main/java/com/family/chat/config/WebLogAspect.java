package com.family.chat.config;

import com.alibaba.fastjson.JSON;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import java.util.UUID;

@Aspect
@Component
public class WebLogAspect {

    private static final Logger log = LoggerFactory.getLogger(WebLogAspect.class);

    // 拦截 com.family.chat.controller 包及其子包下的所有控制层方法
    @Pointcut("execution(* com.family.chat.controller..*.*(..))")
    public void webLog() {}

    @Around("webLog()")
    public Object doAround(ProceedingJoinPoint joinPoint) throws Throwable {
        long startTime = System.currentTimeMillis();

        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = attributes != null ? attributes.getRequest() : null;

        String url = request != null ? request.getRequestURL().toString() : "Unknown";
        String method = request != null ? request.getMethod() : "Unknown";
        String ip = request != null ? request.getRemoteAddr() : "Unknown";
        Object[] logArgs = filterArgs(joinPoint.getArgs());
        // 👈 微信级英文规范：入站 HTTP 请求统一审计
        log.info("[HTTP REQUEST] [url={}] [method={}] [client_ip={}] [class_method={}.{}] [args={}]",
                url, method, ip,
                joinPoint.getSignature().getDeclaringTypeName(),
                joinPoint.getSignature().getName(),
                JSON.toJSONString(logArgs));

        Object result;
        try {
            // 执行真实的业务方法
            result = joinPoint.proceed();

            // 2. 👈 【核心重构】：只有当业务方法成功（没有抛出异常）时，才在这里打印 [HTTP RESPONSE] 成功日志
            long endTime = System.currentTimeMillis();
//            log.info("[HTTP RESPONSE] [elapsed_time={}ms] [payload={}]", (endTime - startTime), JSON.toJSONString(result));

            return result; // 返回执行结果

        } catch (Throwable t) {
            // 3. 👈 【核心重构】：如果业务方法发生任何报错/崩溃
            long endTime = System.currentTimeMillis();
            // 打印红色的 [HTTP EXCEPTION] 异常日志，并记录报错的类名和异常信息
//            log.error("[HTTP EXCEPTION] [elapsed_time={}ms] [exception_type={}] [exception_msg={}]",
//                    (endTime - startTime), t.getClass().getName(), t.getMessage());

            // 必须重新往外抛出！这样您的 Spring 全局异常处理器 (@RestControllerAdvice) 才能捕获它并返回标准的统一错误 JSON
            throw t;

        } finally {
            MDC.clear();
        }
    }

    /**
     * 👈 【核心新增】：参数安全过滤器
     * 作用：过滤掉 HttpServletRequest、HttpServletResponse 和 HttpSession 等无法被 JSON 序列化的底层容器对象
     */
    private Object[] filterArgs(Object[] args) {
        if (args == null) {
            return new Object[0];
        }
        Object[] filtered = new Object[args.length];
        for (int i = 0; i < args.length; i++) {
            if (args[i] instanceof HttpServletRequest ||
                    args[i] instanceof HttpServletResponse ||
                    args[i] instanceof HttpSession) {

                // 如果是无法序列化的 Servlet 对象，直接用其“简单类名”进行文本占位，防止 FastJSON 崩溃
                filtered[i] = args[i].getClass().getSimpleName();

            } else {
                filtered[i] = args[i];
            }
        }
        return filtered;
    }
}