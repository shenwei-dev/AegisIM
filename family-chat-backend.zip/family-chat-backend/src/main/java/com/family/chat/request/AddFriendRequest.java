package com.family.chat.request;

import lombok.*;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class AddFriendRequest {

    Long targetUserId;

    String targetMessage;
}
