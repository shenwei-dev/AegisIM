package com.family.chat.service;

import com.family.chat.entity.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
public class MessageConsumer {


    @RabbitListener(queues = "chat.queue")
    public void receive(Message message) {
        System.out.println(
                "收到消息:"
                        + message.getContent()
        );


    }

}