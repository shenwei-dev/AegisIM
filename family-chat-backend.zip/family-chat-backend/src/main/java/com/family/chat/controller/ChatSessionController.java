package com.family.chat.controller;

import com.family.chat.common.result.ApiResponse;
import com.family.chat.mapper.ChatSessionMapper;
import com.family.chat.mapper.MessageMapper;
import com.family.chat.service.ChatSessionService;
import com.family.chat.util.SecurityUtil;
import com.family.chat.vo.ChatSessionVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/chat/session")
public class ChatSessionController {

    @Autowired
    private ChatSessionService chatSessionService;

    @Autowired
    private ChatSessionMapper chatSessionMapper;

    @Autowired
    private MessageMapper messageMapper;

    /**
     * 拉取当前登录用户的所有活跃聊天会话（微信首屏数据源）
     */
    @GetMapping("/list")
    public ApiResponse<List<ChatSessionVO>> getRecentSessions() {
        // 从 Token 安全上下文中获取当前登录用户的真实 ID
        Long currentUserId = SecurityUtil.getCurrentUserId();
        List<ChatSessionVO> sessions = chatSessionService.getRecentSessions(currentUserId);
        return ApiResponse.success(sessions);
    }

    /**
     * 进入聊天窗口时调用：将对应的会话未读数清零 (HTTP POST)
     */
    @PostMapping("/clear-unread")
    public ApiResponse<Void> clearUnread(@RequestParam("friendId") Long friendId) {
        Long currentUserId = SecurityUtil.getCurrentUserId();
        chatSessionMapper.clearUnreadCount(currentUserId, friendId);
        return ApiResponse.success();
    }

    /**
     * 置顶或取消置顶该聊天
     */
    @PostMapping("/pin")
    public ApiResponse<Void> togglePin(@RequestParam("friendId") Long friendId, @RequestParam("isPinned") int isPinned) {
        Long currentUserId = SecurityUtil.getCurrentUserId();
        chatSessionMapper.updateSessionPinned(currentUserId, friendId, isPinned, System.currentTimeMillis());
        return ApiResponse.success(null);
    }

    /**
     * 不显示该聊天
     */
    @PostMapping("/hide")
    public ApiResponse<Void> hideSession(@RequestParam("friendId") Long friendId) {
        Long currentUserId = SecurityUtil.getCurrentUserId();
        chatSessionMapper.deleteSession(currentUserId, friendId);
        return ApiResponse.success(null);
    }

    /**
     * 接口三：删除该聊天 (删除首屏会话 + 物理清空云端 MySQL 消息明细)
     */
    @PostMapping("/delete")
    @Transactional(rollbackFor = Exception.class)
    public ApiResponse<Void> deleteSessionAndHistory(@RequestParam("friendId") Long friendId) {
        Long currentUserId = SecurityUtil.getCurrentUserId();
        chatSessionMapper.deleteSession(currentUserId, friendId);
        messageMapper.deleteChatHistory(currentUserId, friendId);
        return ApiResponse.success(null);
    }
}