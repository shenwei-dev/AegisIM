package com.family.chat.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.family.chat.dto.MessageDTO;
import com.family.chat.entity.ChatSession;
import com.family.chat.entity.Message;
import com.family.chat.mapper.ChatSessionMapper;
import com.family.chat.mapper.FriendRequestMapper;
import com.family.chat.mapper.MessageMapper;
import com.family.chat.netty.SessionManager;
import com.family.chat.protobuf.MessageProto;
import com.family.chat.service.MessageService;
import com.family.chat.util.UserIdentifierGenerator;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import io.netty.handler.codec.http.websocketx.BinaryWebSocketFrame;
import io.netty.handler.codec.http.websocketx.TextWebSocketFrame;
import lombok.RequiredArgsConstructor;
import okhttp3.*;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;
import com.alibaba.fastjson.JSON;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.Executor;
import com.alibaba.fastjson.JSONArray;

@Service
@RequiredArgsConstructor
public class MessageServiceImpl implements MessageService {

    private static final Logger log = LoggerFactory.getLogger(MessageServiceImpl.class);

    private final StringRedisTemplate stringRedisTemplate;

    private final RabbitTemplate rabbitTemplate;

    private final MessageMapper messageMapper;

    private final SessionManager sessionManager;

    private final FriendRequestMapper friendRequestMapper;

    private final ChatSessionMapper chatSessionMapper;

    private final OkHttpClient okHttpClient;

    private final RedissonClient redissonClient;

    private static final Long AI_ASSISTANT_ID = 99999L;


    // ==================== 【大模型动态可插拔注入】 ====================
    @Value("${ai.model}")
    private String aiModel;

    @Value("${ai.api-key}")
    private String aiApiKey;

    @Value("${ai.base-url}")
    private String aiBaseUrl;

    @Autowired
    private Executor aiExecutor;

    @Override
    public void handleWebSocketMessage(MessageDTO messageRequest, Channel clientChannel) {
        int optionCode = messageRequest.getType() != null ? messageRequest.getType() : 0;
        Long realUserId = messageRequest.getSenderId();
        switch (optionCode) {
            case 0:
                // 👈 【操作码 0】：普通人对人文本消息，直接由专属文本方法处理（内部包含会话未读数维护）
                processNormalTextMessage(messageRequest, clientChannel);
                break;

            case 1:
                // 👈 【操作码 1】：语音通话呼叫邀请
                processVoiceCallInvite(messageRequest, clientChannel);
                break;

            case 2:
                // 👈 【操作码 2】：接受语音通话
                processVoiceCallAccept(messageRequest, clientChannel);
                break;

            case 3:
                // 👈 【操作码 3】：挂断电话（或拒绝邀请）
                processCallHangup(messageRequest, clientChannel);
                break;

            case 4:
                // 👈 【操作码 4】：视频通话呼叫邀请
                processVideoCallInvite(messageRequest, clientChannel);
                break;

            case 5:
                // 👈 【操作码 5】：接受视频通话
                processVideoCallAccept(messageRequest, clientChannel);
                break;

            case 8:
                // 👈 【操作码 8】：AI 智能体/大模型对话专属操作码
                //processBasicAiChat(messageRequest, clientChannel);
                processAiAgentMessage(messageRequest, clientChannel);
                break;

            case 99:
                // 【操作码 99】：收到客户端的心跳 Ping。
                // 💡 提示：这里我们不需要写任何回复，因为只要网络通道里产生了字节传输，
                // Netty 的 IdleStateHandler 就会自动将该通道的“读空闲时间”重置归零！
                log.info("【心跳盘点】收到用户 [{}] 的心跳 Ping", realUserId);
                break;

            default:
                log.warn(">>>> 【网关警告】收到未定义的操作码 (Unknown optionCode): {}", optionCode);
                clientChannel.writeAndFlush(new TextWebSocketFrame("{\"status\":\"error\",\"message\":\"未知操作码\"}"));
                break;
        }
    }

    @Override
    public void pushOfflineFriendRequests(Long userId, Channel channel) {
        try {
            int unreadCount = friendRequestMapper.selectUnreadCount(userId);
            if (unreadCount > 0) {
                JSONObject pushData = new JSONObject();
                pushData.put("type", 6);
                pushData.put("content", "您有未处理的好友申请");
                pushData.put("unreadCount", unreadCount);
                channel.writeAndFlush(new TextWebSocketFrame(JSON.toJSONString(pushData)));
                log.info(">>>> 【离线红点补发】检测到用户 [{}] 刚刚上线，且有 {} 条未处理申请，开始补推红点...",
                        userId, unreadCount);
            }
        } catch (Exception e) {
            log.error("离线好友申请红点补发失败", e);
        }
    }

    @Override
    public List<Message> getDeltaMessages(Long currentUserId, Long friendId, Long localMaxSeq) {
        return messageMapper.selectDeltaMessages(currentUserId, friendId, localMaxSeq);
    }

    private void updateSenderChatSession(Long userId, Long friendId, String content, Long timestamp) {
        // 步骤一：首先无锁尝试 UPDATE 现有行（读写分离，大部分情况下此更新会成功，无需走锁开销）
        int affectedRows = chatSessionMapper.updateSenderSession(userId, friendId, content, timestamp);


//        // 2. 如果影响行数为 0，说明数据库中从来没有创建过与该联系人（或 AI 助手）的会话，立即执行自动初始化插入！
//        if (affectedRows == 0) {
//            log.info(">>>> 发现用户 [{}] 与联系人 [{}] 的首屏会话不存在，开始自动创建...", userId, friendId);
//
//            ChatSession session = new ChatSession();
//            session.setId(UserIdentifierGenerator.nextId()); // 生成会话雪花ID
//            session.setUserId(userId);
//            session.setFriendId(friendId);
//            session.setLastMessage(content);
//            session.setUnreadCount(0); // 发送方自己的未读数初始化为 0
//            session.setUpdatedAt(timestamp);
//
//            try {
//                chatSessionMapper.insert(session);
//                log.info(">>>> 成功为用户 [{}] 初始化创建了与 [{}] 的首屏会话！", userId, friendId);
//            } catch (Exception e) {
//                // 并发安全防护：如果是由于主键/唯一键冲突导致插入失败，重新执行一次更新即可
//                chatSessionMapper.updateSenderSession(userId, friendId, content, timestamp);
//            }
//        }

        // 步骤二：如果影响行数为 0，说明数据库里确实没有这条会话，开始准备【加锁安全创建】
        if (affectedRows == 0) {

            // 计算双方之间物理唯一的分布式锁 Key
            long minId = Math.min(userId, friendId);
            long maxId = Math.max(userId, friendId);
            String lockKey = "lock:session:" + minId + "_" + maxId; //

            // 获取 Redisson 锁
            RLock lock = redissonClient.getLock(lockKey);

            try {
                // 尝试获取分布式锁，最多等待 5 秒，获取成功后 10 秒自动释放（防止发生线程死锁挂死）
                if (lock.tryLock(5, 10, java.util.concurrent.TimeUnit.SECONDS)) {

                    // 👈 【核心亮点：Double-Check 双重检查】
                    // 必须再次尝试更新一次！因为在当前线程排队等待锁的这 1-2 秒期间，另一个抢到锁的线程可能已经把数据 INSERT 好了！
                    int doubleCheckRows = chatSessionMapper.updateSenderSession(userId, friendId, content, timestamp);

                    if (doubleCheckRows == 0) {
                        // 确认还是没有，此时当前线程可以安全执行 INSERT，绝对不会报唯一键冲突或死锁！
                        ChatSession session = new ChatSession();
                        session.setId(UserIdentifierGenerator.nextId());
                        session.setUserId(userId);
                        session.setFriendId(friendId);
                        session.setLastMessage(content);
                        session.setUnreadCount(0);
                        session.setUpdatedAt(timestamp);

                        chatSessionMapper.insert(session);
                        log.info("【分布式锁】成功通过双重检查锁（DCL）安全创建了首屏会话 [lock_key={}]", lockKey);
                    }
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                log.error("获取分布式会话锁异常中断", e);
            } finally {
                // 👈 【核心细节】：在 finally 中，只有当前线程持有这把锁时，才执行安全释放
                if (lock.isHeldByCurrentThread()) {
                    lock.unlock();
                }
            }
        }
    }

    // 调用AI模型流
    private String callAiModelStream(Long aiMessageId, Long sequence, String userPrompt, Channel clientChannel) throws IOException {
        // 创建请求体对象
        JSONObject requestBody = new JSONObject();

        // 将 "AI模型名称" 放入请求体对象
        requestBody.put("model", aiModel);

        // 将 "true" 放入请求体对象, 表示开启流式（Stream）开关！
        requestBody.put("stream", true);

        JSONArray messages = new JSONArray();

        JSONObject systemRole = new JSONObject();
        systemRole.put("role", "system");
        systemRole.put("content", "你是一个FamilyChat中的智能助理，请简练回答。");
        messages.add(systemRole);

        JSONObject userMessage = new JSONObject();
        userMessage.put("role", "user");
        userMessage.put("content", userPrompt);
        messages.add(userMessage);

        requestBody.put("messages", messages);

        RequestBody body = RequestBody.create(
                MediaType.parse("application/json; charset=utf-8"),
                requestBody.toJSONString()
        );

        Request request = new Request.Builder()
                .url(aiBaseUrl)
                .header("Authorization", "Bearer " + aiApiKey)
                .post(body)
                .build();

        StringBuilder fullContent = new StringBuilder();

        // B. 发起请求，通过行读取器（Line Reader）实现流式字节流的边读边发
        try (Response response = okHttpClient.newCall(request).execute()) {
            // 如果请求正常
            if (response.isSuccessful() && response.body() != null) {

                // 包装成字符流读取器
                java.io.BufferedReader reader = new java.io.BufferedReader(response.body().charStream());
                String line;

                while ((line = reader.readLine()) != null) {
                    // 大模型的 SSE 流每行均以 "data:" 开头
                    if (line.startsWith("data:")) {
                        String dataText = line.substring(5).trim();

                        // 结束标志
                        if ("[DONE]".equals(dataText)) {
                            break;
                        }

                        try {
                            // 解析每一行的 Delta 碎片增量字符
                            JSONObject chunkJson = JSONObject.parseObject(dataText);
                            String chunkWord = chunkJson.getJSONArray("choices")
                                    .getJSONObject(0)
                                    .getJSONObject("delta")
                                    .getString("content");

                            // 如果当前行吐出了字符
                            if (chunkWord != null && !chunkWord.isEmpty()) {
                                fullContent.append(chunkWord); // 拼接整句话

                                // 👈 【Netty 物理直投】：包装成包含 isChunk = true 的 WebSocket 文本帧
//                                JSONObject pushObj = new JSONObject();
//                                pushObj.put("messageId", String.valueOf(aiMessageId)); // 使用相同的消息雪花ID
//                                pushObj.put("senderId", AI_ASSISTANT_ID);
//                                pushObj.put("content", chunkWord);                 // 吐出的单个字
//                                pushObj.put("isChunk", true);
//                                pushObj.put("sequence", true);
                                // 告诉前端：这是流式碎片，请执行追加！
                                MessageProto.MsgFrame pushObject = MessageProto.MsgFrame.newBuilder()
                                        .setMessageId(aiMessageId)
                                        .setSenderId(AI_ASSISTANT_ID)
                                        .setContent(chunkWord)
                                        .setIsChunk(true)
                                        .setIsSequence(true)
                                        .build();
                                byte[] pushObjectBytes = pushObject.toByteArray();
                                clientChannel.writeAndFlush(new BinaryWebSocketFrame(Unpooled.copiedBuffer(pushObjectBytes)));
                                log.info(">>>> aiMessageId" + aiMessageId + chunkWord);
//                                // 毫秒级直投回手机端
//                                clientChannel.writeAndFlush(new TextWebSocketFrame(pushObj.toJSONString()));
                            }
                        } catch (Exception e) {
                            // 忽略部分空行或解析噪音
                        }
                    }
                }
                reader.close();
            }
        }
        return fullContent.toString(); // 返回整句话用于持久化落库
    }

    /**
     * 获取当前会话在 Redis 中的唯一、原子、连续自增计数器
     */
    private Long getNextSequence(Long userA, Long userB) {
        long minId = Math.min(userA, userB);
        long maxId = Math.max(userA, userB);
        String redisKey = "chat:seq:" + minId + "_" + maxId;

        // 👈 使用 Redis 的 INCR 命令，保证多线程并发下依然绝对单调连续递增 (1, 2, 3...)
        return stringRedisTemplate.opsForValue().increment(redisKey);
    }

    /**
     * 【核心算法】：OpenAI 标准的 Function Calling 双轴路由协议
     */
    private String callAiAgentProtocol(Long myUserId, String userPrompt) throws IOException {

        // 1. 初始化消息历史
        com.alibaba.fastjson.JSONArray messages = new com.alibaba.fastjson.JSONArray();

        JSONObject systemRole = new JSONObject();
        systemRole.put("role", "system");
        systemRole.put("content", "你是一个FamilyChat系统中的智能管家。你拥有调用 Java 方法查询本地数据库的能力。");
        messages.add(systemRole);

        // ==================== 👈 【核心重构：为 Agent 注入历史对话记忆】 ====================
        // 从本地 MySQL 中，精准捞出当前用户与 AI 助手最近的 5 条历史聊天记录
        List<Message> historyList = messageMapper.selectRecentHistory(myUserId, AI_ASSISTANT_ID, 5);
        log.info(">>>> 【Agent 记忆装载】成功捞出与 AI 的最近 {} 条对话历史并注入智能体上下文...", historyList.size());
        for (Message history : historyList) {
            JSONObject historyMsg = new JSONObject();
            // 判定角色：如果是我发的，角色是 "user"；如果是 AI 助理（99999L）发的，角色是 "assistant"
            String role = history.getFromUserId().equals(myUserId) ? "user" : "assistant";

            historyMsg.put("role", role);
            historyMsg.put("content", history.getContent());
            messages.add(historyMsg); // 👈 依次注入历史，给智能体建立“短期记忆”！
        }
        // ==============================================================================

        JSONObject userMessage = new JSONObject();
        userMessage.put("role", "user");
        userMessage.put("content", userPrompt);
        messages.add(userMessage);

        // 2. 注入工具声明（告诉大模型你可以调用哪些方法）
        com.alibaba.fastjson.JSONArray tools = new com.alibaba.fastjson.JSONArray();
        JSONObject tool = new JSONObject();
        tool.put("type", "function");

        JSONObject function = new JSONObject();
        function.put("name", "queryUnreadFriendRequestsCount"); // 函数名称
        function.put("description", "用于查询当前用户在数据库中拥有的、尚未同意或拒绝的、待处理的好友申请总条数");

        JSONObject parameters = new JSONObject();
        parameters.put("type", "object");
        parameters.put("properties", new JSONObject()); // 无入参
        function.put("parameters", parameters);

        tool.put("function", function);
        tools.add(tool);

        // 3. 【第一轮调用】：携带 Tools 声明发送给大模型，询问它的意图
        JSONObject responseObj = postToLlm(messages, tools);

        if (responseObj != null && responseObj.containsKey("tool_calls")) {
            // 4. 大模型判定：确实需要调用我们本地的工具！
            com.alibaba.fastjson.JSONArray toolCalls = responseObj.getJSONArray("tool_calls");
            JSONObject firstToolCall = toolCalls.getJSONObject(0);
            String callId = firstToolCall.getString("id");
            String functionName = firstToolCall.getJSONObject("function").getString("name");

            log.info(">>>> 【Agent 触发】：大模型决定调用本地 Java 函数 [{}]", functionName);

            String javaResult = "";
            if ("queryUnreadFriendRequestsCount".equals(functionName)) {
                // 执行我们第一章写好的、对准 MySQL 的真实物理查询！
                int unreadCount = friendRequestMapper.selectUnreadCount(myUserId);
                javaResult = String.valueOf(unreadCount);
                log.info(">>>> 【Java 执行成功】：从数据库中查到当前用户有 {} 条未处理好友申请", javaResult);
            }

            // 👈 【核心修复一】：直接把第一轮大模型返回的、格式绝对完美的 responseObj 塞入历史记录
            // 这样能确保包含所有的必须字段（如 content: null），绝对不会被大模型网关 400 拒连！
            messages.add(responseObj);

            // 6. 将本地 Java 的真实执行结果（tool 角色）塞入历史记录，带上唯一 callId 对齐
            JSONObject toolMessage = new JSONObject();
            toolMessage.put("role", "tool");
            toolMessage.put("tool_call_id", callId);
            toolMessage.put("name", functionName);
            toolMessage.put("content", javaResult); // 将“3”反哺给大模型
            messages.add(toolMessage);


            // 第二轮请求：把装有【数据库真实数据】的上下文，再次丢给大模型
            log.info(">>>> 正在发起第二轮大模型请求，反哺真实数据...");
            JSONObject finalResponse = postToLlm(messages, null);
            if (finalResponse != null) {
                return finalResponse.getString("content");
            } else {
                log.error(">>>> 【Agent 严重异常】：第二轮大模型请求返回为 null！");
            }
        }

        // 兜底
        return responseObj != null && responseObj.getString("content") != null
                ? responseObj.getString("content")
                : "智能管家开小差了，请稍后再试。";
    }

    /**
     * 辅助请求工具类
     */
    private JSONObject postToLlm(com.alibaba.fastjson.JSONArray messages, com.alibaba.fastjson.JSONArray tools) throws IOException {
        JSONObject requestBody = new JSONObject();
        requestBody.put("model", aiModel);
        requestBody.put("messages", messages);
        if (tools != null) {
            requestBody.put("tools", tools);
        }

        RequestBody body = RequestBody.create(
                MediaType.parse("application/json; charset=utf-8"),
                requestBody.toJSONString()
        );

        Request request = new Request.Builder()
                .url(aiBaseUrl)
                .header("Authorization", "Bearer " + aiApiKey)
                .post(body)
                .build();

        try (Response response = okHttpClient.newCall(request).execute()) {
            if (response.isSuccessful() && response.body() != null) {
                String responseBody = response.body().string();
                JSONObject resultJson = JSONObject.parseObject(responseBody);
                return resultJson.getJSONArray("choices")
                        .getJSONObject(0)
                        .getJSONObject("message");
            }  else {
                // 👈 【核心修复二】：如果 HTTP 请求不成功，打印出大模型网关返回的真实错误 Body 信息
                String errorBody = response.body() != null ? response.body().string() : "无错误详情";
                log.error("❌【大模型网关报错】HTTP 状态码: {}, 错误详情: {}", response.code(), errorBody);
            }
        }
        return null;
    }


    /**
     * 【方案一】：处理基础版 AI 对话（纯大模型直连，打字机流式输出，不带函数调用）
     */
    private void processBasicAiChat(MessageDTO messageRequest, Channel clientChannel) {
        // 1. 【同步立即执行】：处理“我的提问”并落库
        Message userMessage = new Message();
        userMessage.setId(UserIdentifierGenerator.nextId());
        userMessage.setFromUserId(messageRequest.getSenderId()); // 发送者：我
        userMessage.setToUserId(AI_ASSISTANT_ID);               // 接收者：AI 99999L
        userMessage.setMessageType(messageRequest.getType());
        userMessage.setContent(messageRequest.getContent());     // 提问内容
        userMessage.setStatus(0);
        userMessage.setCreatedAt(System.currentTimeMillis());
        userMessage.setUpdatedAt(System.currentTimeMillis());

        Long seq = getNextSequence(userMessage.getFromUserId(), userMessage.getToUserId());
        userMessage.setSequence(seq);

        try {
            // 将我的提问存入数据库
            messageMapper.insert(userMessage);
            updateSenderChatSession(messageRequest.getSenderId(), AI_ASSISTANT_ID, messageRequest.getContent(), userMessage.getCreatedAt());
        } catch (Exception e) {
            log.error("保存我的提问消息失败", e);
            JSONObject failedAck = new JSONObject();
            failedAck.put("status", "failed");
            failedAck.put("tempId", messageRequest.getTempId());
            clientChannel.writeAndFlush(new TextWebSocketFrame(failedAck.toJSONString()));
            return;
        }

        // 2. 落库成功，【立刻】回传成功 ACK 给我的手机（让我的绿色气泡瞬间停止转圈）
        log.info("tempId", messageRequest.getTempId());

        JSONObject successAck = new JSONObject();
        successAck.put("status", "success");
        successAck.put("tempId", messageRequest.getTempId());
        successAck.put("messageId", String.valueOf(userMessage.getId()));
        successAck.put("sequence", userMessage.getSequence());
        clientChannel.writeAndFlush(new TextWebSocketFrame(successAck.toJSONString()));

        // 3. 👈 【异步扔进线程池】：去请求大模型 API，防止阻塞 Netty 长连接！
        aiExecutor.execute(() -> {
            try {
                log.info(">>>> 异步线程启动，开始发起大模型流式（Stream）请求...");
                Long aiMessageId = UserIdentifierGenerator.nextId();
                long timestamp = System.currentTimeMillis();
                Long seq1 = getNextSequence(userMessage.getFromUserId(), userMessage.getToUserId());
                String fullReplyContent = callAiModelStream(aiMessageId, seq1, messageRequest.getContent(), clientChannel);
                log.info(">>>> 大模型流式输出完毕，完整回答: {}", fullReplyContent);
                // 创建一条消息对象，代表“AI 的回答（消息二）”
                Message aiMessage = new Message();
                aiMessage.setId(aiMessageId);
                aiMessage.setFromUserId(AI_ASSISTANT_ID);
                aiMessage.setToUserId(messageRequest.getSenderId());
                aiMessage.setMessageType(0);
                aiMessage.setContent(fullReplyContent);
                aiMessage.setStatus(0);
                aiMessage.setSequence(seq1);
                aiMessage.setCreatedAt(System.currentTimeMillis());
                aiMessage.setUpdatedAt(System.currentTimeMillis());
                // 5. 将 AI 的回答写入数据库（确保我以后重新进页面能拉取到这段对话历史）
                messageMapper.insert(aiMessage);
                // 更新我与 AI 助手的会话消息预览
                updateSenderChatSession(messageRequest.getSenderId(), AI_ASSISTANT_ID, fullReplyContent, aiMessage.getCreatedAt());

            } catch (Exception e) {
                log.error("大模型异步处理发生异常", e);
            }
        });
        return; // 结束当前控制流


    }

    /**
     * 【方案二】：处理高级版 AI 智能体对话（带函数调用，支持读取本地数据库）
     */
    private void processAiAgentMessage(MessageDTO messageRequest, Channel clientChannel) {
        // 1. 同步将“我的提问”落库并发送成功 ACK (保持不变，极其干净)
        Message userMessage = new Message();
        userMessage.setId(UserIdentifierGenerator.nextId());
        userMessage.setFromUserId(messageRequest.getSenderId());
        userMessage.setToUserId(AI_ASSISTANT_ID);
        userMessage.setMessageType(messageRequest.getType());
        userMessage.setContent(messageRequest.getContent());
        userMessage.setStatus(0);
        userMessage.setCreatedAt(System.currentTimeMillis());
        userMessage.setUpdatedAt(System.currentTimeMillis());

        Long seq = getNextSequence(userMessage.getFromUserId(), userMessage.getToUserId());
        userMessage.setSequence(seq);

        try {
            messageMapper.insert(userMessage);
            updateSenderChatSession(messageRequest.getSenderId(), AI_ASSISTANT_ID, messageRequest.getContent(), userMessage.getCreatedAt());
        } catch (Exception e) {
            log.error("保存我的提问消息失败", e);
            JSONObject failedAck = new JSONObject();
            failedAck.put("status", "failed");
            failedAck.put("tempId", messageRequest.getTempId());
            clientChannel.writeAndFlush(new TextWebSocketFrame(failedAck.toJSONString()));
            return;
        }

//        JSONObject successAck = new JSONObject();
//        successAck.put("status", "success");
//        successAck.put("tempId", messageRequest.getTempId());
//        successAck.put("messageId", String.valueOf(userMessage.getId()));
//        successAck.put("sequence", userMessage.getSequence());
//        clientChannel.writeAndFlush(new TextWebSocketFrame(successAck.toJSONString()));

        MessageProto.MsgFrame successAckProto = MessageProto.MsgFrame.newBuilder()
                .setStatus("success")
                .setTempId(messageRequest.getTempId())
                .setMessageId(userMessage.getId())
                .setSequence(userMessage.getSequence())
                .build();
        byte[] successAckBytes = successAckProto.toByteArray();
        clientChannel.writeAndFlush(new BinaryWebSocketFrame(Unpooled.copiedBuffer(successAckBytes)));

        // 2. 👈 【核心重构：扔进线程池执行 Agent 决策流】
        aiExecutor.execute(() -> {
            try {
                log.info(">>>> [Agent 启动] 收到指令: {}, 正在执行智能体链式决策...", messageRequest.getContent());

                // 执行 Agent 工具链调用算法，获取大模型的最终智能决策文本
                String agentReply = callAiAgentProtocol(messageRequest.getSenderId(), messageRequest.getContent());

                log.info(">>>> [Agent 决策完成] 最终输出内容: {}", agentReply);
                Long seq1 = getNextSequence(userMessage.getFromUserId(), userMessage.getToUserId());
                // 3. 将大模型的最终回答写入数据库
                Message aiMessage = new Message();
                aiMessage.setId(UserIdentifierGenerator.nextId());
                aiMessage.setFromUserId(AI_ASSISTANT_ID);
                aiMessage.setToUserId(messageRequest.getSenderId());
                aiMessage.setMessageType(0);
                aiMessage.setContent(agentReply);
                aiMessage.setStatus(0);
                aiMessage.setSequence(seq1);
                aiMessage.setCreatedAt(System.currentTimeMillis());
                aiMessage.setUpdatedAt(System.currentTimeMillis());

                messageMapper.insert(aiMessage);
                updateSenderChatSession(messageRequest.getSenderId(), AI_ASSISTANT_ID, agentReply, aiMessage.getCreatedAt());

                // 4. 将回答实时推回给手机端
//                JSONObject pushData = new JSONObject();
//                pushData.put("msgId", String.valueOf(aiMessage.getId()));
//                pushData.put("senderId", AI_ASSISTANT_ID);
//                pushData.put("content", agentReply);
//                pushData.put("timestamp", aiMessage.getCreatedAt());
//                pushData.put("type", 0);
//
//                clientChannel.writeAndFlush(new TextWebSocketFrame(pushData.toJSONString()));

                MessageProto.MsgFrame pushDataProto = MessageProto.MsgFrame.newBuilder()
                        .setMessageId(aiMessage.getId())
                        .setSenderId(AI_ASSISTANT_ID)
                        .setContent(agentReply)
                        .setTimestamp(aiMessage.getCreatedAt())
                        .setType(0)
                        .build();
                byte[] pushDataBytes = pushDataProto.toByteArray();
                clientChannel.writeAndFlush(new BinaryWebSocketFrame(Unpooled.copiedBuffer(pushDataBytes)));


            } catch (Exception e) {
                log.error("Agent 智能体处理发生异常", e);
            }
        });
    }

    /**
     * 处理器一：处理普通聊天信息 (Type = 0)
     */
    private void processNormalTextMessage(MessageDTO messageRequest, Channel clientChannel) {
        String redisKey = "msg:idempotent:" + messageRequest.getTempId();
        Boolean isUnique = stringRedisTemplate.opsForValue().setIfAbsent(redisKey, "1", 300, java.util.concurrent.TimeUnit.SECONDS);
        if (Boolean.FALSE.equals(isUnique)) {
            log.warn("【防重拦截】检测到重复投递的消息包，执行防重拦截并直接回传成功 ACK. [tempId={}]", messageRequest.getTempId());
            MessageProto.MsgFrame ackProto = MessageProto.MsgFrame.newBuilder()
                    .setStatus("success")
                    .setTempId(messageRequest.getTempId())
                    .build();
            byte[] ackBytes = ackProto.toByteArray();
            clientChannel.writeAndFlush(new BinaryWebSocketFrame(Unpooled.copiedBuffer(ackBytes)));
            return;
        }

        // 将用户发送过来的消息封装成Message对象
        Message message = new Message();
        message.setId(UserIdentifierGenerator.nextId());
        message.setFromUserId(messageRequest.getSenderId());
        message.setToUserId(messageRequest.getReceiverId());
        message.setMessageType(messageRequest.getType());
        message.setContent(messageRequest.getContent());
        message.setStatus(0);
        message.setCreatedAt(System.currentTimeMillis());
        message.setUpdatedAt(System.currentTimeMillis());
        Long seq = getNextSequence(message.getFromUserId(), message.getToUserId());
        message.setSequence(seq);

        // 用户消息落库
        try {
            messageMapper.insert(message);
        } catch (Exception e) {
            log.error("消息落库失败", e);
            MessageProto.MsgFrame ackProto = MessageProto.MsgFrame.newBuilder()
                    .setStatus("false")
                    .setTempId(messageRequest.getTempId())
                    .build();
            byte[] failedAckBytes = ackProto.toByteArray();
            clientChannel.writeAndFlush(new BinaryWebSocketFrame(Unpooled.copiedBuffer(failedAckBytes)));
            return;
        }

        // 发送ACK包确认消息发送成功
        MessageProto.MsgFrame successAckProto = MessageProto.MsgFrame.newBuilder()
                .setStatus("success")
                .setTempId(messageRequest.getTempId())
                .setMessageId(message.getId())
                .setSequence(message.getSequence())
                .build();
        log.info("sequence: {}", message.getSequence());
        byte[] ackBytes = successAckProto.toByteArray();
        clientChannel.writeAndFlush(new BinaryWebSocketFrame(Unpooled.copiedBuffer(ackBytes)));

        // 更新会话未读数
        chatSessionMapper.incrementUnreadCount(
                messageRequest.getReceiverId(),
                messageRequest.getSenderId(),
                messageRequest.getContent(),
                System.currentTimeMillis()
        );

        updateSenderChatSession(message.getFromUserId(), message.getToUserId(), message.getContent(), message.getCreatedAt());

        try {
            // 将消息发送到RabbitMQ
            rabbitTemplate.convertAndSend(
                    "chat.exchange",
                    "chat",
                    message
            );
        } catch (Exception e) {
            log.error("发送消息到 RabbitMQ 失败", e);
        }

        MessageProto.MsgFrame pushData = MessageProto.MsgFrame.newBuilder()
                .setMessageId(message.getId())
                .setSenderId(message.getFromUserId())
                .setContent(message.getContent())
                .setTimestamp(message.getCreatedAt())
                .setType(message.getMessageType())
                .setSequence(message.getSequence())
                .setReceiverId(message.getToUserId())
                .build();
        byte[] pushDataBytes = pushData.toByteArray();

        // 实时推送普通消息给接收方 B
        Channel receiverChannel = sessionManager.getChannel(message.getToUserId());

        // 👈 判断接收方当前是否在线
        boolean isOnline = receiverChannel != null && receiverChannel.isActive();

        // 3. 👈 【核心修复点】：安全更新接收方 B 的会话（自动判断在线/离线并执行增量或初始化）
        updateReceiverChatSession(message.getToUserId(), message.getFromUserId(), message.getContent(), message.getCreatedAt(), isOnline);

        if (isOnline) {
            log.info(">>>> 接收方在当前服务器在线，执行本地物理直推");
            updateSenderChatSession(message.getToUserId(), message.getFromUserId(), message.getContent(), message.getCreatedAt());
            receiverChannel.writeAndFlush(new BinaryWebSocketFrame(Unpooled.copiedBuffer(pushDataBytes)));
        } else {
            log.info(">>>> 在本地未找到接收方连接...");
        }
    }


    /**
     * 处理器二：处理语音呼叫邀请 (Type = 1)
     */
    private void processVoiceCallInvite(MessageDTO messageRequest, Channel clientChannel) {
        // 👈 【大厂规范日志】：带有明确的业务类型和业务对象，便于 ELK 提取“呼叫发起数”
        log.info("【通话信令日志】用户 [{}] 📲 成功发起了 [语音通话呼叫] -> 目标用户: [{}]",
                messageRequest.getSenderId(), messageRequest.getReceiverId());

        sendSuccessAck(messageRequest.getTempId(), clientChannel);
        routeSignalingToReceiver(messageRequest);
    }

    /**
     * 处理器三：处理同意接受语音 (Type = 2)
     */
    private void processVoiceCallAccept(MessageDTO messageRequest, Channel clientChannel) {
        // 👈 便于 ELK 统计“接通率”
        log.info("【通话信令日志】用户 [{}] ✅ 同意接听了 [语音通话] -> 目标用户: [{}]",
                messageRequest.getSenderId(), messageRequest.getReceiverId());

        sendSuccessAck(messageRequest.getTempId(), clientChannel);
        routeSignalingToReceiver(messageRequest);
    }

    /**
     * 处理器四：处理通话挂断/拒绝 (Type = 3)
     */
    private void processCallHangup(MessageDTO messageRequest, Channel clientChannel) {
        // 👈 便于 ELK 统计“平均通话时长”
        log.info("【通话信令日志】用户 [{}] 🛑 结束/挂断了 [通话邀请/通话通道] -> 目标用户: [{}]",
                messageRequest.getSenderId(), messageRequest.getReceiverId());

        sendSuccessAck(messageRequest.getTempId(), clientChannel);
        routeSignalingToReceiver(messageRequest);
    }

    /**
     * 处理器五：处理视频呼叫邀请 (Type = 4)
     */
    private void processVideoCallInvite(MessageDTO messageRequest, Channel clientChannel) {
        log.info("【通话信令日志】用户 [{}] 📷 成功发起了 [视频通话呼叫] -> 目标用户: [{}]",
                messageRequest.getSenderId(), messageRequest.getReceiverId());

        sendSuccessAck(messageRequest.getTempId(), clientChannel);
        routeSignalingToReceiver(messageRequest);
    }

    /**
     * 处理器六：处理同意接受视频 (Type = 5)
     */
    private void processVideoCallAccept(MessageDTO messageRequest, Channel clientChannel) {
        log.info("【通话信令日志】用户 [{}] 🟢 同意接听了 [视频通话] -> 目标用户: [{}]",
                messageRequest.getSenderId(), messageRequest.getReceiverId());

        sendSuccessAck(messageRequest.getTempId(), clientChannel);
        routeSignalingToReceiver(messageRequest);
    }

    private void sendSuccessAck(Long tempId, Channel clientChannel) {
        MessageProto.MsgFrame successAckProto = MessageProto.MsgFrame.newBuilder()
                .setStatus("success")
                .setTempId(tempId)
                .build();
        byte[] ackBytes = successAckProto.toByteArray();
        clientChannel.writeAndFlush(new BinaryWebSocketFrame(Unpooled.copiedBuffer(ackBytes)));
    }

    private void routeSignalingToReceiver(MessageDTO messageRequest) {
        Channel receiverChannel = sessionManager.getChannel(messageRequest.getReceiverId());

        if (receiverChannel != null && receiverChannel.isActive()) {
            MessageProto.MsgFrame pushData = MessageProto.MsgFrame.newBuilder()
                    .setMessageId(UserIdentifierGenerator.nextId())
                    .setTempId(messageRequest.getTempId())
                    .setContent(messageRequest.getContent())
                    .setTimestamp(System.currentTimeMillis())
                    .setType(messageRequest.getType())
                    .build();
            byte[] pushDataBytes = pushData.toByteArray();
            receiverChannel.writeAndFlush(new BinaryWebSocketFrame(Unpooled.copiedBuffer(pushDataBytes)));
        } else {
            MessageProto.MsgFrame pushData = MessageProto.MsgFrame.newBuilder()
                    .setContent("对方不在线")
                    .setType(3)
                    .build();
            byte[] pushDataBytes = pushData.toByteArray();
            receiverChannel.writeAndFlush(new BinaryWebSocketFrame(Unpooled.copiedBuffer(pushDataBytes)));
        }
    }

    private void updateReceiverChatSession(Long userId, Long friendId, String content, Long timestamp, boolean isOnline) {
        // 1. 尝试执行更新。如果在线则不累加未读数，如果离线则累加未读数
        int affectedRows;
        if (isOnline) {
            affectedRows = chatSessionMapper.updateSenderSession(userId, friendId, content, timestamp);
        } else {
            affectedRows = chatSessionMapper.incrementUnreadCount(userId, friendId, content, timestamp);
        }

        // 2. 如果影响行数为 0，说明接收方数据库中还没有创建过该会话，立即执行自动初始化插入！
        if (affectedRows == 0) {
            log.info(">>>> 发现接收方 [{}] 与发送方 [{}] 的会话不存在，开始自动创建...", userId, friendId);

            ChatSession session = new ChatSession();
            session.setId(UserIdentifierGenerator.nextId());
            session.setUserId(userId);
            session.setFriendId(friendId);
            session.setLastMessage(content);

            // 如果在线设为 0，离线设为 1
            session.setUnreadCount(isOnline ? 0 : 1);
            session.setUpdatedAt(timestamp);

            try {
                chatSessionMapper.insert(session);
                log.info(">>>> 成功为接收方 [{}] 初始化创建了首屏会话！", userId);
            } catch (Exception e) {
                // 并发防护：如果报唯一键冲突，重新更新一次即可
                if (isOnline) {
                    chatSessionMapper.updateSenderSession(userId, friendId, content, timestamp);
                } else {
                    chatSessionMapper.incrementUnreadCount(userId, friendId, content, timestamp);
                }
            }
        }
    }
}
