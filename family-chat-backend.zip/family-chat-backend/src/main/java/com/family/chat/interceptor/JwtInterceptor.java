package com.family.chat.interceptor;

import com.family.chat.common.result.ResultCode;
import com.family.chat.exception.ServiceException;
import com.family.chat.util.JwtUtil; // 导入您的 JwtUtil
import com.family.chat.config.JwtProperties; // 导入您的配置类

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

@Component
public class JwtInterceptor implements HandlerInterceptor {

    private static final Logger log = LoggerFactory.getLogger(JwtInterceptor.class);

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        // 放行浏览器的跨域预检（OPTIONS）请求
        if ("OPTIONS".equalsIgnoreCase(request.getMethod())) {
            return true;
        }

        // 1. 获取请求头中的 Authorization Token
        String authorization = request.getHeader("Authorization");
        if (authorization == null || !authorization.startsWith("Bearer ")) {
            throw new ServiceException(ResultCode.UNAUTHORIZED); // 未登录，抛出401
        }

        String token = authorization.replace("Bearer ", "");

        // 2. 👈 【核心安全防护】：拦截并校验该 Token 是否存在于 Redis 黑名单中！
        String blacklistKey = "auth:blacklist:" + token;
        Boolean isBlacklisted = stringRedisTemplate.hasKey(blacklistKey);

        if (Boolean.TRUE.equals(isBlacklisted)) {
            // 发现盗刷危险！直接报警拦截
            log.warn("【安全拦截】拦截到已退出登录的黑名单 Token 盗刷请求! [token={}]", token);
            throw new ServiceException(ResultCode.UNAUTHORIZED); // 强制返回 401
        }

        try {
            jwtUtil.parseToken(token);
        } catch (Exception e) {
            throw new ServiceException(ResultCode.UNAUTHORIZED);
        }
        return true;
    }
}