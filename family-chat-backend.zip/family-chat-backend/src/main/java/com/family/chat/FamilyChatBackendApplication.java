package com.family.chat;

import com.family.chat.netty.NettyServer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FamilyChatBackendApplication implements CommandLineRunner {

    @Autowired
    private NettyServer nettyServer;

    public static void main(String[] args) {
        SpringApplication.run(FamilyChatBackendApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        // 在 8081 端口启动 Netty WebSocket 服务
        nettyServer.start(8081);
    }
}
