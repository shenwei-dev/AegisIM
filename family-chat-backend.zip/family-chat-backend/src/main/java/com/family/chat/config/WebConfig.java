package com.family.chat.config;

import com.family.chat.interceptor.GlobalRateLimitInterceptor;
import com.family.chat.interceptor.ApiRateLimitInterceptor;
import com.family.chat.interceptor.RequestIdInterceptor;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * Web 配置类 (WebConfig)。
 *
 * <p>负责注册全局拦截器, 包括请求ID生成、全局限流和接口限流。<p/>
 *
 * @author ShenWei
 */
@Configuration
@RequiredArgsConstructor
public class WebConfig implements WebMvcConfigurer {

    /** 请求ID拦截器 */
    private final RequestIdInterceptor requestIdInterceptor;

    /** 接口级限流拦截器 */
    private final ApiRateLimitInterceptor apiRateLimitInterceptor;

    /** 全局限流拦截器 */
    private final GlobalRateLimitInterceptor globalRateLimitInterceptor;

    /**
     * 添加拦截器到 Spring MVC 拦截链。
     * 顺序很重要: 先生成请求ID, 再进行全局限流, 最后接口限流。
     *
     * @param registry {@link InterceptorRegistry} 拦截器注册器
     */
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        // 负责生成唯一请求ID（requestId）并放入日志上下文，用于请求追踪。
        registry.addInterceptor(requestIdInterceptor).addPathPatterns("/**");

        // 全局限流
        registry.addInterceptor(globalRateLimitInterceptor)
                .addPathPatterns("/**")
                .excludePathPatterns("/health",
                                    "/static/**",
                                    "/api/auth/login",
                                    "/api/auth/register"
                );


        // 接口限流
        registry.addInterceptor(apiRateLimitInterceptor).addPathPatterns("/**");
    }
}
