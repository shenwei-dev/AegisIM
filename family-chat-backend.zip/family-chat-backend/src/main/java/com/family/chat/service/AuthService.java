package com.family.chat.service;

import com.family.chat.common.result.ApiResponse;
import com.family.chat.dto.LoginDTO;
import com.family.chat.request.LoginRequest;
import com.family.chat.request.RegisterRequest;
import com.family.chat.vo.RegisterVO;

public interface AuthService {

    LoginDTO login(LoginRequest loginRequest);

    RegisterVO register(RegisterRequest registerRequest);

    void logout(String accessToken);
}
