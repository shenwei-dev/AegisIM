package com.family.chat.controller;


import com.family.chat.common.result.ApiResponse;
import com.family.chat.dto.SearchUserDTO;
import com.family.chat.service.UserService;
import com.family.chat.vo.QueryUserInfoVO;
import com.family.chat.vo.SearchUserVO;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/user")
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping(value = "/info")
    public ApiResponse<QueryUserInfoVO> queryUserInfo() {
        QueryUserInfoVO queryUserInfoVO = new QueryUserInfoVO();
        BeanUtils.copyProperties(userService.getUserById(), queryUserInfoVO);
        return ApiResponse.success(queryUserInfoVO);
    }

    @PostMapping("/search/{account}")
    public ApiResponse<SearchUserVO> searchUser(@PathVariable("account") Long account) {
        SearchUserDTO searchUserDTO = userService.queryUserByAccount(account);
        SearchUserVO searchUserVO = new SearchUserVO();
        if (searchUserDTO != null) {
            BeanUtils.copyProperties(searchUserDTO, searchUserVO);
            return ApiResponse.success(searchUserVO);
        }
        return ApiResponse.success(null);
    }
}
