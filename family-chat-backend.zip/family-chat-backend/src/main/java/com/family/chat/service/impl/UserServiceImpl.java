package com.family.chat.service.impl;

import com.family.chat.dto.SearchUserDTO;
import com.family.chat.dto.QueryUserInfoDTO;
import com.family.chat.entity.User;
import com.family.chat.mapper.UserMapper;
import com.family.chat.service.UserService;
import com.family.chat.util.SecurityUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserMapper userMapper;

    // 查询当前用户详细信息
    @Override
    public QueryUserInfoDTO getUserById() {
        Long userId = SecurityUtil.getCurrentUserId();
        User user = userMapper.selectById(userId);
        QueryUserInfoDTO queryUserInfoDTO = new QueryUserInfoDTO();
        BeanUtils.copyProperties(user, queryUserInfoDTO);
        return queryUserInfoDTO;
    }

    // 根据用户名查询用户
    @Override
    public SearchUserDTO queryUserByAccount(Long account) {
        User user = userMapper.selectByAccount(account);
        SearchUserDTO searchUserDTO = new SearchUserDTO();
        if (user != null) {
            BeanUtils.copyProperties(user, searchUserDTO);
            return searchUserDTO;
        }
        return null;
    }
}
