package com.family.chat.handler;

import com.family.chat.common.result.ApiResponse;
import com.family.chat.exception.ServiceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(ServiceException.class)
    public ResponseEntity<ApiResponse<?>> handleServiceException(ServiceException e) {
        return ResponseEntity.ok(ApiResponse.fail(e.getResultCode()));
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiResponse<?>> handleException(Exception e) {
        log.error(e.getMessage(), e);
        return ResponseEntity
                .status(500)
                .body(ApiResponse.fail(com.family.chat.common.result.ResultCode.SYSTEM_ERROR));
    }
}
