package com.family.chat.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMQConfig {

    // 1. 创建测试队列 (保留您原有的)
    @Bean
    public Queue testQueue(){
        return new Queue("test.queue", true);
    }

    // 2. 配置消息转换器：使用 Jackson 将 Java 实体类自动序列化为 JSON 字符串传输
    @Bean
    public MessageConverter messageConverter(){
        return new Jackson2JsonMessageConverter();
    }

    // 3. 【修改点】：将交换机实际名称修改为 "chat.exchange"，完美匹配业务代码
    @Bean
    public DirectExchange chatExchange(){
        return new DirectExchange("chat.exchange");
    }

    // 4. 创建聊天核心接收队列
    @Bean
    public Queue chatQueue(){
        return new Queue("chat.queue");
    }

    // 5. 将队列 chat.queue 与交换机 chat.exchange 进行绑定，指定路由键为 "chat"
    @Bean
    public Binding binding(){
        return BindingBuilder
                .bind(chatQueue())
                .to(chatExchange())
                .with("chat"); // RoutingKey
    }
}