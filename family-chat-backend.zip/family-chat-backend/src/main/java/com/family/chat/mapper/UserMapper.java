package com.family.chat.mapper;

import com.family.chat.entity.User;
import com.family.chat.enums.UserStatus;
import org.apache.ibatis.annotations.*;
import java.time.LocalDateTime;


@Mapper
public interface UserMapper {

    @Insert("""
        INSERT INTO im_user
        (id, account, password_hash, nickname, avatar_url, status, privacy_mode, created_at, updated_at)
        VALUES
        (#{id}, #{account}, #{passwordHash}, #{nickname}, #{avatarUrl}, #{status}, #{privacyMode},  #{createdAt}, #{updatedAt})
    """)
    int insert(User user);

    @Select("SELECT * FROM im_user WHERE id = #{id}")
    User selectById(@Param("id") Long id);

    @Select("SELECT * FROM im_user WHERE account = #{account}")
    User selectByAccount(@Param("account") Long account);

    @Update("""
        UPDATE im_user
        SET nickname = #{nickname},
            avatar_url = #{avatarUrl},
            status = #{status},
            privacy_mode = #{privacyMode},
            updated_at = #{updatedAt}
        WHERE id = #{id}
    """)
    int update(User user);

    @Update("""
        UPDATE im_user
        SET is_deleted = 1, deleted_at = #{deletedAt}
        WHERE id = #{id}
    """)
    int deleteLogic(@Param("id") Long id, @Param("deletedAt") Long deletedAt);
}
