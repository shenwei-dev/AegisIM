package com.family.chat.enums;

public enum MessageType {

    TEXT(1, "文本"),
    IMAGE(2, "图片");

    private final int code;
    private final String message;

    MessageType(int code, String message) {
        this.code = code;
        this.message = message;
    }

    public int getCode() { return code; }

    public String getMessage() { return message; }

    public static MessageType fromCode(int code) {
        for (MessageType type : values()) {
            if (type.code == code) return type;
        }
        return null;
    }
}
