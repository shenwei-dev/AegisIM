package com.family.chat.interceptor;

import com.family.chat.common.result.ResultCode;
import com.family.chat.exception.ServiceException;
import com.family.chat.util.JwtUtil;
import com.family.chat.util.SecurityUtil;
import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import java.io.IOException;

@Slf4j
@Component
@RequiredArgsConstructor
public class AuthInterceptor implements Filter {

    private final JwtUtil jwtUtil;

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        // 获取请求对象
        HttpServletRequest http = (HttpServletRequest) request;

        // 从请求头中取出token
        String token = http.getHeader("Authorization");

        // 如果token不为空,且解析有效
        if (token != null) {
            if(token.startsWith("Bearer ")){
                token = token.substring(7);
            }
            if (jwtUtil.parseToken(token) != null) {
                // 从token中取出用户名
                Long userId = jwtUtil.getUserId(token);

                // 将当前用户名设置进线程中
                SecurityUtil.setCurrentUserId(userId);
            }
        }

        try {
            chain.doFilter(request, response);
        } finally {
            SecurityUtil.clear();
        }
    }
}
