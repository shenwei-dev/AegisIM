package com.family.chat.controller;

import com.family.chat.common.result.ApiResponse;
import com.family.chat.entity.Message;
import com.family.chat.protobuf.MessageProto;
import com.family.chat.request.SendMessageRequest;
import com.family.chat.service.MessageService;
import com.family.chat.util.SecurityUtil;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/chat")
public class MessageController {

    @Autowired
    private final MessageService messageService;

    /**
     * 👈 【大厂级核心接口】：对标微信 SyncKey 的增量消息拉取
     * @param localMaxSeq 客户端本地当前已有的最大消息序号
     */
    @GetMapping(value = "/sync/{friendId}",  produces = "application/x-protobuf")
    public  MessageProto.QueryHistoryResponse syncMessages(
            @PathVariable("friendId") Long friendId,
            @RequestParam("localMaxSeq") Long localMaxSeq) {
        Long currentUserId = SecurityUtil.getCurrentUserId();
        List<Message> historyList = messageService.getDeltaMessages(currentUserId, friendId, localMaxSeq);

        MessageProto.QueryHistoryResponse.Builder responseBuilder = MessageProto.QueryHistoryResponse.newBuilder()
                .setCode(1000)
                .setMessage("SUCCESS");

        for (Message message : historyList) {
            MessageProto.MsgFrame.Builder messageBuilder = MessageProto.MsgFrame.newBuilder()
                    .setMessageId(message.getId())
                    .setSenderId(message.getFromUserId())
                    .setReceiverId(message.getToUserId())
                    .setContent(message.getContent())
                    .setTimestamp(message.getCreatedAt())
                    .setType(message.getMessageType());

            if (message.getSequence() != null) {
                messageBuilder.setSequence(message.getSequence());
            }
            // 将每一条单条消息加入 repeated data 列表中
            responseBuilder.addData(messageBuilder.build());
        }
        return responseBuilder.build();
    }
}
