package com.family.chat.service.impl;

import com.family.chat.mapper.ChatSessionMapper;
import com.family.chat.service.ChatSessionService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import com.family.chat.vo.ChatSessionVO;

@Service
@RequiredArgsConstructor
public class ChatSessionServiceImpl implements ChatSessionService {

    private final ChatSessionMapper chatSessionMapper;

    @Override
    public List<ChatSessionVO> getRecentSessions(Long userId) {
        return chatSessionMapper.selectUserSessions(userId);
    }
}