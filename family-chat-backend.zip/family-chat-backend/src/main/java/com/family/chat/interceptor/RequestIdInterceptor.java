package com.family.chat.interceptor;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import java.util.UUID;

/**
 * 请求唯一标识拦截器 (RequestIdInterceptor)。
 * <p>实现 {@link HandlerInterceptor}。
 * 每个 HTTP 请求进入系统时, 会生成一个唯一请求 ID 并注入到日志上下文(MDC)中,
 * 同时将该请求 ID 写入响应头, 用于请求追踪和日志关联。
 * </p>
 *
 * @author ShenWei
 */
@Component
@SuppressWarnings("NullableProblems")
public class RequestIdInterceptor implements HandlerInterceptor {

    /** 在 MDC中存放请求 ID的key */
    private static final String TRACE_ID_KEY = "traceId";

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        // 生成一个唯一请求ID
        String traceId = UUID.randomUUID().toString();

        // 放入 MDC
        MDC.put(TRACE_ID_KEY, traceId);

        // 把requestId 放回响应头
        response.setHeader("X-Trace-Id", traceId);

        // 放行请求
        return true;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {
        // 请求处理完成后清理 MDC
        MDC.remove(TRACE_ID_KEY);
    }
}
