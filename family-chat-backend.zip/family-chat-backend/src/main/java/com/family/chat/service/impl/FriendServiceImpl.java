package com.family.chat.service.impl;

import com.family.chat.common.result.ResultCode;
import com.family.chat.entity.Friend;
import com.family.chat.entity.FriendRequest;
import com.family.chat.enums.FriendRequestStatus;
import com.family.chat.exception.ServiceException;
import com.family.chat.mapper.FriendMapper;
import com.family.chat.mapper.FriendRequestMapper;
import com.family.chat.request.AddFriendRequest;
import com.family.chat.request.UpdateFriendRemarkRequest;
import com.family.chat.service.FriendsService;
import com.family.chat.util.SecurityUtil;
import com.family.chat.vo.QueryFriendDetailVO;
import com.family.chat.vo.QueryFriendListVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

/**
 * 联系人服务实现类（ContactsServiceImpl）。
 *
 * @author ShenWei
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class FriendServiceImpl implements FriendsService {

    private final FriendMapper friendMapper;

    private final FriendRequestMapper friendRequestMapper;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void addFriend(AddFriendRequest addFriendRequest) {
        Long userId = SecurityUtil.getCurrentUserId();
        Long targetUserId = addFriendRequest.getTargetUserId();

        // 判断当前是否已经是好友
        if (friendMapper.exists(userId, targetUserId) > 0) {
            throw new ServiceException(ResultCode.FRIEND_ALREADY_EXISTS);
        }

        // 判断是否存在当前好友的请求未被处理
        if (friendRequestMapper.existsPendingRequest(userId, targetUserId)) {
            throw new ServiceException(ResultCode.FRIEND_REQUEST_PENDING);
        }

        FriendRequest friendRequest = new FriendRequest();
        friendRequest.setFromUserId(userId);
        friendRequest.setToUserId(targetUserId);
        friendRequest.setStatus(0);
        friendRequest.setCreatedAt(System.currentTimeMillis());
        friendRequest.setUpdatedAt(System.currentTimeMillis());

        // 发送好友请求
        friendRequestMapper.insert(friendRequest);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateRemark(UpdateFriendRemarkRequest updateFriendRemarkRequest) {
        Long userId = SecurityUtil.getCurrentUserId();
        Long friendId = updateFriendRemarkRequest.getFriendId();
        if (!(friendMapper.exists(userId, friendId) > 0)) {
            throw new ServiceException(ResultCode.FRIEND_NOT_FOUND);
        }
        friendMapper.updateRemark(userId, friendId, updateFriendRemarkRequest.getRemark());
    }

    @Override
    public void deleteFriend(Long friendId) {
        Long userId = SecurityUtil.getCurrentUserId();

        // 判断当前是否是好友
        if (!(friendMapper.exists(userId, friendId) > 0)) {
            throw new ServiceException(ResultCode.FRIEND_NOT_FOUND);
        }

        friendMapper.deleteFriend(userId, friendId, System.currentTimeMillis());
    }

    @Override
    public List<QueryFriendListVO> listFriends(Long userId) {
        List<QueryFriendListVO> friendList = friendMapper.selectFriendList(userId);
        return friendList;
    }

    @Override
    public boolean isFriend(Long userId, Long friendId) {
        return friendMapper.exists(userId, friendId) > 0;
    }

    @Override
    public QueryFriendDetailVO getFriend(Long friendId) {
        return friendMapper.selectFriendDetail(SecurityUtil.getCurrentUserId(), friendId);
    }
}