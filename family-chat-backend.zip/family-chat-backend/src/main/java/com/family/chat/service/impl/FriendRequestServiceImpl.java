package com.family.chat.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.family.chat.common.result.ResultCode;
import com.family.chat.dto.QueryFriendRequestListDTO;
import com.family.chat.entity.*;
import com.family.chat.exception.ServiceException;
import com.family.chat.mapper.*;
import com.family.chat.netty.SessionManager;
import com.family.chat.request.FriendAcceptRequest;
import com.family.chat.request.FriendApplyRequest;
import com.family.chat.service.FriendRequestService;
import com.family.chat.service.MessageService;
import com.family.chat.util.SecurityUtil;
import com.family.chat.util.UserIdentifierGenerator;
import com.family.chat.vo.FriendRequestVO;
import io.netty.channel.Channel;
import io.netty.handler.codec.http.websocketx.TextWebSocketFrame;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class FriendRequestServiceImpl implements FriendRequestService {

    private final FriendRequestMapper friendRequestMapper;

    private final FriendMapper friendMapper;

    private final UserMapper userMapper;

    private final SessionManager sessionManager;

    private final ChatSessionMapper chatSessionMapper;

    // 发起好友请求
    @Override
    public void transmitFriendRequest(FriendApplyRequest friendApplyRequest) {
        Long targetAccount = friendApplyRequest.getTargetAccount();

        User user = userMapper.selectByAccount(targetAccount);
        if (user == null) {
            throw new ServiceException(ResultCode.USER_NOT_EXIST);
        }

        Long fromUserId = SecurityUtil.getCurrentUserId();
        Long toUserId = user.getId();

        // 使用双向查询，拦截所有待处理记录 (复用我们上一步修改的高性能SQL)
        FriendRequest existRequest = friendRequestMapper.selectExist(fromUserId, toUserId);

        if (existRequest != null) {
            throw new ServiceException(ResultCode.FRIEND_REQUEST_PENDING);
        }

        // 👈 【Bug 修复】：重新 new 一个实体，彻底杜绝空指针异常
        FriendRequest friendRequest = new FriendRequest();
        friendRequest.setId(UserIdentifierGenerator.nextId());
        friendRequest.setFromUserId(fromUserId);
        friendRequest.setToUserId(toUserId);
        friendRequest.setCreatedAt(System.currentTimeMillis());
        friendRequest.setUpdatedAt(System.currentTimeMillis());
        friendRequest.setRemark(friendApplyRequest.getRemark());
        friendRequest.setGreeting(friendApplyRequest.getMessage());

        // 1. 同步插入数据库
        friendRequestMapper.insert(friendRequest);
        log.info(">>>> 好友申请落库成功，发送者: {}, 接收者: {}", fromUserId, toUserId);

        // 2. 【核心改动】：通过 SessionManager 寻找接收方 B 是否在线
        Channel receiverChannel = sessionManager.getChannel(toUserId);
        if (receiverChannel != null && receiverChannel.isActive()) {
            log.info(">>>> 接收方用户 [{}] 在线，开始执行 Netty 实时红点推送", toUserId);

            // 组装极简的控制信令 (type = 6 代表：新朋友申请红点通知)
            JSONObject pushData = new JSONObject();
            pushData.put("type", 6);
            pushData.put("senderId", fromUserId); // 携带是谁发起的，便于 B 端进行日志分析
            pushData.put("content", "您有一条新的好友申请");

            // 通过 WebSocket 将信号直推给 B 的手机
            receiverChannel.writeAndFlush(new TextWebSocketFrame(pushData.toJSONString()));
            log.info(">>>> 实时红点信令已成功推给用户: {}", toUserId);

        } else {
            log.info(">>>> 接收方用户 [{}] 处于离线状态，信令无需推送，等待其上线后自主拉取", toUserId);
        }
    }

    // 同意好友请求
    @Override
    public void acceptFriendRequest(Long id) {
        FriendRequest friendRequest = friendRequestMapper.selectById(id);
        if (friendRequest == null) {
            throw new ServiceException(ResultCode.FRIEND_REQUEST_NOT_EXIST);
        }
        friendRequestMapper.updateStatus(id, 1, System.currentTimeMillis());

        Long userA = friendRequest.getFromUserId();
        Long userB = friendRequest.getToUserId();
        insertFriendRelation(userA, userB, friendRequest.getRemark());
        insertFriendRelation(userB, userA, null);

        String initMessage = "您已添加了对方为好友，现在可以开始聊天了。";
        createChatSession(userA, userB, initMessage);
        createChatSession(userB, userA, initMessage);

        pushNewSessionSignal(userA, userB, initMessage);
        pushNewSessionSignal(userB, userA, initMessage);
    }

    // 获取好友请求列表
    @Override
    public List<FriendRequestVO> getFriendRequestList() {
        List<FriendRequestVO> friendRequestList = friendRequestMapper.selectUndelete(SecurityUtil.getCurrentUserId());
        return friendRequestList;
    }

    // 插入好友记录
    private void insertFriendRelation(Long fromUserId, Long toUserId, String remark) {
        Friend friend = new Friend();
        friend.setId(UserIdentifierGenerator.nextId());
        friend.setUserId(fromUserId);
        friend.setFriendId(toUserId);
        friend.setRemark(remark);
        friend.setCreatedAt(System.currentTimeMillis());
        friendMapper.insert(friend);
    }

    private void createChatSession(Long userId, Long friendId, String lastMessage) {
        ChatSession session = new ChatSession();
        session.setId(UserIdentifierGenerator.nextId());
        session.setUserId(userId);
        session.setFriendId(friendId);
        session.setLastMessage(lastMessage);
        session.setUnreadCount(0);
        session.setUpdatedAt(System.currentTimeMillis());
        chatSessionMapper.insert(session);
    }

    private void pushNewSessionSignal(Long fromUserId, Long toUserId, String lastMessage) {
        Channel channel = sessionManager.getChannel(fromUserId);
        if (channel != null && channel.isActive()) {
            JSONObject push = new JSONObject();
            push.put("type", 7);
            push.put("toUserId", toUserId);
            push.put("lastMessage", lastMessage);
            push.put("timestamp", System.currentTimeMillis());
            channel.writeAndFlush(new TextWebSocketFrame(push.toJSONString()));
        }
    }
}
