package com.family.chat.service;

import com.family.chat.vo.ChatSessionVO;

import java.util.List;

public interface ChatSessionService {
    List<ChatSessionVO> getRecentSessions(Long userId);
}