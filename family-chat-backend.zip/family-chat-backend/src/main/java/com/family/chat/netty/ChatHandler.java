package com.family.chat.netty;

import com.alibaba.fastjson.JSON;
import com.family.chat.dto.MessageDTO;
import com.family.chat.protobuf.MessageProto;
import com.family.chat.service.MessageService;
import com.family.chat.util.UserIdentifierGenerator;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.handler.codec.http.websocketx.BinaryWebSocketFrame;
import io.netty.handler.codec.http.websocketx.TextWebSocketFrame;
import io.netty.handler.codec.http.websocketx.WebSocketFrame;
import io.netty.handler.codec.http.websocketx.WebSocketServerProtocolHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ChatHandler extends SimpleChannelInboundHandler<WebSocketFrame> {

    private static final Logger log = LoggerFactory.getLogger(ChatHandler.class);

    @Override
    protected void channelRead0(ChannelHandlerContext ctx, WebSocketFrame frame) throws Exception {
        if (frame instanceof BinaryWebSocketFrame) {
            String traceId = String.valueOf(UserIdentifierGenerator.nextId());
            org.slf4j.MDC.put("traceId", traceId);
            ByteBuf content = frame.content();
            byte[] bytes = new byte[content.readableBytes()];
            content.readBytes(bytes);
            MessageProto.MsgFrame protoMsg = MessageProto.MsgFrame.parseFrom(bytes);
            log.info(">>>> [Protobuf 物理接收] 解析成功, 内容: {}, 类型: {}", protoMsg.getContent(), protoMsg.getType());
            MessageDTO dto = new MessageDTO();
            dto.setTempId(protoMsg.getTempId());
            dto.setReceiverId(protoMsg.getReceiverId());
            dto.setContent(protoMsg.getContent());
            dto.setType(protoMsg.getType());
            Long realUserId = ctx.channel().attr(HandshakeAuthHandler.USER_ID_KEY).get();
            if (realUserId == null) {
                log.error("通道未绑定合法用户ID，强制下线");
                ctx.close();
                return;
            }
            dto.setSenderId(realUserId);
            MessageService messageService = SpringUtil.getBean(MessageService.class);
            messageService.handleWebSocketMessage(dto, ctx.channel());
        }
    }

    @Override
    public void handlerRemoved(ChannelHandlerContext ctx) throws Exception {
        log.info("客户端下线，通道关闭: {}", ctx.channel().id().asLongText());
        SessionManager sessionManager = SpringUtil.getBean(SessionManager.class);
        sessionManager.unbind(ctx.channel());
        log.info("Client channel inactive. Session unbound successfully. [channel_id={}, remaining_online={}]",
                ctx.channel().id().asShortText(), sessionManager.getOnlineCount());
        log.info("下线成功。当前在线人数: {}", sessionManager.getOnlineCount());
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        log.error("通道异常断开", cause);
        ctx.close();
    }

    @Override
    public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
        if (evt instanceof io.netty.handler.timeout.IdleStateEvent) {
            io.netty.handler.timeout.IdleStateEvent event = (io.netty.handler.timeout.IdleStateEvent) evt;
            if (event.state() == io.netty.handler.timeout.IdleState.READER_IDLE) {
                log.warn("【心跳超时】检测到连接已假死，服务端主动断开物理通道: {}", ctx.channel().id().asShortText());
                ctx.close();
                return;
            }
        }
        if (evt instanceof WebSocketServerProtocolHandler.HandshakeComplete) {
            Long realUserId = ctx.channel().attr(HandshakeAuthHandler.USER_ID_KEY).get();
            if (realUserId != null) {
                SessionManager sessionManager = SpringUtil.getBean(SessionManager.class);
                sessionManager.bind(realUserId, ctx.channel());
                log.info(">>>> [物理握手彻底完成] 用户 [{}] 成功上线！", realUserId);
                MessageService messageService = SpringUtil.getBean(MessageService.class);
                messageService.pushOfflineFriendRequests(realUserId, ctx.channel());
            }
        }
        super.userEventTriggered(ctx, evt);
    }
}