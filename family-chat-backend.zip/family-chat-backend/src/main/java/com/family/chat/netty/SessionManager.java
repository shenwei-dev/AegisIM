package com.family.chat.netty;

import io.netty.channel.Channel;
import org.springframework.stereotype.Component;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class SessionManager {

    private final ConcurrentHashMap<Long, Channel> onlineUsers = new ConcurrentHashMap<>();

    public void bind(Long userId, Channel channel) {
        onlineUsers.put(userId, channel);
    }

    public void unbind(Channel channel) {
        onlineUsers.values().remove(channel);
    }

    public Channel getChannel(Long userId) {
        return onlineUsers.get(userId);
    }

    public int getOnlineCount() {
        return onlineUsers.size();
    }
}