package com.family.chat.netty;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.ChannelFuture;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.SelfSignedCertificate;
import jakarta.annotation.PreDestroy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class NettyServer {

    private static final Logger log = LoggerFactory.getLogger(NettyServer.class);

    public static SslContext sslContext;

    // 主线程组，用于接收客户端连接
    private final EventLoopGroup bossGroup = new NioEventLoopGroup(1);

    // 工作线程组，用于处理网络读写逻辑
    private final EventLoopGroup workerGroup = new NioEventLoopGroup();

    private ChannelFuture channelFuture;

    /**
     * 启动 Netty WebSocket 服务
     * @param port 监听的端口号 (例如 8081)
     */
    public void start(int port) {
        new Thread(() -> {
            try {
                // ==================== 【WSS 核心：自签名证书构建】 ====================
                // Netty 自带的物理证书工具，会在本地内存自动为您生成并签发一套标准的 SSL/TLS 证书
                SelfSignedCertificate ssc = new SelfSignedCertificate();
                sslContext = SslContextBuilder.forServer(ssc.certificate(), ssc.privateKey()).build();
                log.info(">>>> 【WSS 加密通道】自签名 SSL/TLS 证书加载完成，WSS 通道物理就绪 <<<<");
                // ===================================================================

                ServerBootstrap bootstrap = new ServerBootstrap();
                bootstrap.group(bossGroup, workerGroup)
                        .channel(NioServerSocketChannel.class)
                        .childHandler(new WebSocketChannelInitializer()); // 绑定管道处理器

                channelFuture = bootstrap.bind(port).sync();
                log.info("Netty WebSocket 服务器启动成功，监听端口: {}", port);

                // 等待服务端监听端口关闭
                channelFuture.channel().closeFuture().sync();
            } catch (Exception e) {
                log.error("Netty 服务启动异常", e);
            } finally {
                destroy();
            }
        }).start();
    }

    @PreDestroy
    public void destroy() {
        if (channelFuture != null) {
            channelFuture.channel().close();
        }
        bossGroup.shutdownGracefully();
        workerGroup.shutdownGracefully();
        log.info("Netty WebSocket 服务器已安全关闭");
    }
}