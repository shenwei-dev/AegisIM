package com.family.chat.controller;

import com.family.chat.common.result.ApiResponse;
import com.family.chat.dto.LoginDTO;
import com.family.chat.request.LoginRequest;
import com.family.chat.request.RegisterRequest;
import com.family.chat.service.AuthService;
import com.family.chat.util.SecurityUtil;
import com.family.chat.vo.LoginVO;
import com.family.chat.vo.RegisterVO;
import com.fasterxml.jackson.core.JsonProcessingException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;

    @PostMapping("/register")
    public ApiResponse<RegisterVO> register(@Valid @RequestBody RegisterRequest registerRequest) {
        RegisterVO registerVO = authService.register(registerRequest);
        return ApiResponse.success(registerVO);
    }


    @PostMapping("/login")
    public ApiResponse<LoginVO> login(@Valid @RequestBody LoginRequest loginRequest) throws JsonProcessingException {
        LoginDTO loginDTO = authService.login(loginRequest);
        LoginVO loginVO = new LoginVO();
        BeanUtils.copyProperties(loginDTO, loginVO);
        return ApiResponse.success(loginVO);
    }

    @PostMapping("/logout")
    public ApiResponse<Void> logout(HttpServletRequest request) {
        String authorization = request.getHeader("Authorization");
        String accessToken = authorization.replace("Bearer ", "");
        authService.logout(accessToken);
        return ApiResponse.success();
    }
}
