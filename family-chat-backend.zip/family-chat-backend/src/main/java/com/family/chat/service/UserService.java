package com.family.chat.service;

import com.family.chat.dto.SearchUserDTO;
import com.family.chat.dto.QueryUserInfoDTO;

public interface UserService {

    QueryUserInfoDTO getUserById();

    SearchUserDTO queryUserByAccount(Long account);
}
