package com.family.chat.model;

public class SearchFriendDTO {

    private Long account;

    public Long getAccount() {
        return account;
    }

    public void setAccount(Long account) {
        this.account = account;
    }
}
