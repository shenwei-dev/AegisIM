package com.family.chat.ui.home;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.family.chat.R;
import com.family.chat.ui.GroupListActivity;
import com.family.chat.ui.contact.AddFriendActivity;
import com.family.chat.ui.contact.FriendDetailActivity;
import com.family.chat.ui.contact.FriendsAdapter;
import com.family.chat.viewmodel.friends.FriendsViewModel;

public class FriendsFragment extends Fragment {

    /** 显示好友列表 */
    private RecyclerView rvFriends;

    /** "新的朋友"控件 */
    private LinearLayout layoutNewFriend;

    /** "群聊"控件 */
    private LinearLayout layoutGroupChat;

    private FriendsViewModel viewModel;

    private FriendsAdapter adapter;

    private TextView tvNewFriendUnreadCount;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_friends, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initViewModel();
        initView(view);
        initListener();
        initRecyclerView();

        loadData();
    }

    private void initView(View view) {
        rvFriends = view.findViewById(R.id.rv_contacts);
        layoutNewFriend = view.findViewById(R.id.layout_new_friend);
        layoutGroupChat = view.findViewById(R.id.layout_group_chat);
        tvNewFriendUnreadCount = view.findViewById(R.id.tv_new_friend_unread_count);
    }

    private void initViewModel() {
        viewModel = new ViewModelProvider(this).get(FriendsViewModel.class);
        viewModel.getFriendList().observe(
                getViewLifecycleOwner(), friends -> {
                    adapter.setNewData(friends);
                });

        // 监听错误
        viewModel.getErrorMessage()
                .observe(getViewLifecycleOwner(), error -> {
                    Toast.makeText(getContext(), error, Toast.LENGTH_SHORT).show();
                });
    }

    private void initListener() {
        // 为“新的朋友”设置点击监听器
        layoutNewFriend.setOnClickListener(v -> {

            // 👈 【核心重构三】：点击时，不仅隐藏当前的，还要同步将本地未读缓存清空归零！
            android.content.SharedPreferences sp = requireContext()
                    .getSharedPreferences("user_session", android.content.Context.MODE_PRIVATE);
            sp.edit().putInt("unread_friend_requests", 0).apply();

            tvNewFriendUnreadCount.setVisibility(View.GONE);

            HomeActivity homeActivity = (HomeActivity) getActivity();
            if (homeActivity != null) {
                // 物理获取底栏通讯录的红色数字气泡
                TextView tvTabContactsBadge = homeActivity.findViewById(R.id.tv_tab_contacts_badge);
                if (tvTabContactsBadge != null) {
                    tvTabContactsBadge.setVisibility(View.GONE); // 👈 设为 GONE 即可在物理上瞬间抹去底栏红点！
                }
            }

            // 跳转
            Intent intent = new Intent(getActivity(), AddFriendActivity.class);
            startActivity(intent);
        });

        // 为"群聊"设置点击监听器
        layoutGroupChat.setOnClickListener(v -> {
            // 点击后，跳转到GroupActivity(群聊列表展示界面)
            Intent intent = new Intent(getActivity(), GroupListActivity.class);
            startActivity(intent);
        });
    }

    private void initRecyclerView() {
        adapter = new FriendsAdapter();
        rvFriends.setLayoutManager(new LinearLayoutManager(getContext()));
        rvFriends.setAdapter(adapter);

        // 设置好友项的点击监听
        adapter.setOnItemClickListener((friend, position) -> {
            if (friend != null) {
                Intent intent = new Intent(getActivity(), FriendDetailActivity.class);

                // 将friend_id传递到好友详情页中
                intent.putExtra("friend_id", friend.getFriendId());

                // 跳转好友详情页
                startActivity(intent);
            }
        });
    }

    private void loadData() {
        if (viewModel != null) {
            viewModel.loadFriends();
        }
    }


    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if (!hidden) {
            loadData();
            android.util.Log.d("FriendsFragment", "通讯录页面切换为显示状态，开始更新未读数字...");
            // 👈 切换回本页面时，立即刷新红色未读数字
            updateNewFriendUnreadCount();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (!isHidden()) {
            Log.d("FriendsFragment", "onResume：页面可见，重新请求好友列表数据");
            loadData();
        }
        updateNewFriendUnreadCount();
    }

    /**
     * 【抽取为公共方法】：从底栏 Badge 中获取真实的未读数，并渲染为纯红色字体的数字
     */
    /**
     * 【重构二】：直接、安全地从本地缓存中读取未读数字，100% 稳定防失效
     */
    private void updateNewFriendUnreadCount() {
        // 读取本地存储的数字
        android.content.SharedPreferences sp = requireContext()
                .getSharedPreferences("user_session", android.content.Context.MODE_PRIVATE);

        int count = sp.getInt("unread_friend_requests", 0);
        android.util.Log.d("FriendsFragment", "【本地盘点】读取到未读新朋友数量: " + count);

        if (count > 0) {
            tvNewFriendUnreadCount.setText(String.valueOf(count));
            tvNewFriendUnreadCount.setVisibility(View.VISIBLE); // 显示纯红色数字
        } else {
            tvNewFriendUnreadCount.setVisibility(View.GONE);
        }
    }
}

