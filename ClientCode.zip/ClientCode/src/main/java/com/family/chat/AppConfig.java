package com.family.chat;

public class AppConfig {

    // 局域网测试IP
    private static final String SERVER_HOST = "10.96.11.137";

    // 本地测试IP
//    private static final String SERVER_HOST = "10.0.2.2";

    // ======================================================================
    // 1. 自动派生 HTTP 接口的基础 BaseUrl (假设您的后台 Spring Boot 端口是 8080)
    public static final String HTTP_BASE_URL = "http://" + SERVER_HOST + ":8080";

    // 2. 自动派生 WebSocket 的基础 BaseUrl (Netty 端口 8081)
    public static final String WS_BASE_URL = "wss://" + SERVER_HOST + ":8081/ws";
}
