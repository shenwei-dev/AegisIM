package com.family.chat.api;

import com.family.chat.common.ApiResponse;
import com.family.chat.model.UserLoginDTO;
import com.family.chat.model.UserLoginVO;
import com.family.chat.model.UserRegisterDTO;
import com.family.chat.model.UserRegisterVO;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

// 有关认证的Api
public interface AuthApi {

    // 注册
    @POST("/api/auth/register")
    Call<ApiResponse<UserRegisterVO>> register(@Body UserRegisterDTO userRegisterDTO);

    // 登录
    @POST("/api/auth/login")
    Call<ApiResponse<UserLoginVO>> login(@Body UserLoginDTO userLoginDTO);
}
