package com.family.chat.ui;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.family.chat.R;
import com.family.chat.adapter.ChatAdapter;
import com.family.chat.repository.ChatRepository;
import com.family.chat.repository.ChatSessionRepository;
import com.family.chat.viewmodel.ChatViewModel;
import android.content.ClipData;
import android.content.ClipboardManager;

import java.util.List;


public class ChatActivity extends AppCompatActivity {

    private LinearLayout btnChatBack;
    private TextView tvChatTitle;
    private ImageView btnChatMore;
    private RecyclerView rvMessages;
    private EditText etMessageInput;
    private AppCompatButton btnSend;
    private Long friendId;
    private ChatViewModel viewModel;
    private ChatAdapter chatAdapter;
    private ImageView btnPlus;
    private LinearLayout layoutMorePanel;
    private LinearLayout btnOptionAlbum;
    private ActivityResultLauncher<String> mGetContent;
    private ActivityResultLauncher<Intent> mPhotoPickerLauncher;
    public static Long activeChatFriendId = -1L;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 3. 👈 【核心初始化】：注册系统相册拉取协议 (Jetpack 规范)
        mGetContent = registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
            if (uri != null) {
                // 物理拿到了用户选择的图片 URI
                Log.d("ChatActivity", "用户选择的图片 URI: " + uri.toString());

                // TODO: 下一章我们可以直接将这个 uri 上传至我们的阿里云加密 OSS 桶中并发送！
                Toast.makeText(this, "成功选择图片: " + uri.toString(), Toast.LENGTH_SHORT).show();
            }
        });
        // 👈 【核心重构】：注册我们自己手写的高保真图片选择器接收通道
        mPhotoPickerLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(), result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {

                        // 1. 获取用户在自研选择器中选中的所有图片物理路径！
                        List<String> paths = (List<String>) result.getData().getSerializableExtra("selected_photos");
                        if (paths != null && !paths.isEmpty()) {
                            for (String localPath : paths) {
                                // 2. 👈 下一章：您可以直接遍历这些物理路径，调用 STS OSS 物理上传，并将图片链接发送出去！
                                Log.d("ChatDebug", "准备上传并发送本地图片: " + localPath);
                                Toast.makeText(this, "准备发送图片: " + localPath, Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                });
        setContentView(R.layout.activity_chat);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
            android.view.Window window = getWindow();
            window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
            window.addFlags(android.view.WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(android.graphics.Color.parseColor("#F3F3F3"));
            window.setNavigationBarColor(android.graphics.Color.parseColor("#F7F7F7"));
        }
        int systemUiFlags = 0;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            systemUiFlags |= android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            systemUiFlags |= android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        if (systemUiFlags != 0) {
            getWindow().getDecorView().setSystemUiVisibility(systemUiFlags);
        }

        friendId = getIntent().getLongExtra("friend_id", -1L);
        String nickname = getIntent().getStringExtra("nickname");
        String remark = getIntent().getStringExtra("remark");
        if (friendId == -1L) {
            Toast.makeText(this, "异常：未指定聊天对象", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        new ChatSessionRepository().clearUnreadCount(friendId);
        initView();
        initToolbar(nickname, remark);
        initViewModel();
        initInputListener();
    }

    /** 初始化视图 */
    private void initView() {
        btnChatBack = findViewById(R.id.btn_chat_back);
        btnPlus = findViewById(R.id.btn_plus);
        tvChatTitle = findViewById(R.id.tv_chat_title);
        btnChatMore = findViewById(R.id.btn_chat_more);
        rvMessages = findViewById(R.id.rv_messages);
        etMessageInput = findViewById(R.id.et_message_input);
        btnSend = findViewById(R.id.btn_send);
        rvMessages.setLayoutManager(new LinearLayoutManager(this));
        chatAdapter = new ChatAdapter();
        rvMessages.setAdapter(chatAdapter);
        layoutMorePanel = findViewById(R.id.layout_more_panel);
        btnOptionAlbum = findViewById(R.id.btn_option_album);
        btnChatBack.setOnClickListener(v -> finish());
        chatAdapter.setOnBubbleLongClickListener((message, view) -> {
            // 长按气泡，拉起管理菜单
            showMessageOptionsDialog(message);
        });
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);

        // 使消息重新从屏幕最顶部开始起排
        layoutManager.setStackFromEnd(false);
        rvMessages.setLayoutManager(layoutManager);

        // 键盘自适应
        rvMessages.addOnLayoutChangeListener((v, left, top, right, bottom, oldLeft, oldTop, oldRight, oldBottom) -> {
            if (bottom < oldBottom) { // 说明高度变矮（键盘弹起来了）
                rvMessages.post(() -> {
                    if (chatAdapter != null && chatAdapter.getItemCount() > 0) {
                        rvMessages.scrollToPosition(chatAdapter.getItemCount() - 1);
                    }
                });
            }
        });

        rvMessages.setLayoutManager(layoutManager);
    }

    /** 初始化ViewModel */
    private void initViewModel() {
        viewModel = new ViewModelProvider(this).get(ChatViewModel.class);
        viewModel.initChat(friendId);
        viewModel.getMessageList().observe(this, messages -> {
            if (messages != null) {
                chatAdapter.setNewData(messages);
                rvMessages.post(() -> {
                    if (chatAdapter.getItemCount() > 0) {
                        rvMessages.scrollToPosition(chatAdapter.getItemCount() - 1);
                    }
                });
            }
        });

        viewModel.getErrorMessage().observe(this, error -> {
            if (!TextUtils.isEmpty(error)) {
                Toast.makeText(this, error, Toast.LENGTH_SHORT).show();
            }
        });
    }

    /** 初始化聊天框标题栏 */
    private void initToolbar(String nickname, String remark) {
        String displayName;
        if (!TextUtils.isEmpty(remark)) {
            displayName = remark;
        } else if (!TextUtils.isEmpty(nickname)) {
            displayName = nickname;
        } else {
            displayName = "未命名好友";
        }
        tvChatTitle.setText(displayName);
        btnChatMore.setOnClickListener(v -> {
        });
    }

    /** 初始化输入框监听器 */
    private void initInputListener() {
        etMessageInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                boolean hasContent = s != null && s.toString().trim().length() > 0;
                if (hasContent) {
                    btnPlus.setVisibility(View.GONE);
                    btnSend.setVisibility(View.VISIBLE);
                    btnSend.setEnabled(true);
                    btnSend.setTextColor(Color.WHITE);
                } else {
                    btnPlus.setVisibility(View.VISIBLE);
                    btnSend.setVisibility(View.GONE);
                    btnSend.setEnabled(false);
                }
            }
            @Override
            public void afterTextChanged(Editable s) {}
        });
        etMessageInput.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) {
                rvMessages.postDelayed(() -> {
                    if (chatAdapter != null && chatAdapter.getItemCount() > 0) {
                        rvMessages.scrollToPosition(chatAdapter.getItemCount() - 1);
                    }
                }, 200);
            }
        });
        btnSend.setOnClickListener(v -> {
            String content = etMessageInput.getText().toString().trim();
            if (!TextUtils.isEmpty(content)) {
                sendMessage(content);
            }
        });
        // 5. 👈 【体验核心】：点击输入框（键盘准备弹起）时，必须【立刻强制隐藏】多媒体面板，防止视图冲突！
        etMessageInput.setOnTouchListener((v, event) -> {
            if (event.getAction() == android.view.MotionEvent.ACTION_DOWN) {
                layoutMorePanel.setVisibility(View.GONE); // 强制隐藏面板
            }
            return false;
        });

        // 6. 👈 【体验核心】：点击加号按钮时的无缝切换逻辑
        btnPlus.setOnClickListener(v -> {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);

            if (imm != null && imm.isActive(etMessageInput)) {
                layoutMorePanel.setVisibility(View.VISIBLE);
                imm.hideSoftInputFromWindow(etMessageInput.getWindowToken(), 0);
                etMessageInput.clearFocus();
                scrollChatListToBottom();
            } else {
                if (layoutMorePanel.getVisibility() == View.VISIBLE) {
                    layoutMorePanel.setVisibility(View.GONE);
                } else {
                    layoutMorePanel.setVisibility(View.VISIBLE);
                    scrollChatListToBottom();
                }
            }
        });

        // 7. 👈 【点击相册】：通过启动器一行代码安全唤起系统图库！
        btnOptionAlbum.setOnClickListener(v -> {
            layoutMorePanel.setVisibility(View.GONE); // 退出面板
            Intent intent = new Intent(ChatActivity.this, PhotoPickerActivity.class);
            mPhotoPickerLauncher.launch(intent);
        });

    }

    /** 发送聊天信息 */
    private void sendMessage(String content) {
        viewModel.sendMessage(content);
        etMessageInput.setText("");
    }

    @Override
    protected void onResume() {
        super.onResume();
        activeChatFriendId = friendId;
    }

    @Override
    protected void onPause() {
        super.onPause();
        activeChatFriendId = -1L;
        new ChatSessionRepository().clearUnreadCount(friendId);
    }

    /**
     * 2. 👈 【核心新增】：构建并弹出微信同款“复制/删除”气泡选项框
     */
    private void showMessageOptionsDialog(com.family.chat.model.ChatMessage message) {
        android.app.Dialog dialog = new android.app.Dialog(this);
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_message_options, null);

        TextView tvOptionCopy = dialogView.findViewById(R.id.tv_option_copy);
        TextView tvOptionDelete = dialogView.findViewById(R.id.tv_option_delete);

        // 【复制】动作：写入 Android 系统剪贴板
        tvOptionCopy.setOnClickListener(v -> {
            dialog.dismiss();
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (clipboard != null) {
                ClipData clip = ClipData.newPlainText("chat_msg", message.getContent());
                clipboard.setPrimaryClip(clip);
                Toast.makeText(this, "已复制", Toast.LENGTH_SHORT).show();
            }
        });

        // B. 【删除】动作：委托给 ViewModel 从 Room 本地库删除
        tvOptionDelete.setOnClickListener(v -> {
            dialog.dismiss();
            // 获取我们要删除的消息主键 ID
            Long messageId = message.getTempId();
            viewModel.deleteLocalMessage(messageId);
        });
        dialog.setContentView(dialogView);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        }
        dialog.show();
    }

    /**
     * 辅助置底
     */
    private void scrollChatListToBottom() {
        rvMessages.postDelayed(() -> {
            if (chatAdapter != null && chatAdapter.getItemCount() > 0) {
                rvMessages.scrollToPosition(chatAdapter.getItemCount() - 1);
            }
        }, 100);
    }
}