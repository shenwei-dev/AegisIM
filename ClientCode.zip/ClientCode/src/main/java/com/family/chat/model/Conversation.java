package com.family.chat.model;

/**
 * 会话实体（Conversation）
 *
 * <p>用于展示在首页“消息列表”中的对话记录。
 * 和 Friend 解耦，只表示“最近的聊天窗口”。</p>
 *
 * 字段设计参考微信/QQ：
 * - conversationId：可采用 friendId / chatId
 * - lastMessage：最近一条消息的内容
 * - lastTime：最近的消息时间戳（用于排序）
 * - unreadCount：未读消息数量
 * - top：是否置顶
 */
public class Conversation {

    /** 会话ID（单聊可直接使用 friendId） */
    private Long id;

    /** 好友ID（对应 Friend.id） */
    private Long friendId;

    /** 最近一条消息内容（文本消息内容） */
    private String lastMessage;

    /** 最近消息时间戳（毫秒，用于排序） */
    private Long lastTime;

    /** 未读消息数量 */
    private int unreadCount;

    /** 是否置顶（0 否，1 是） */
    private int top;

    /** 无参构造 */
    public Conversation() {}

    /** 全参构造 */
    public Conversation(Long id, Long friendId, String lastMessage,
                        Long lastTime, int unreadCount, int top) {
        this.id = id;
        this.friendId = friendId;
        this.lastMessage = lastMessage;
        this.lastTime = lastTime;
        this.unreadCount = unreadCount;
        this.top = top;
    }

    // Getter / Setter

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getFriendId() {
        return friendId;
    }

    public void setFriendId(Long friendId) {
        this.friendId = friendId;
    }

    public String getLastMessage() {
        return lastMessage;
    }

    public void setLastMessage(String lastMessage) {
        this.lastMessage = lastMessage;
    }

    public Long getLastTime() {
        return lastTime;
    }

    public void setLastTime(Long lastTime) {
        this.lastTime = lastTime;
    }

    public int getUnreadCount() {
        return unreadCount;
    }

    public void setUnreadCount(int unreadCount) {
        this.unreadCount = unreadCount;
    }

    public int getTop() {
        return top;
    }

    public void setTop(int top) {
        this.top = top;
    }


    @Override
    public String toString() {
        return "Conversation{" +
                "id=" + id +
                ", friendId=" + friendId +
                ", lastMessage='" + lastMessage + '\'' +
                ", lastTime=" + lastTime +
                ", unreadCount=" + unreadCount +
                ", top=" + top +
                '}';
    }
}
