package com.family.chat.ui.home;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import com.family.chat.AppConfig;
import com.family.chat.ChatApplication;
import com.family.chat.R;
import com.family.chat.databinding.ActivityHomeBinding;
import com.family.chat.db.AppDatabase;
import com.family.chat.db.LocalMessage;
import com.family.chat.db.MessageDao;
import com.family.chat.model.ChatMessage;
import com.family.chat.network.WebSocketManager;
import com.family.chat.protobuf.MessageProto;
import com.family.chat.ui.VideoCallActivity;
import com.family.chat.ui.VoiceCallActivity;
import com.family.chat.util.TokenManager;
import java.util.List;

/** 有关首页的Activity类,继承了Activity基类 */
public class HomeActivity extends AppCompatActivity {

    private ActivityHomeBinding binding;

    /** 聊天界面 */
    private ChatFragment chatFragment;

    /** 好友界面 */
    private FriendsFragment friendsFragment;

    /** 个人中心界面 */
    private MeFragment meFragment;

    /** 当前显示界面 */
    private Fragment activeFragment;

    /** 界面管理器 */
    private FragmentManager fragmentManager;

    /** Activity创建入口 */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityHomeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        // 👈 【新增】：动态向用户申请系统的通知发送权限 (针对 Android 13+)
        requestNotificationPermission();

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
            android.view.Window window = getWindow();
            window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
            window.addFlags(android.view.WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(android.graphics.Color.parseColor("#EDEDED"));
            window.setNavigationBarColor(android.graphics.Color.parseColor("#F7F7F7"));
        }
        int systemUiFlags = 0;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            systemUiFlags |= android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            systemUiFlags |= android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        if (systemUiFlags != 0) {
            getWindow().getDecorView().setSystemUiVisibility(systemUiFlags);
        }
        initFragments(savedInstanceState);
        initTabListeners();
        if (savedInstanceState == null) {
            selectTab(0);
        }
        String realToken = TokenManager.getAccessToken(ChatApplication.getContext());
        WebSocketManager.getInstance().connect(AppConfig.WS_BASE_URL + "?token=" + realToken);
        WebSocketManager.getInstance().setGlobalListener(text -> {
            android.util.Log.e("HomeActivity", ">>>>【物理接收】长连接收到原始文本: " + text);
            runOnUiThread(() -> {
                try {
                    org.json.JSONObject json = new org.json.JSONObject(text);
                    if (json.has("status") && json.has("tempId")) {
                        long tempId = json.getLong("tempId");
                        String status = json.getString("status");
                        if ("success".equals(status)) {
                            long realMessageId = json.optLong("messageId", -1L);
                            long sequence = json.optLong("sequence", 0L);
                            android.util.Log.e("HomeActivity", "sequence: " + sequence);
                            if (realMessageId != -1L) {
                                MessageDao messageDao = AppDatabase.getInstance(HomeActivity.this).messageDao();
                                LocalMessage oldMessage = messageDao.getMessageById(tempId);
                                if (oldMessage != null) {
                                    messageDao.deleteMessage(tempId);
                                    com.family.chat.db.LocalMessage newSuccessMsg = new com.family.chat.db.LocalMessage(
                                            realMessageId,
                                            oldMessage.getFriendId(),
                                            oldMessage.getContent(),
                                            oldMessage.getTimestamp(),
                                            oldMessage.isMe(),
                                            ChatMessage.STATUS_SUCCESS,
                                            sequence
                                    );
                                    messageDao.insert(newSuccessMsg);
                                    android.util.Log.e("HomeActivityDebug", "【首页全局置换成功】已将本地临时ID [" + tempId + "] 置换为真实雪花ID [" + realMessageId + "]");
                                }
                            }
                        } else {
                            MessageDao messageDao = AppDatabase.getInstance(HomeActivity.this).messageDao();
                            messageDao.updateStatus(tempId, com.family.chat.model.ChatMessage.STATUS_FAILED);
                        }

                        // 5. 如果用户此时正看着“消息首屏列表”，刷新一下会话预览
                        if (activeFragment == chatFragment && chatFragment != null) {
                            runOnUiThread(() -> chatFragment.loadChatSessions());
                        }
                        return;
                    }
                    // ==============================================================================

//                    // 1. 如果是服务器返回的 ACK 确认包，主页直接忽略不处理
//                    if (json.has("status") && json.has("tempId")) {
//                        android.util.Log.e("HomeActivity", "【业务拦截】收到的是 ACK 发送回执，主页忽略");
//                        return;
//                    }

                    // 2. 解析核心字段
                    int type = json.optInt("type", 0);
                    Long senderId = json.optLong("senderId");
                    String content = json.optString("content");

                    // 3. 👈 【无条件打印，红色高亮】：打印解析出来的 type
                    android.util.Log.e("HomeActivity", "【业务解析成功】当前消息的 Type = " + type);

                    // 1. 收到新好友通过信号（type == 7）
                    if (type == 7) {
                        runOnUiThread(() -> {
                            binding.tvTabContactsBadge.setVisibility(View.VISIBLE);
                            int current = 0;
                            String currentText = binding.tvTabContactsBadge.getText().toString();
                            if (!android.text.TextUtils.isEmpty(currentText)) {
                                current = Integer.parseInt(currentText);
                            }
                            binding.tvTabContactsBadge.setText(String.valueOf(current + 1));
                        });
                        if (activeFragment == chatFragment && chatFragment != null) {
                            runOnUiThread(() -> chatFragment.loadChatSessions());
                        }
                        return;
                    }

                    // ==================== 【新好友申请红点直推】 ====================
                    if (type == 6) {
                        android.util.Log.e("HomeActivity", "【业务流】进入 type == 6 好友申请分支");

                        int unreadCount = json.optInt("unreadCount", 1);
                        android.content.SharedPreferences sp = getSharedPreferences("user_session", MODE_PRIVATE);
                        sp.edit().putInt("unread_friend_requests", unreadCount).apply();

                        runOnUiThread(() -> {
                            binding.tvTabContactsBadge.setVisibility(View.VISIBLE);
                            binding.tvTabContactsBadge.setText(String.valueOf(unreadCount));
                        });
                        return;
                    }

                    // 3. 【核心分支 A】：拦截并处理“语音来电邀请” (type == 1)
                    if (type == 1) {
                        android.util.Log.e("HomeActivity", "【业务流】进入 type == 1 语音呼叫分支");

                        Intent intent = new Intent(HomeActivity.this, VoiceCallActivity.class);
                        intent.putExtra("friend_id", senderId);
                        intent.putExtra("is_caller", false);
                        startActivity(intent);
                        return;
                    }

                    // 4. 【核心分支 B】：拦截并处理“视频来电邀请” (type == 4)
                    if (type == 4) {
                        android.util.Log.e("HomeActivity", "【业务流】进入 type == 4 视频呼叫分支");

                        Intent intent = new Intent(HomeActivity.this, VideoCallActivity.class);
                        intent.putExtra("friend_id", senderId);
                        intent.putExtra("is_caller", false);
                        startActivity(intent);
                        return;
                    }

                    if (type == 0) {
                        // 👈 【大厂核心判定】：只有当用户“没有正处于与该发送者的聊天窗口中”时，底栏才执行 +1 递增
                        if (!senderId.equals(com.family.chat.ui.ChatActivity.activeChatFriendId)) {
                            runOnUiThread(() -> {
                                binding.tvTabChatBadge.setVisibility(View.VISIBLE);
                                int current = 0;
                                String currentText = binding.tvTabChatBadge.getText().toString();
                                if (!android.text.TextUtils.isEmpty(currentText)) {
                                    current = Integer.parseInt(currentText);
                                }
                                binding.tvTabChatBadge.setText(String.valueOf(current + 1));
                            });
                        }
                        if (activeFragment == chatFragment && chatFragment != null) {
                            runOnUiThread(() -> chatFragment.loadChatSessions());
                        }
                    }

                } catch (Exception e) {
                    // 4. 👈 【核心修复点】：如果 JSON 解析报错，确保我们能在 Logcat 中一眼抓到红色的报错堆栈
                    android.util.Log.e("HomeActivity", "❌【长连接严重报错】解析或处理消息时发生了异常!!!", e);
                }
            });
        });
        WebSocketManager.getInstance().setOnConnectionStateListener(() -> {
            runOnUiThread(this::autoResendPendingMessages);
        });
    }

    /**
     * 初始化底部导航栏Tab点击事件
     */
    private void initTabListeners() {
        // 给"聊天"Tab设置点击事件
        binding.tabChat.setOnClickListener(v -> selectTab(0));

        // 给"联系人"Tab设置点击事件
        binding.tabContacts.setOnClickListener(v -> selectTab(1));

        // 给"发现"Tab设置点击事件
        binding.tabDiscover.setOnClickListener(v -> selectTab(2));

        // 给"我"Tab设置点击事件
        binding.tabMe.setOnClickListener(v -> selectTab(3));
    }

    /**
     * 根据Tab索引切换底部导航栏页面
     */
    private void selectTab(int index) {
        // 重置所有Tab样式
        resetTabStyles();

        // 判断当前选中哪个Tab
        if (index == 0) {
            // 设置"聊天"图标选中状态
            binding.ivTabChat.setSelected(true);

            // 修改文字颜色为绿色
            binding.tvTabChat.setTextColor(Color.parseColor("#018941"));

            // 切换Fragment
            switchFragment(chatFragment);

            // 更新顶部栏
            updateToolbarUI(R.id.nav_chat);
        } else if (index == 1) {
            // 设置"通讯录"图标选中状态
            binding.ivTabContacts.setSelected(true);

            // 修改文字颜色为绿色
            binding.tvTabContacts.setTextColor(Color.parseColor("#018941"));

            // 切换Fragment
            switchFragment(friendsFragment);

            // 更新顶部栏
            updateToolbarUI(R.id.nav_contacts);
        } else if (index == 2) {
            // 设置"发现"图标选中状态
            binding.ivTabDiscover.setSelected(true);

            // 修改文字颜色为绿色
            binding.tvTabDiscover.setTextColor(Color.parseColor("#018941"));

            Toast.makeText(this, "发现模块建设中...", Toast.LENGTH_SHORT).show();
        } else if (index == 3) {
            // 设置"我"图标选中状态
            binding.ivTabMe.setSelected(true);

            // 修改文字颜色为绿色
            binding.tvTabMe.setTextColor(Color.parseColor("#018941"));

            // 切换Fragment
            switchFragment(meFragment);

            // 更新顶部栏
            updateToolbarUI(R.id.nav_me);
        }
    }

    /**
     * 重置底部导航栏所有Tab的样式为初态
     */
    private void resetTabStyles() {
        int greyColor = Color.parseColor("#1E1E1E");
        binding.ivTabChat.setSelected(false);
        binding.tvTabChat.setTextColor(greyColor);
        binding.ivTabContacts.setSelected(false);
        binding.tvTabContacts.setTextColor(greyColor);
        binding.ivTabDiscover.setSelected(false);
        binding.tvTabDiscover.setTextColor(greyColor);
        binding.ivTabMe.setSelected(false);
        binding.tvTabMe.setTextColor(greyColor);
    }

    /**
     * 处理Activity已存在情况下接收到的新Intent
     */
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleTargetIntent(intent);
    }

    /**
     * 更新顶栏的样式
     */
    private void updateToolbarUI(int destinationId) {
        binding.homeToolbar.setVisibility(View.VISIBLE);
        if (destinationId == R.id.nav_chat) {
            binding.tvTitle.setText("微信");
            setToolbarIconsVisible(true);
        } else if (destinationId == R.id.nav_contacts) {
            binding.tvTitle.setText("通讯录");
            setToolbarIconsVisible(true);
        } else if (destinationId == R.id.nav_contacts) {
            binding.tvTitle.setText("发现");
            setToolbarIconsVisible(true);
        } else {
            binding.homeToolbar.setVisibility(View.GONE);
        }
    }

    /**
     * 更新聊天Tab的未读消息角标
     */
    public void updateChatBadge(int count) {
        runOnUiThread(() -> {
            if (count > 99) {
                binding.tvTabChatBadge.setVisibility(View.VISIBLE);
                binding.tvTabChatBadge.setText("99+");
            } else if (count > 0) {
                binding.tvTabChatBadge.setVisibility(View.VISIBLE);
                binding.tvTabChatBadge.setText(String.valueOf(count));
            } else {
                binding.tvTabChatBadge.setVisibility(View.GONE);
            }
        });
    }

    private void handleTargetIntent(Intent intent) {
        if (intent != null && "friends_tab".equals(intent.getStringExtra("target_tab"))) {
            selectTab(1);
        } else {
            selectTab(0);
        }
    }

    private void setToolbarIconsVisible(boolean visible) {
        binding.btnSearch.setVisibility(visible ? View.VISIBLE : View.GONE);
        binding.btnAdd.setVisibility(visible ? View.VISIBLE : View.GONE);
    }

    /** 初始化页面 */
    private void initFragments(Bundle savedInstanceState) {
        fragmentManager = getSupportFragmentManager();

        if (savedInstanceState == null) {
            chatFragment = new ChatFragment();
            friendsFragment = new FriendsFragment();
            meFragment = new MeFragment();

            // 1. 【修改点】：将容器 ID 修改为新布局对应的 R.id.fragment_container
            fragmentManager.beginTransaction()
                    .add(R.id.fragment_container, chatFragment, "ChatFragment")
                    .commit();
            activeFragment = chatFragment;
        } else {
            chatFragment = (ChatFragment) fragmentManager.findFragmentByTag("ChatFragment");
            friendsFragment = (FriendsFragment) fragmentManager.findFragmentByTag("FriendsFragment");
            meFragment = (MeFragment) fragmentManager.findFragmentByTag("MeFragment");

            if (chatFragment != null && chatFragment.isVisible()) activeFragment = chatFragment;
            else if (friendsFragment != null && friendsFragment.isVisible()) activeFragment = friendsFragment;
            else if (meFragment != null && meFragment.isVisible()) activeFragment = meFragment;
        }
    }

    /** 切换页面 */
    private void switchFragment(Fragment targetFragment) {
        // 判断当前页面是否是目标页面
        if (activeFragment == targetFragment) {
            return;
        }

        // 开启Fragment事务
        FragmentTransaction transaction = fragmentManager.beginTransaction();

        // 判断Fragment事务是否已经加入Activity
        if (!targetFragment.isAdded()) {
            // 获取Fragment类名
            String tag = targetFragment.getClass().getSimpleName();
            // 隐藏当前Fragment, 添加目标Fragment
            transaction.hide(activeFragment).add(R.id.fragment_container, targetFragment, tag);
        } else {
            // 隐藏当前Fragment, 显示目标Fragment
            transaction.hide(activeFragment).show(targetFragment);
        }

        // 更新当前Fragment
        activeFragment = targetFragment;

        // 提交事务
        transaction.commit();
    }


    /**
     * Activity销毁时释放WebSocket连接资源
     */
    @Override
    protected void onDestroy() {
        // 调用父类的销毁逻辑
        super.onDestroy();

        // 释放WebSocket连接
        WebSocketManager.getInstance().disconnect();
    }


    /**
     * 离线积压消息自动补发算法
     */
    private void autoResendPendingMessages() {
        // 获取数据库操作对象
        MessageDao messageDao = AppDatabase.getInstance(this).messageDao();

        // 查询所有未发送成功的消息
        List<LocalMessage> pendingList = messageDao.getPendingMessages();

        // 判断有没有需要补发的消息
        if (pendingList != null && !pendingList.isEmpty()) {
            for (LocalMessage localMessage : pendingList) {
                try {
                    // 构建Proto消息
                    MessageProto.MsgFrame message = MessageProto.MsgFrame.newBuilder()
                            .setTempId(localMessage.getMessageId())
                            .setReceiverId(localMessage.getFriendId())
                            .setContent(localMessage.getContent())
                            .setType(0)
                            .build();

                    // 将Proto消息转成二进制
                    byte[] bytes = message.toByteArray();

                    // 使用WebSocket发送二进制数据
                    WebSocketManager.getInstance().sendBinary(bytes);
                } catch (Exception e) {
                    // 打印异常日志
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * 重写getResources方法, 获取当前App的资源管理对象Resources
     */
    @Override
    public android.content.res.Resources getResources() {
        // 获取Android默认的资源对象
        android.content.res.Resources resources = super.getResources();

        // 创建一个新的配置对象
        android.content.res.Configuration config = new android.content.res.Configuration();

        // 把新的配置对象设置成默认值
        config.setToDefaults();

        // 把新的配置应用到Resources
        resources.updateConfiguration(config, resources.getDisplayMetrics());

        // 返回修改后的Resources
        return resources;
    }

    /**
     * 申请 Android 13+ 必须的通知发送权限
     */
    private void requestNotificationPermission() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            if (androidx.core.content.ContextCompat.checkSelfPermission(this,
                    android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {

                // 弹出系统权限询问框
                androidx.core.app.ActivityCompat.requestPermissions(this,
                        new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 102);
            }
        }
    }
}