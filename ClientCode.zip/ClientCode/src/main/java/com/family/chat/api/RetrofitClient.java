package com.family.chat.api;

import com.family.chat.AppConfig;
import com.family.chat.ChatApplication;
import com.family.chat.interceptor.AuthInterceptor;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.converter.protobuf.ProtoConverterFactory;

// Retrofit的客户端配置
public class RetrofitClient {

    private static Retrofit retrofit;

    // 获取Retrofit实例的方法
    public static Retrofit getInstance() {
        if (retrofit == null) {
            HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
            logging.setLevel(HttpLoggingInterceptor.Level.BODY);

            // 1. 在 Android 手机本地分配一个 10MB 的物理缓存目录
            java.io.File cacheDirectory = new java.io.File(ChatApplication.getContext().getCacheDir(), "http_cache");
            okhttp3.Cache cache = new okhttp3.Cache(cacheDirectory, 10 * 1024 * 1024); // 10MB

            OkHttpClient client = new OkHttpClient.Builder()
                    .addInterceptor(logging)
                    .addInterceptor(new AuthInterceptor(ChatApplication.getContext()))
                    .connectTimeout(15, TimeUnit.SECONDS)
                    .writeTimeout(15, TimeUnit.SECONDS)
                    .readTimeout(120, TimeUnit.SECONDS)
                    .cache(cache)
                    .connectionPool(new okhttp3.ConnectionPool(10, 5, TimeUnit.MINUTES))
                    .build();

            retrofit = new Retrofit.Builder()
                    .baseUrl(AppConfig.HTTP_BASE_URL)
                    .client(client)
                    .addConverterFactory(ProtoConverterFactory.create())
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return retrofit;
    }
}
