package com.family.chat.util;

import android.content.Context;
import android.content.SharedPreferences;

public class TokenManager {

    private static final String PREF_NAME = "user_session";
    private static final String KEY_ACCESS_TOKEN = "access_token";
    private static final String KEY_REFRESH_TOKEN = "refresh_token";
    private static final String KEY_USER_ID = "user_id";
    private static final String KEY_ACCOUNT = "account";
    private static final String KEY_NICKNAME = "nickname";
    private static final String KEY_UNREAD_COUNT = "unread_count";

    private static SharedPreferences getPreferences(Context context) {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    // 保存 Token
    public static void saveTokens(Context context, String accessToken, String refreshToken, Long userId, Long account, String nickname) {
        SharedPreferences.Editor editor = getPreferences(context).edit();
        editor.putString(KEY_ACCESS_TOKEN, accessToken);
        editor.putString(KEY_REFRESH_TOKEN, refreshToken);
        editor.putString(KEY_USER_ID, String.valueOf(userId));
        editor.putString(KEY_ACCOUNT, String.valueOf(account));
        editor.putString(KEY_NICKNAME, nickname);
        editor.apply();
    }

    // 读取 AccessToken
    public static String getAccessToken(Context context) {
        return getPreferences(context).getString(KEY_ACCESS_TOKEN, "");
    }

    // 读取 RefreshToken
    public static String getRefreshToken(Context context) {
        return getPreferences(context).getString(KEY_REFRESH_TOKEN, "");
    }

    public static String getUserId(Context context) {
        return getPreferences(context).getString(KEY_USER_ID, "");
    }

    public static void clearAccessToken(Context context) {
        if (context == null) return;
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        sp.edit().remove(KEY_ACCESS_TOKEN).apply();
    }

    public static String getAccount(Context context) {
        return getPreferences(context).getString(KEY_ACCOUNT, "");
    }

    // 读取 RefreshToken
    public static String getNickname(Context context) {
        return getPreferences(context).getString(KEY_NICKNAME, "");
    }
}