package com.family.chat.repository;

import com.family.chat.api.RetrofitClient;
import com.family.chat.api.UserApi;
import com.family.chat.common.ApiResponse;
import com.family.chat.model.QueryUserInfoVO;
import com.family.chat.model.SearchUserVO;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UserRepository {

    private UserApi userApi;

    public UserRepository() {
        userApi = RetrofitClient.getInstance().create(UserApi.class);
    }

    public void queryUserInfo(UserRepository.UserCallback<ApiResponse<QueryUserInfoVO>> callback){
        userApi.getUserInfo().enqueue(
                        new Callback<ApiResponse<QueryUserInfoVO>>() {
                            @Override
                            public void onResponse(Call<ApiResponse<QueryUserInfoVO>> call, Response<ApiResponse<QueryUserInfoVO>> response){
                                handleResponse(response, callback);
                            }
                            @Override
                            public void onFailure(Call<ApiResponse<QueryUserInfoVO>> call, Throwable t){
                                callback.onFailure("网络异常");
                            }
                        });
    }


    public void searchUser(Long account, UserRepository.UserCallback<ApiResponse<SearchUserVO>> callback){
        userApi.searchUser(account).enqueue(
                new Callback<ApiResponse<SearchUserVO>>() {
                    @Override
                    public void onResponse(Call<ApiResponse<SearchUserVO>> call, Response<ApiResponse<SearchUserVO>> response){
                        handleResponse(response, callback);
                    }
                    @Override
                    public void onFailure(Call<ApiResponse<SearchUserVO>> call, Throwable t){
                        callback.onFailure("网络异常");
                    }
                });
    }

    private <T> void handleResponse(Response<ApiResponse<T>> response, UserRepository.UserCallback<ApiResponse<T>> callback){
        // 如果HTTP请求状态码为200-299
        if(response.isSuccessful() && response.body()!=null){
            ApiResponse<T> result = response.body();
            // 如果业务状态码为1000(表示请求正常)
            if(result.getCode()==1000){
                callback.onSuccess(result);
            }else{
                callback.onFailure(result.getMessage());
            }
        }else{
            callback.onFailure("服务器异常");
        }
    }

    public interface UserCallback<T>{

        void onSuccess(T response);

        void onFailure(String error);
    }
}

