package com.family.chat.ui;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Vibrator;
import android.util.Log;
import android.view.SurfaceView;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.family.chat.ChatApplication;
import com.family.chat.R;
import com.family.chat.network.WebSocketManager;
import com.family.chat.protobuf.MessageProto;
import com.family.chat.util.TokenManager;
import com.google.android.material.button.MaterialButton;

import io.agora.rtc2.Constants;
import io.agora.rtc2.IRtcEngineEventHandler;
import io.agora.rtc2.RtcEngine;
import io.agora.rtc2.RtcEngineConfig;
import io.agora.rtc2.video.VideoCanvas;
import org.json.JSONObject;

public class VideoCallActivity extends AppCompatActivity {

    private static final String TAG = "VideoCallActivity";
    private static final String AGORA_APP_ID = "5a0487b9b3494203a62b190d3d31359d";

    private TextView tvCallStatus;
    private FrameLayout containerLocalVideo;
    private FrameLayout containerRemoteVideo;

    private LinearLayout layoutRingingPanel;
    private MaterialButton btnDecline;
    private MaterialButton btnAccept;

    private LinearLayout layoutTalkingPanel;
    private MaterialButton btnMuteMic;
    private MaterialButton btnHangup;
    private MaterialButton btnSwitchCamera;
    private TextView tvMicStatus;
    private TextView tvHangupLabel;

    private Long friendId;
    private boolean isCaller;
    private RtcEngine mRtcEngine;

    private boolean isMicMuted = false;
    private Vibrator vibrator;
    private Ringtone ringtone;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_call);

        friendId = getIntent().getLongExtra("friend_id", -1L);
        isCaller = getIntent().getBooleanExtra("is_caller", false);

        requestPermissions(); // 申请麦克风 + 相机双重权限
        initView();
        initCallState();
        registerWebSocketReceiver();
    }

    private void initView() {
        tvCallStatus = findViewById(R.id.tv_call_status);
        containerLocalVideo = findViewById(R.id.container_local_video);
        containerRemoteVideo = findViewById(R.id.container_remote_video);

        layoutRingingPanel = findViewById(R.id.layout_ringing_panel);
        btnDecline = findViewById(R.id.btn_decline);
        btnAccept = findViewById(R.id.btn_accept);

        layoutTalkingPanel = findViewById(R.id.layout_talking_panel);
        btnMuteMic = findViewById(R.id.btn_mute_mic);
        btnHangup = findViewById(R.id.btn_hangup);
        btnSwitchCamera = findViewById(R.id.btn_switch_camera);

        tvMicStatus = findViewById(R.id.tv_mic_status);
        tvHangupLabel = findViewById(R.id.tv_hangup_label);

        btnDecline.setOnClickListener(v -> handleHangup());
        btnAccept.setOnClickListener(v -> handleAccept());
        btnHangup.setOnClickListener(v -> handleHangup());

        btnMuteMic.setOnClickListener(v -> toggleMicrophone());
        btnSwitchCamera.setOnClickListener(v -> {
            if (mRtcEngine != null) {
                mRtcEngine.switchCamera(); // 👈 微信功能：切换前置/后置摄像头
            }
        });
    }

    private void initCallState() {
        if (isCaller) {
            layoutRingingPanel.setVisibility(View.GONE);
            layoutTalkingPanel.setVisibility(View.VISIBLE);
            tvCallStatus.setText("等待对方接受邀请...");
            tvHangupLabel.setText("取消");
            updateMicButtonUI();

            // 1. 发送视频呼叫信令 (type = 4)
            sendSignaling(4, "请求视频通话");
        } else {
            layoutRingingPanel.setVisibility(View.VISIBLE);
            layoutTalkingPanel.setVisibility(View.GONE);
            tvCallStatus.setText("邀请你进行视频通话...");
            startRingingAndVibration();
        }
    }

    private void toggleMicrophone() {
        if (mRtcEngine == null) return;
        isMicMuted = !isMicMuted;
        mRtcEngine.muteLocalAudioStream(isMicMuted);
        updateMicButtonUI();
    }

    private void updateMicButtonUI() {
        if (!isMicMuted) {
            btnMuteMic.setBackgroundTintList(ColorStateList.valueOf(Color.WHITE));
            btnMuteMic.setIconTint(ColorStateList.valueOf(Color.parseColor("#1B1B1D")));
            tvMicStatus.setText("麦克风已开");
        } else {
            btnMuteMic.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#33FFFFFF")));
            btnMuteMic.setIconTint(ColorStateList.valueOf(Color.WHITE));
            tvMicStatus.setText("麦克风已关");
        }
    }

    private void handleAccept() {
        stopRingingAndVibration();
        layoutRingingPanel.setVisibility(View.GONE);
        layoutTalkingPanel.setVisibility(View.VISIBLE);
        tvCallStatus.setText("正在连接视频...");
        tvHangupLabel.setText("挂断");

        updateMicButtonUI();

        // 2. 发送同意视频通话信令 (type = 5)
        sendSignaling(5, "接受视频通话");
        initAgoraAndJoin();
    }

    private void handleHangup() {
        stopRingingAndVibration();
        sendSignaling(3, "挂断"); // 共享挂断信令类型
        leaveChannel();
        finish();
    }

    private void startRingingAndVibration() {
        try {
            Uri ringtoneUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
            ringtone = RingtoneManager.getRingtone(getApplicationContext(), ringtoneUri);
            if (ringtone != null) {
                ringtone.play();
            }

            vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (vibrator != null && vibrator.hasVibrator()) {
                long[] pattern = {1000, 1000, 1000, 1000};
                vibrator.vibrate(pattern, 0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void stopRingingAndVibration() {
        if (ringtone != null && ringtone.isPlaying()) {
            ringtone.stop();
        }
        if (vibrator != null) {
            vibrator.cancel();
        }
    }

    private void registerWebSocketReceiver() {
        WebSocketManager.getInstance().setChatListener(text -> {
            runOnUiThread(() -> {
                try {
                    JSONObject json = new JSONObject(text);
                    int type = json.optInt("type", 0);

                    if (type == 3) { // 挂断
                        stopRingingAndVibration();
                        Toast.makeText(this, "通话已结束", Toast.LENGTH_SHORT).show();
                        leaveChannel();
                        finish();
                    } else if (type == 5 && isCaller) { // 对方接受了视频
                        tvCallStatus.setText("正在连接视频...");
                        tvHangupLabel.setText("挂断");
                        initAgoraAndJoin();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
        });
    }

    private void initAgoraAndJoin() {
        try {
            RtcEngineConfig config = new RtcEngineConfig();
            config.mContext = getBaseContext();
            config.mAppId = AGORA_APP_ID;
            config.mEventHandler = mRtcEventHandler;

            mRtcEngine = RtcEngine.create(config);

            // 1. 【核心修改】：开启视频引擎支持
            mRtcEngine.enableVideo();
            mRtcEngine.enableAudio();
            mRtcEngine.setChannelProfile(Constants.CHANNEL_PROFILE_COMMUNICATION);

            // 2. 【核心修改】：设置并渲染本地前置摄像头视频
            SurfaceView localSurfaceView = new SurfaceView(getBaseContext());
            containerLocalVideo.addView(localSurfaceView);
            mRtcEngine.setupLocalVideo(new VideoCanvas(localSurfaceView, VideoCanvas.RENDER_MODE_HIDDEN, 0));

            long myId = getMyUserId();
            long minId = Math.min(myId, friendId);
            long maxId = Math.max(myId, friendId);
            String channelName = "room_" + minId + "_" + maxId;

            mRtcEngine.joinChannel(null, channelName, "", 0);

        } catch (Exception e) {
            Log.e(TAG, "初始化视频引擎失败", e);
        }
    }

    private final IRtcEngineEventHandler mRtcEventHandler = new IRtcEngineEventHandler() {
        @Override
        public void onJoinChannelSuccess(String channel, int uid, int elapsed) {
            runOnUiThread(() -> {
                tvCallStatus.setText("正在通话中...");
                if (mRtcEngine != null) {
                    mRtcEngine.setEnableSpeakerphone(true); // 视频通话默认强制开启免提
                }
            });
        }

        @Override
        public void onUserJoined(int uid, int elapsed) {
            // 3. 【核心修改】：当对方进入房间后，渲染对方的远端视频（全屏大窗口）
            runOnUiThread(() -> {
                Toast.makeText(VideoCallActivity.this, "通话已接通", Toast.LENGTH_SHORT).show();

                SurfaceView remoteSurfaceView = new SurfaceView(getBaseContext());
                // 对方的画面设为远端大窗口
                containerRemoteVideo.addView(remoteSurfaceView);
                mRtcEngine.setupRemoteVideo(new VideoCanvas(remoteSurfaceView, VideoCanvas.RENDER_MODE_HIDDEN, uid));
            });
        }

        @Override
        public void onUserOffline(int uid, int reason) {
            runOnUiThread(() -> {
                Toast.makeText(VideoCallActivity.this, "通话已结束", Toast.LENGTH_SHORT).show();
                handleHangup();
            });
        }
    };

    private void leaveChannel() {
        if (mRtcEngine != null) {
            mRtcEngine.leaveChannel();
            RtcEngine.destroy();
            mRtcEngine = null;
        }
    }

    private void sendSignaling(int type, String content) {
        try {
            MessageProto.MsgFrame message = MessageProto.MsgFrame.newBuilder()
                    .setType(type)
                    .setReceiverId(friendId)
                    .setContent(content)
                    .build();
            byte[] bytes = message.toByteArray();
            WebSocketManager.getInstance().sendBinary(bytes);
//            JSONObject json = new JSONObject();
//            json.put("type", type);
//            json.put("receiverId", friendId);
//            json.put("content", content);
//            WebSocketManager.getInstance().sendText(json.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void requestPermissions() {
        // 动态申请相机和麦克风权限
        String[] permissions = {Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA};
        if (ContextCompat.checkSelfPermission(this, permissions[0]) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, permissions[1]) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, permissions, 101);
        }
    }

    private Long getMyUserId() {
        Long userId = Long.valueOf(TokenManager.getUserId(ChatApplication.getContext()));
        return  userId;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopRingingAndVibration();
        leaveChannel();
        WebSocketManager.getInstance().setChatListener(null);
    }
}