package com.family.chat.ui;

public class GroupListActivity {
}
