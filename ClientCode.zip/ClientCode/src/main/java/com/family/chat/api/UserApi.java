package com.family.chat.api;

import com.family.chat.common.ApiResponse;
import com.family.chat.model.QueryUserInfoVO;
import com.family.chat.model.SearchUserVO;

import retrofit2.Call;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface UserApi {

    // 获取用户信息
    @POST("/api/user/info")
    Call<ApiResponse<QueryUserInfoVO>> getUserInfo();

    // 查询用户
    @POST("/api/user/search/{account}")
    Call<ApiResponse<SearchUserVO>> searchUser(@Path("account") Long account);

    @POST("/api/auth/logout")
    Call<ApiResponse<Void>> logout();
}
