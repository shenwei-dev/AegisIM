package com.family.chat.viewmodel.friends;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.family.chat.common.ApiResponse;
import com.family.chat.model.FriendVO;
import com.family.chat.repository.FriendRepository;
import java.util.List;

public class FriendsViewModel extends ViewModel {

    private final FriendRepository repository;

    private final MutableLiveData<List<FriendVO>> friendList = new MutableLiveData<>();

    private final MutableLiveData<String> errorMessage = new MutableLiveData<>();

    public FriendsViewModel() {
        repository = new FriendRepository();
    }

    public LiveData<List<FriendVO>> getFriendList(){
        return friendList;
    }

    public LiveData<String> getErrorMessage(){
        return errorMessage;
    }

    public void loadFriends(){
        repository.getFriendList(
                new FriendRepository.FriendCallback<ApiResponse<List<FriendVO>>>() {
                    @Override
                    public void onSuccess(ApiResponse<List<FriendVO>> response) {
                        friendList.postValue(response.getData());
                    }
                    @Override
                    public void onFailure(String error){
                        errorMessage.postValue(error);
                    }
                }
        );
    }

}
