package com.family.chat.ui;

import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Vibrator;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.family.chat.ChatApplication;
import com.family.chat.R;
import com.family.chat.network.WebSocketManager;
import com.family.chat.protobuf.MessageProto;
import com.family.chat.util.TokenManager;
import com.google.android.material.button.MaterialButton;

import io.agora.rtc2.Constants;
import io.agora.rtc2.IRtcEngineEventHandler;
import io.agora.rtc2.RtcEngine;
import io.agora.rtc2.RtcEngineConfig;
import org.json.JSONObject;

public class VoiceCallActivity extends AppCompatActivity {

    private static final String TAG = "VoiceCallActivity";
    private static final String AGORA_APP_ID = "5a0487b9b3494203a62b190d3d31359d";

    private TextView tvCallStatus;
    private TextView tvCallName;
    private ImageView ivCallAvatar;
    private ImageView ivMinimize;

    // 来电响铃面板
    private LinearLayout layoutRingingPanel;
    private MaterialButton btnDecline;
    private MaterialButton btnAccept;

    // 通话中面板
    private LinearLayout layoutTalkingPanel;
    private MaterialButton btnMuteMic;
    private MaterialButton btnHangup;
    private MaterialButton btnToggleSpeaker;

    // 微信高保真标签文本
    private TextView tvMicStatus;
    private TextView tvSpeakerStatus;
    private TextView tvHangupLabel;

    private Long friendId;
    private boolean isCaller;
    private RtcEngine mRtcEngine;

    // 默认微信通话状态
    private boolean isMicMuted = false;       // 默认开启麦克风（麦克风已开）
    private boolean isSpeakerOn = false;       // 👈 微信默认使用听筒（扬声器已关，符合您的截图效果）

    private Vibrator vibrator;
    private Ringtone ringtone;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_voice_call);

        friendId = getIntent().getLongExtra("friend_id", -1L);
        isCaller = getIntent().getBooleanExtra("is_caller", false);
        String nickname = getIntent().getStringExtra("nickname"); // 可选：传入昵称

        requestMicrophonePermission();
        initView();
        initToolbar(nickname);
        initCallState();
        registerWebSocketReceiver();
    }

    private void initView() {
        tvCallStatus = findViewById(R.id.tv_call_status);
        tvCallName = findViewById(R.id.tv_call_name);
        ivCallAvatar = findViewById(R.id.iv_call_avatar);
        ivMinimize = findViewById(R.id.iv_minimize);

        layoutRingingPanel = findViewById(R.id.layout_ringing_panel);
        btnDecline = findViewById(R.id.btn_decline);
        btnAccept = findViewById(R.id.btn_accept);

        layoutTalkingPanel = findViewById(R.id.layout_talking_panel);
        btnMuteMic = findViewById(R.id.btn_mute_mic);
        btnHangup = findViewById(R.id.btn_hangup);
        btnToggleSpeaker = findViewById(R.id.btn_toggle_speaker);

        // 绑定底部的 TextView 标签
        tvMicStatus = findViewById(R.id.tv_mic_status);
        tvSpeakerStatus = findViewById(R.id.tv_speaker_status);
        tvHangupLabel = findViewById(R.id.tv_hangup_label);

        // 点击事件
        btnDecline.setOnClickListener(v -> handleHangup());
        btnAccept.setOnClickListener(v -> handleAccept());
        btnHangup.setOnClickListener(v -> handleHangup());
        ivMinimize.setOnClickListener(v -> finish()); // 缩小窗口返回上一页

        btnMuteMic.setOnClickListener(v -> toggleMicrophone());
        btnToggleSpeaker.setOnClickListener(v -> toggleSpeakerphone());
    }

    private void initToolbar(String nickname) {
        if (nickname != null) {
            tvCallName.setText(nickname);
        } else {
            tvCallName.setText("未命名好友");
        }
    }

    private void initCallState() {
        if (isCaller) {
            layoutRingingPanel.setVisibility(View.GONE);
            layoutTalkingPanel.setVisibility(View.VISIBLE);
            tvCallStatus.setText("等待对方接受邀请...");
            tvHangupLabel.setText("取消"); // 👈 微信规范：呼叫等待中，中间显示为“取消”

            // 初始化按钮状态颜色
            updateMicButtonUI();
            updateSpeakerButtonUI();

            sendSignaling(1, "请求语音通话");
        } else {
            layoutRingingPanel.setVisibility(View.VISIBLE);
            layoutTalkingPanel.setVisibility(View.GONE);
            tvCallStatus.setText("邀请你进行语音通话...");
            startRingingAndVibration();
        }
    }

    /**
     * 控制麦克风静音切换
     */
    private void toggleMicrophone() {
        if (mRtcEngine == null) return;
        isMicMuted = !isMicMuted;
        mRtcEngine.muteLocalAudioStream(isMicMuted);
        updateMicButtonUI();
    }

    private void updateMicButtonUI() {
        if (!isMicMuted) {
            // 麦克风已开：白色背景 + 黑色图标
            btnMuteMic.setBackgroundTintList(ColorStateList.valueOf(Color.WHITE));
            btnMuteMic.setIconTint(ColorStateList.valueOf(Color.parseColor("#1B1B1D")));
            tvMicStatus.setText("麦克风已开");
        } else {
            // 麦克风已关：暗色半透明背景 + 白色图标
            btnMuteMic.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#33FFFFFF")));
            btnMuteMic.setIconTint(ColorStateList.valueOf(Color.WHITE));
            tvMicStatus.setText("麦克风已关");
        }
    }

    /**
     * 控制扬声器免提切换
     */
    private void toggleSpeakerphone() {
        if (mRtcEngine == null) return;
        isSpeakerOn = !isSpeakerOn;
        mRtcEngine.setEnableSpeakerphone(isSpeakerOn);
        updateSpeakerButtonUI();
    }

    private void updateSpeakerButtonUI() {
        if (isSpeakerOn) {
            // 扬声器已开（免提）：白色背景 + 黑色图标
            btnToggleSpeaker.setBackgroundTintList(ColorStateList.valueOf(Color.WHITE));
            btnToggleSpeaker.setIconTint(ColorStateList.valueOf(Color.parseColor("#1B1B1D")));
            tvSpeakerStatus.setText("扬声器已开");
        } else {
            // 扬声器已关（听筒）：暗色半透明背景 + 白色图标
            btnToggleSpeaker.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#33FFFFFF")));
            btnToggleSpeaker.setIconTint(ColorStateList.valueOf(Color.WHITE));
            tvSpeakerStatus.setText("扬声器已关");
        }
    }

    private void handleAccept() {
        stopRingingAndVibration();
        layoutRingingPanel.setVisibility(View.GONE);
        layoutTalkingPanel.setVisibility(View.VISIBLE);
        tvCallStatus.setText("正在连接语音...");
        tvHangupLabel.setText("挂断"); // 👈 微信规范：接通后，中间选项文案变更为“挂断”

        updateMicButtonUI();
        updateSpeakerButtonUI();

        sendSignaling(2, "接受语音通话");
        initAgoraAndJoin();
    }

    private void handleHangup() {
        stopRingingAndVibration();
        sendSignaling(3, "挂断");
        leaveChannel();
        finish();
    }

    private void startRingingAndVibration() {
        try {
            Uri ringtoneUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
            ringtone = RingtoneManager.getRingtone(getApplicationContext(), ringtoneUri);
            if (ringtone != null) {
                ringtone.play();
            }

            vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (vibrator != null && vibrator.hasVibrator()) {
                long[] pattern = {1000, 1000, 1000, 1000};
                vibrator.vibrate(pattern, 0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void stopRingingAndVibration() {
        if (ringtone != null && ringtone.isPlaying()) {
            ringtone.stop();
        }
        if (vibrator != null) {
            vibrator.cancel();
        }
    }

    private void registerWebSocketReceiver() {
        WebSocketManager.getInstance().setChatListener(text -> {
            runOnUiThread(() -> {
                try {
                    JSONObject json = new JSONObject(text);
                    int type = json.optInt("type", 0);

                    if (type == 3) {
                        stopRingingAndVibration();
                        Toast.makeText(this, "通话已结束", Toast.LENGTH_SHORT).show();
                        leaveChannel();
                        finish();
                    } else if (type == 2 && isCaller) {
                        tvCallStatus.setText("正在连接语音...");
                        tvHangupLabel.setText("挂断"); // 接听后变更为挂断
                        initAgoraAndJoin();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
        });
    }

    private void initAgoraAndJoin() {
        try {
            RtcEngineConfig config = new RtcEngineConfig();
            config.mContext = getBaseContext();
            config.mAppId = AGORA_APP_ID;
            config.mEventHandler = mRtcEventHandler;

            mRtcEngine = RtcEngine.create(config);
            mRtcEngine.setChannelProfile(Constants.CHANNEL_PROFILE_COMMUNICATION);

            long myId = getMyUserId();
            long minId = Math.min(myId, friendId);
            long maxId = Math.max(myId, friendId);
            String channelName = "room_" + minId + "_" + maxId;

            mRtcEngine.joinChannel(null, channelName, "", 0);

        } catch (Exception e) {
            Log.e(TAG, "初始化声网失败", e);
        }
    }

    private final IRtcEngineEventHandler mRtcEventHandler = new IRtcEngineEventHandler() {
        @Override
        public void onJoinChannelSuccess(String channel, int uid, int elapsed) {
            runOnUiThread(() -> {
                tvCallStatus.setText("正在通话中...");
                if (mRtcEngine != null) {
                    mRtcEngine.setEnableSpeakerphone(isSpeakerOn); // 微信默认听筒，此值为 false
                    mRtcEngine.adjustPlaybackSignalVolume(200);
                    mRtcEngine.adjustRecordingSignalVolume(200);
                }
            });
        }

        @Override
        public void onUserJoined(int uid, int elapsed) {
            runOnUiThread(() -> Toast.makeText(VoiceCallActivity.this, "通话已接通", Toast.LENGTH_SHORT).show());
        }

        @Override
        public void onUserOffline(int uid, int reason) {
            runOnUiThread(() -> {
                Toast.makeText(VoiceCallActivity.this, "通话已结束", Toast.LENGTH_SHORT).show();
                handleHangup();
            });
        }
    };

    private void leaveChannel() {
        if (mRtcEngine != null) {
            mRtcEngine.leaveChannel();
            RtcEngine.destroy();
            mRtcEngine = null;
        }
    }

    private void sendSignaling(int type, String content) {
        try {
            MessageProto.MsgFrame message = MessageProto.MsgFrame.newBuilder()
                    .setType(type)
                    .setReceiverId(friendId)
                    .setContent(content)
                    .build();
            byte[] bytes = message.toByteArray();
            WebSocketManager.getInstance().sendBinary(bytes);
//
//            JSONObject json = new JSONObject();
//            json.put("type", type);
//            json.put("receiverId", friendId);
//            json.put("content", content);
//            WebSocketManager.getInstance().sendText(json.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void requestMicrophonePermission() {
        if (androidx.core.content.ContextCompat.checkSelfPermission(this,
                android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            androidx.core.app.ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.RECORD_AUDIO}, 101);
        }
    }

    private Long getMyUserId() {
        Long userId = Long.valueOf(TokenManager.getUserId(ChatApplication.getContext()));
        return userId;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopRingingAndVibration();
        leaveChannel();
        WebSocketManager.getInstance().setChatListener(null);
    }
}