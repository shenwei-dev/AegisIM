package com.family.chat;

import android.app.Application;
import android.content.Context;

public class ChatApplication extends Application {

    private static Context context;

    @Override
    public void onCreate() {
        super.onCreate();
        // 保存全局的 ApplicationContext，此 Context 的生命周期与应用一致，不会产生内存泄漏
        context = getApplicationContext();
    }

    /**
     * 获取全局 Context 的静态方法
     */
    public static Context getContext() {
        return context;
    }
}
