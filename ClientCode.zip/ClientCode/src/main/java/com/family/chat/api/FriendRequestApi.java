package com.family.chat.api;

import com.family.chat.common.ApiResponse;
import com.family.chat.model.QueryFriendRequestListVO;
import com.family.chat.model.SearchFriendVO;
import com.family.chat.model.SendFriendRequestDTO;
import com.family.chat.model.UserRegisterDTO;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface FriendRequestApi {

    // 发送好友请求
    @POST("/api/friend_request/send")
    Call<ApiResponse<Void>> sendFriendRequest(@Body SendFriendRequestDTO sendFriendRequestDTO);

    @GET("/api/friend_request/list")
    Call<ApiResponse<List<QueryFriendRequestListVO>>> getFriendRequestList();

    // 发送好友请求
    @POST("/api/friend_request/accept/{id}")
    Call<ApiResponse<Void>> acceptFriendRequest(@Path("id") Long id);
}
