package com.family.chat.util;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import com.family.chat.R;
import com.family.chat.ui.ChatActivity;
import com.family.chat.ui.contact.AddFriendActivity;

public class NotificationHelper {

    private static final String CHANNEL_CHAT_ID = "chat_messages";      // 消息渠道 ID
    private static final String CHANNEL_FRIEND_ID = "friend_requests";  // 好友申请渠道 ID

    private static final int NOTIFICATION_CHAT_ID = 1001;
    private static final int NOTIFICATION_FRIEND_ID = 1002;

    /**
     * 1. 初始化创建通知渠道 (Android 8.0+ 物理必须)
     */
    public static void createNotificationChannels(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager manager = context.getSystemService(NotificationManager.class);
            if (manager != null) {
                // A. 聊天消息渠道 (高优先级：支持屏幕顶部横幅弹出)
                NotificationChannel chatChannel = new NotificationChannel(
                        CHANNEL_CHAT_ID,
                        "聊天消息",
                        NotificationManager.IMPORTANCE_HIGH
                );
                chatChannel.setDescription("用于接收并弹出好友发来的即时聊天消息");

                // B. 好友申请渠道 (高优先级：支持屏幕顶部横幅弹出)
                NotificationChannel friendChannel = new NotificationChannel(
                        CHANNEL_FRIEND_ID,
                        "好友申请",
                        NotificationManager.IMPORTANCE_HIGH
                );
                friendChannel.setDescription("用于接收新好友添加申请通知");

                manager.createNotificationChannel(chatChannel);
                manager.createNotificationChannel(friendChannel);
            }
        }
    }

    /**
     * 2. 👈 【核心方法一】：弹出微信同款聊天消息横幅通知
     */
    public static void showChatNotification(Context context, Long senderId, String senderName, String content) {
        // 确保通知渠道已创建
        createNotificationChannels(context);

        // 微信级规范：点击通知直接跳转到与该好友的 ChatActivity，并清空中间栈
        Intent intent = new Intent(context, ChatActivity.class);
        intent.putExtra("friend_id", senderId);
        intent.putExtra("nickname", senderName);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);

        // 处理 Android 12+ 的 PendingIntent 安全强类型 Flag 兼容性
        int pendingFlags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            pendingFlags |= PendingIntent.FLAG_IMMUTABLE;
        }

        // 使用发送者 ID 作为 requestCode，防止不同好友的通知点击发生跳转混淆
        PendingIntent pendingIntent = PendingIntent.getActivity(
                context, (int) (long) senderId, intent, pendingFlags);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_CHAT_ID)
                .setSmallIcon(R.drawable.ic_tab_chat) // 使用我们精致的微信小图标
                .setContentTitle(senderName)          // 标题显示发送人姓名
                .setContentText(content)              // 内容显示聊天文本
                .setPriority(NotificationCompat.PRIORITY_HIGH) // 强行设为高优先级，支持顶部悬浮横幅
                .setDefaults(NotificationCompat.DEFAULT_ALL)   // 开启默认的声音和震动
                .setAutoCancel(true)                  // 点击后通知自动消失
                .setContentIntent(pendingIntent);

        try {
            NotificationManagerCompat.from(context).notify(NOTIFICATION_CHAT_ID, builder.build());
        } catch (SecurityException e) {
            e.printStackTrace();
        }
    }

    /**
     * 3. 👈 【核心方法二】：弹出微信同款新好友申请横幅通知
     */
    public static void showFriendRequestNotification(Context context, String senderName, String greeting) {
        createNotificationChannels(context);

        // 点击通知直接跳转到“新的朋友（AddFriendActivity）”页面
        Intent intent = new Intent(context, AddFriendActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);

        int pendingFlags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            pendingFlags |= PendingIntent.FLAG_IMMUTABLE;
        }
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, intent, pendingFlags);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_FRIEND_ID)
                .setSmallIcon(R.drawable.ic_tab_contacts)
                .setContentTitle("新的朋友")
                .setContentText(senderName + " 申请添加您为好友: " + greeting)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent);

        try {
            NotificationManagerCompat.from(context).notify(NOTIFICATION_FRIEND_ID, builder.build());
        } catch (SecurityException e) {
            e.printStackTrace();
        }
    }
}