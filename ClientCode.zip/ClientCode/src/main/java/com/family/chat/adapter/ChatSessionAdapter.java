package com.family.chat.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.family.chat.R;
import com.family.chat.model.ChatSessionVO;
import com.family.chat.util.FontUtil;

import java.util.ArrayList;
import java.util.List;

public class ChatSessionAdapter extends RecyclerView.Adapter<ChatSessionAdapter.SessionViewHolder> {

    private List<ChatSessionVO> dataList = new ArrayList<>();
    private OnItemClickListener itemClickListener;
    private OnItemLongClickListener itemLongClickListener;

    public interface OnItemClickListener {
        void onItemClick(ChatSessionVO session);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.itemClickListener = listener;
    }

    public void setNewData(List<ChatSessionVO> list) {
        this.dataList = list != null ? list : new ArrayList<>();
        notifyDataSetChanged();
    }

    public interface OnItemLongClickListener {
        void onItemLongClick(ChatSessionVO session, View view);
    }

    public void setOnItemLongClickListener(OnItemLongClickListener listener) {
        this.itemLongClickListener = listener;
    }


    @NonNull
    @Override
    public SessionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_chat_session, parent, false);
        return new SessionViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SessionViewHolder holder, int position) {
        ChatSessionVO item = dataList.get(position);
        if (item == null) return;

        holder.tvSessionTitle.setText(item.getDisplayName()); // 备注或昵称
        String lastMessage = item.getLastMessage();
        // 👈 替换传统的 setText，改用微信同款居中省略号工具方法
        FontUtil.setWeChatStyleEllipsize(holder.tvSessionLastMsg, lastMessage);
//        holder.tvSessionLastMsg.setText(item.getLastMessage());
        holder.tvSessionTime.setText(item.getFormatTime()); // 格式化后的时间，如 20:25

        // 👈 【核心控制】：处理头像右上角未读红色数字气泡
        if (item.getUnreadCount() > 0) {
            holder.tvUnreadBadge.setVisibility(View.VISIBLE);
            holder.tvUnreadBadge.setText(String.valueOf(item.getUnreadCount()));
        } else {
            holder.tvUnreadBadge.setVisibility(View.GONE);
        }

        if (item.getFriendId() != null && item.getFriendId().equals(99999L)) {
            holder.ivSessionAvatar.setImageResource(R.drawable.ic_chat_ai_avatar);
        } else {
            // 普通好友的头像加载
            holder.ivSessionAvatar.setImageResource(android.R.drawable.sym_def_app_icon);

            // if (item.getAvatar() != null) Glide...
        }

        // 点击会话项跳转到聊天页
        holder.itemView.setOnClickListener(v -> {
            if (itemClickListener != null) {
                itemClickListener.onItemClick(item);
            }
        });

        holder.itemView.setOnLongClickListener(v -> {
            if (itemLongClickListener != null) {
                itemLongClickListener.onItemLongClick(item, v);
                return true;
            }
            return false;
        });

        // 加载会话头像
        // Glide.with(holder.itemView.getContext()).load(item.getAvatar()).into(holder.ivSessionAvatar);
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    static class SessionViewHolder extends RecyclerView.ViewHolder {
        ImageView ivSessionAvatar;
        TextView tvUnreadBadge;
        TextView tvSessionTitle;
        TextView tvSessionLastMsg;
        TextView tvSessionTime;

        public SessionViewHolder(@NonNull View view) {
            super(view);
            ivSessionAvatar = view.findViewById(R.id.iv_session_avatar);
            tvUnreadBadge = view.findViewById(R.id.tv_unread_badge);
            tvSessionTitle = view.findViewById(R.id.tv_session_title);
            tvSessionLastMsg = view.findViewById(R.id.tv_session_last_msg);
            tvSessionTime = view.findViewById(R.id.tv_session_time);
        }
    }
}