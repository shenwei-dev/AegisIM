package com.family.chat.model;

public class SearchFriendVO {
}
