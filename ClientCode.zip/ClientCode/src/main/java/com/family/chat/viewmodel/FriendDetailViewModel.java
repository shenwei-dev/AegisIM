package com.family.chat.viewmodel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.family.chat.common.ApiResponse;
import com.family.chat.model.FriendDetailVO;
import com.family.chat.repository.FriendRepository;

public class
FriendDetailViewModel extends ViewModel {

    private final MutableLiveData<FriendDetailVO> friendDetail = new MutableLiveData<>();
    private final MutableLiveData<String> errorMessage = new MutableLiveData<>();
    private final MutableLiveData<Boolean> isLoading = new MutableLiveData<>();
    private final FriendRepository friendRepository = new FriendRepository();

    public LiveData<FriendDetailVO> getFriendDetail() {
        return friendDetail;
    }

    public LiveData<String> getErrorMessage() {
        return errorMessage;
    }

    public LiveData<Boolean> getIsLoading() {
        return isLoading;
    }

    /**
     * 根据好友 ID 查询好友详细信息
     * @param friendId 好友ID (Long类型，对应您的API接口定义)
     */
    public void loadFriendDetail(Long friendId) {
        if (friendId == null) {
            errorMessage.setValue("好友ID不能为空");
            return;
        }

        isLoading.setValue(true);
        friendRepository.getFriendDetail(friendId, new FriendRepository.FriendCallback<ApiResponse<FriendDetailVO>>() {
            @Override
            public void onSuccess(ApiResponse<FriendDetailVO> response) {
                // 将加载状态设置为false
                isLoading.setValue(false);

                // 将好友详情信息存储到MutableLiveData容器中
                friendDetail.setValue(response.getData());
            }

            @Override
            public void onFailure(String error) {
                isLoading.setValue(false);
                errorMessage.setValue(error != null ? error : "请求发生异常");
            }
        });
    }
}