package com.family.chat.db;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "local_message")
public class LocalMessage {

    @PrimaryKey
    @NonNull
    @ColumnInfo(name = "message_id")
    private Long messageId;

    @ColumnInfo(name = "friend_id")
    private Long friendId;

    @ColumnInfo(name = "content")
    private String content;

    @ColumnInfo(name = "timestamp")
    private long timestamp;

    @ColumnInfo(name = "is_me")
    private boolean isMe;

    @ColumnInfo(name = "send_status")
    private int sendStatus;

    @ColumnInfo(name = "sequence")
    private long sequence; // 物理存储服务端的连续序号

    public LocalMessage(@NonNull Long messageId, Long friendId, String content, long timestamp, boolean isMe, int sendStatus, long sequence) {
        this.messageId = messageId;
        this.friendId = friendId;
        this.content = content;
        this.timestamp = timestamp;
        this.isMe = isMe;
        this.sendStatus = sendStatus;
        this.sequence = sequence;
    }

    // Getters and Setters...
    @NonNull
    public Long getMessageId() { return messageId; }
    public void setMessageId(@NonNull Long messageId) { this.messageId = messageId; }
    public Long getFriendId() { return friendId; }
    public void setFriendId(Long friendId) { this.friendId = friendId; }
    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }
    public boolean isMe() { return isMe; }
    public void setMe(boolean me) { isMe = me; }
    public int getSendStatus() { return sendStatus; }
    public void setSendStatus(int sendStatus) { this.sendStatus = sendStatus; }
    public long getSequence() {
        return sequence;
    }
    public void setSequence(long sequence) {
        this.sequence = sequence;
    }
}