package com.family.chat.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.family.chat.R;
import com.family.chat.model.ChatMessage;
import java.util.ArrayList;
import java.util.List;

public class ChatAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    /** 消息类型 -> 对方发送的 */
    private static final int TYPE_RECEIVE = 0;

    /** 消息类型 -> 我发送的 */
    private static final int TYPE_SEND = 1;

    private List<ChatMessage> dataList = new ArrayList<>();

    /** 气泡长按监听器 */
    private OnBubbleLongClickListener bubbleLongClickListener;

    public interface OnBubbleLongClickListener {
        void onBubbleLongClick(ChatMessage message, View view);
    }

    public void setOnBubbleLongClickListener(OnBubbleLongClickListener listener) {
        this.bubbleLongClickListener = listener;
    }
    /**
     * 更新数据源
     */
    public void setNewData(List<ChatMessage> list) {
        this.dataList = list != null ? list : new ArrayList<>();
        notifyDataSetChanged();
    }

    @Override
    public int getItemViewType(int position) {
        ChatMessage message = dataList.get(position);
        // 根据 isMe 字段决定加载哪种布局
        return message.isMe() ? TYPE_SEND : TYPE_RECEIVE;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == TYPE_SEND) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_chat_send, parent, false);
            return new SendViewHolder(view);
        } else {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_chat_receive, parent, false);
            return new ReceiveViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ChatMessage message = dataList.get(position);

        if (holder instanceof SendViewHolder) {
            SendViewHolder sendHolder = (SendViewHolder) holder;
            sendHolder.tvContent.setText(message.getContent());

            // 为我发送的绿色气泡文本框绑定长按事件
            sendHolder.tvContent.setOnLongClickListener(v -> {
                if (bubbleLongClickListener != null) {
                    bubbleLongClickListener.onBubbleLongClick(message, v);
                    return true;
                }
                return false;
            });

            // 处理发送状态的渲染
            int status = message.getSendStatus();
            if (status == ChatMessage.STATUS_SENDING) {
                sendHolder.progressBar.setVisibility(View.VISIBLE);  // 显示转圈
                sendHolder.ivError.setVisibility(View.GONE);         // 隐藏红点
            } else if (status == ChatMessage.STATUS_FAILED) {
                sendHolder.progressBar.setVisibility(View.GONE);     // 隐藏转圈
                sendHolder.ivError.setVisibility(View.VISIBLE);      // 显示红点
            } else {
                sendHolder.progressBar.setVisibility(View.GONE);     // 隐藏转圈
                sendHolder.ivError.setVisibility(View.GONE);         // 隐藏红点
            }

        } else if (holder instanceof ReceiveViewHolder) {
            ReceiveViewHolder receiveHolder = (ReceiveViewHolder) holder;
            receiveHolder.tvContent.setText(message.getContent());

            // 为对方发送的白色气泡文本框绑定长按事件
            receiveHolder.tvContent.setOnLongClickListener(v -> {
                if (bubbleLongClickListener != null) {
                    bubbleLongClickListener.onBubbleLongClick(message, v);
                    return true;
                }
                return false;
            });
            if (message.getReceiverId() != null && message.getReceiverId().equals(99999L)) {
                receiveHolder.ivAvatar.setImageResource(R.drawable.ic_chat_ai_avatar);
            } else {
                // 如果是普通人类好友发来的，加载其对应的头像（此处用系统默认图标代替）
                receiveHolder.ivAvatar.setImageResource(android.R.drawable.sym_def_app_icon);

                // 如果您集成了 Glide，可以解开：
                // Glide.with(context).load(message.getFriendAvatar()).into(receiveHolder.ivAvatar);
            }
            // 对方发送的消息没有发送状态（默认都是成功的）
        }
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    // ==================== ViewHolder 定义 ====================

    /**
     * 右侧：我发送的消息 ViewHolder
     */
    static class SendViewHolder extends RecyclerView.ViewHolder {
        TextView tvContent;
        ImageView ivAvatar;
        ProgressBar progressBar; // 发送中的菊花转圈
        ImageView ivError;       // 发送失败的红色感叹号

        public SendViewHolder(@NonNull View view) {
            super(view);
            tvContent = view.findViewById(R.id.tv_send_content);
            ivAvatar = view.findViewById(R.id.iv_send_avatar);
            progressBar = view.findViewById(R.id.progress_sending);
            ivError = view.findViewById(R.id.iv_send_error);
        }
    }

    /**
     * 左侧：对方发送的消息 ViewHolder
     */
    static class ReceiveViewHolder extends RecyclerView.ViewHolder {
        TextView tvContent;
        ImageView ivAvatar;

        public ReceiveViewHolder(@NonNull View view) {
            super(view);
            tvContent = view.findViewById(R.id.tv_receive_content);
            ivAvatar = view.findViewById(R.id.iv_receive_avatar);
        }
    }

}
