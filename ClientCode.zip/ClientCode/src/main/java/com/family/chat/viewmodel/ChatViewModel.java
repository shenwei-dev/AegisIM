package com.family.chat.viewmodel;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.family.chat.ChatApplication;
import com.family.chat.db.AppDatabase;
import com.family.chat.db.LocalMessage;
import com.family.chat.db.MessageDao;
import com.family.chat.model.ChatMessage;
import com.family.chat.protobuf.MessageProto;
import com.family.chat.repository.ChatRepository;
import com.family.chat.util.SnowflakeIdGenerator;
import com.family.chat.util.TokenManager;

import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class ChatViewModel extends ViewModel {

    /** 数据访问层对象 */
    private final ChatRepository chatRepository;

    /** 本地数据库-数据访问层对象 */
    private final MessageDao messageDao;

    /** 当前好友ID */
    private Long currentFriendId;

    /** 存放聊天消息 */
    private final MutableLiveData<List<ChatMessage>> messageList = new MutableLiveData<>(new ArrayList<>());

    /** 存放异常信息 */
    private final MutableLiveData<String> errorMessage = new MutableLiveData<>();

    private final MutableLiveData<Boolean> isLoading = new MutableLiveData<>(false);


    /** 空参构造初始化 */
    public ChatViewModel() {
        this.chatRepository = new ChatRepository();
        this.messageDao = AppDatabase.getInstance(ChatApplication.getContext()).messageDao();
    }

    /** Getter */
    public MutableLiveData<List<ChatMessage>> getMessageList() {
        return messageList;
    }
    public MutableLiveData<String> getErrorMessage() {
        return errorMessage;
    }

    /**
     * 初始化聊天上下文，启动连接，注册接收监听
     */
    public void initChat(Long friendId) {
        this.currentFriendId = friendId;
        registerReceiver();
        loadLocalAndSyncCloud();
    }

    /**
     * 【重构修复】：发送消息时强制先写入本地数据库
     */
    public void sendMessage(String content) {
        // 如果好友ID为空,那么直接返回
        if (currentFriendId == null) {
            return;
        }

        // 如果是跟智能助手(99999L)聊，协议指令设为 8；如果是普通人，指令设为 0
        int messageType = currentFriendId.equals(99999L) ? 8 : 0;

        // 本地生成消息的临时ID
        Long tempId = SnowflakeIdGenerator.getInstance().nextId();

        // 将临时消息封装成LocalMessage对象
        LocalMessage localMessage = new LocalMessage(
                tempId,
                currentFriendId,
                content,
                System.currentTimeMillis(),
                true,
                ChatMessage.STATUS_SENDING,
                -1L
        );

        // 写入本地Room数据库
        messageDao.insert(localMessage);

        // 如果用户是在和智能体机器人对话
        if (currentFriendId == 99999) {
            // 将机器人思考的信息封装成LocalMessage对象
            LocalMessage thinkingMessage = new LocalMessage(
                    -1L,
                    currentFriendId,
                    "...",
                    System.currentTimeMillis() + 1, // 时间戳 +1，确保排在我的提问下方
                    false,
                    ChatMessage.STATUS_SENDING,
                    -999L
            );
            messageDao.insert(thinkingMessage);
        }

        refreshMessageListFromLocal();

        // 通过WebSocket连接发送消息
        chatRepository.sendMessage(currentFriendId, tempId, content, messageType);
    }

    private void registerReceiver() {
        // 注册消息接收器
        chatRepository.registerMessageReceiver(jsonText -> {
            try {
                android.util.Log.e("ChatDebug", "我执行了");
                android.util.Log.e("ChatDebug", "【物理接收】原始 JSON 数据 = " + jsonText);
                JSONObject json = new JSONObject(jsonText);
                if (json.has("status") && json.has("tempId")) {
                    Long tempId = json.getLong("tempId");
                    String status = json.getString("status");
                    android.util.Log.e("ChatDebug", "消息的状态为" + status);
                    if ("success".equals(status)) {
                        long sequence = json.optLong("sequence", 0L);
                        long realMsgId = json.optLong("messageId", 0L); // 拿到后端分发的真实雪花 ID
                        android.util.Log.e("ChatDebug", "realMsgId = " + realMsgId);
                        // 开始执行“删旧插新”置换
                        if (realMsgId != 0L) {
                            // A. 查出本地原先那条处于“发送中”的临时消息
                            LocalMessage oldMsg = messageDao.getMessageById(tempId);
                            if (oldMsg != null) {
                                android.util.Log.e("ChatDebug", "删除临时消息: " + oldMsg.getContent());
                                // 本地数据库删除临时消息
                                messageDao.deleteMessage(tempId);

                                // 使用真实消息ID封装LocalMessage对象
                                LocalMessage newSuccessMsg = new LocalMessage(
                                        realMsgId, //
                                        oldMsg.getFriendId(),
                                        oldMsg.getContent(),
                                        oldMsg.getTimestamp(),
                                        oldMsg.isMe(),
                                        ChatMessage.STATUS_SUCCESS,
                                        sequence
                                );

                                android.util.Log.e("ChatDebug", "插入新消息: " + newSuccessMsg.getContent());
                                // 将真实消息插入到本地数据库
                                messageDao.insert(newSuccessMsg);
                                android.util.Log.e("ChatDebug", "【发送成功】已将本地临时ID [" + tempId + "] 置换为真实雪花ID [" + realMsgId + "]");
                            }
                        }
                    } else {
                        messageDao.updateStatus(tempId, ChatMessage.STATUS_FAILED);
                    }
                    refreshMessageListFromLocal();
                    return;
                }

                // ==================== 【视频/语音通话拦截逻辑】 ====================
                // 获取消息类型
                int type = json.optInt("type", 0);

                // 获取发送者ID
                Long senderId = json.optLong("senderId");

                // 拦截并处理“语音通话邀请”
                if (type == 1) {
                    android.util.Log.d("ChatViewModel", "拦截到语音通话邀请，正在拉起语音接听界面...");
                    android.content.Context context = com.family.chat.ChatApplication.getContext();
                    android.content.Intent intent = new android.content.Intent(context, com.family.chat.ui.VoiceCallActivity.class);
                    intent.putExtra("friend_id", senderId);
                    intent.putExtra("is_caller", false);
                    intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                    return;
                }

                // 拦截并忽略挂断信号
                if (type == 3) {
                    return;
                }

                // 拦截并处理“视频通话邀请”
                if (type == 4) {
                    android.util.Log.d("ChatViewModel", "拦截到视频通话邀请，正在拉起视频接听界面...");
                    android.content.Context context = com.family.chat.ChatApplication.getContext();
                    android.content.Intent intent = new android.content.Intent(context, com.family.chat.ui.VideoCallActivity.class);
                    intent.putExtra("friend_id", senderId);
                    intent.putExtra("is_caller", false);
                    intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                    return;
                }

                // ==================================================================
                boolean isChunk = json.optBoolean("isChunk", false); // 获取是否是流式碎片包
                long messageId = json.optLong("messageId", 0L);
                String chunkContent = json.optString("content");

                // 如果是流式碎片包
                if (isChunk) {
                    long sequence = json.optLong("sequence", 0L);
                    appendStreamChunk(messageId, chunkContent, sequence);
                }

                // 获取消息内容
                String content = json.optString("content");

                // 获取时间
                long timestamp = json.optLong("timestamp");

                // 消息ID保底
                if (messageId == 0L) {
                    messageId = SnowflakeIdGenerator.getInstance().nextId();
                    android.util.Log.e("ChatDebug", "⚠️ 警告：接收消息时后端未传 messageId，已自动使用本地 UUID 保底: " + messageId);
                }

                // 判断是不是当前聊天对象
                long sequence = json.optLong("sequence", 0L);

                android.util.Log.e("ChatDebug", "sequence" + jsonText);
                if (senderId.equals(currentFriendId)) {
                    // 创建本地消息对象
                    LocalMessage incomingLocalMsg = new LocalMessage(
                            messageId,
                            currentFriendId,
                            content,
                            timestamp,
                            false, // isMe = false
                            ChatMessage.STATUS_SUCCESS,
                            sequence
                    );

                    // 写入本地数据库
                    messageDao.insert(incomingLocalMsg);
                    android.util.Log.e("ChatDebug", "【接收消息】已成功存入本地数据库，ID: " + messageId);

                    // 刷新 UI
                    refreshMessageListFromLocal();
                }

            } catch (Exception e) {
                android.util.Log.e("ChatDebug", "❌【接收器严重崩溃】处理接收消息时发生异常!!!", e);
            }
        });
    }

    @Override
    protected void onCleared() {
        super.onCleared();
    }

    // 从 Room 本地数据库重新读取当前好友的聊天记录，然后转换成 UI 能显示的数据，通知界面刷新
    private void refreshMessageListFromLocal() {
        // 从数据库查询聊天记录
        List<LocalMessage> localList = messageDao.getChatHistory(currentFriendId);

        // 打印数据库当前状态
        android.util.Log.e("ChatDebug", "【本地盘点】当前内存列表刷新，从 Room 数据库中查出的消息总数为: " + localList.size());

        // 创建UI数据列表
        List<ChatMessage> convertedList = new ArrayList<>();

        // 遍历数据库消息
        for (LocalMessage local : localList) {
            android.util.Log.e("ChatDebug", "数据: " + local.getContent() + "-" + "messageId" + local.getMessageId());
            convertedList.add(new ChatMessage(
                    local.getMessageId(),
                    currentFriendId,
                    local.getContent(),
                    local.getTimestamp(),
                    local.getSendStatus(),
                    local.isMe()
            ));
        }

        // 通知页面刷新
        messageList.postValue(convertedList);
    }

    private void appendStreamChunk(Long messageId, String chunk, Long sequence) {
        android.util.Log.e("ChatDebug", "执行appendStreamChunk");
        // 获取消息列表(聊天记录)
        List<ChatMessage> currentList = messageList.getValue();

        // 如果消息列表为空,则new一个
        if (currentList == null) {
            currentList = new ArrayList<>();
        }

        // 1. 查找内存中是否已经存在该条正在打字的消息
        ChatMessage activeMsg = null;
        int activeIndex = -1;
        for (int i = 0; i < currentList.size(); i++) {
            ChatMessage msg = currentList.get(i);
            if (messageId.equals(msg.getTempId())) {
                activeMsg = msg;
                activeIndex = i;
                break;
            }
        }

        List<ChatMessage> newList = new ArrayList<>(currentList);

        if (activeMsg != null) {
            android.util.Log.e("ChatDebug", "activeMsg已经存在");
            // 情况 A：如果已经存在，直接在内存中追加字符，不写数据库！速度极快！
            activeMsg.setContent(activeMsg.getContent() + chunk);
            newList.set(activeIndex, activeMsg);
        } else {
            android.util.Log.e("ChatDebug", "activeMsg不存在");
            // 情况 B：如果是第一个字符，先清理本地数据库和内存中的“思考中...”占位符，再创建新消息
            messageDao.deleteMessage(-1L); // 物理删除数据库占位
            newList.removeIf(msg -> -1L == msg.getTempId()); // 剔除内存占位

            activeMsg = new ChatMessage(
                    messageId, // 接收消息不需要临时ID
                    currentFriendId,
                    chunk, // 第一个字
                    System.currentTimeMillis(),
                    ChatMessage.STATUS_SUCCESS,
                    false // 不是我发送的
            );
            newList.add(activeMsg);
        }

        // 更新聊天记录
        messageList.postValue(newList);

        LocalMessage localMessage = new LocalMessage(
                activeMsg.getTempId(),
                activeMsg.getReceiverId(),
                activeMsg.getContent(),
                activeMsg.getTimestamp(),
                activeMsg.isMe(),
                activeMsg.getSendStatus(),
                sequence
        );
        android.util.Log.e("ChatDebug", "插入AI信息" + localMessage.getMessageId());
        messageDao.insert(localMessage);
    }

    /**
     * 👈 【大厂核心算法】：基于滑动窗口计算本地持续可达的高水位线 (Watermark)
     * @param recentMessageList 降序排列的最近 100 条消息
     */
    private long calculateLastContinuousSeq(List<LocalMessage> recentMessageList) {
        // 如果本地Room数据库没有缓存聊天记录,那么返回0
        if (recentMessageList == null || recentMessageList.isEmpty()) {
            return 0L;
        }
        for (int i = recentMessageList.size() - 1; i > 0; i--) {
            long currentSeq = recentMessageList.get(i).getSequence();
            long messageId = recentMessageList.get(i).getMessageId();
            android.util.Log.e("ChatDebug", "当前序号" + currentSeq + recentMessageList.get(i).getContent());
            android.util.Log.e("ChatDebug", "当前messageId" + messageId + recentMessageList.get(i).getContent());
            long nextSeq = recentMessageList.get(i - 1).getSequence();
            if (nextSeq != currentSeq + 1) {
                android.util.Log.e("ChatDebug", "【空洞检测】本地数据在序号 [" + currentSeq + "] 和 [" + nextSeq + "] 之间产生断层！");
                return currentSeq;
            }
        }
        return recentMessageList.get(0).getSequence();
    }

    /**
     * 【高水位线增量自愈同步】：本地优先加载 + 云端增量拉取
     */
    private void loadLocalAndSyncCloud() {
        refreshMessageListFromLocal();
        List<LocalMessage> recentMessageList = messageDao.getRecentMessagesForGapCheck(currentFriendId);
        long watermarkSeq = calculateLastContinuousSeq(recentMessageList);
        android.util.Log.e("ChatDebug", "【高水位线计算成功】当前 Watermark = " + watermarkSeq);
        chatRepository.syncDeltaMessages(currentFriendId, watermarkSeq, new ChatRepository.ChatCallback<MessageProto.QueryHistoryResponse>() {
            @Override
            public void onSuccess(MessageProto.QueryHistoryResponse response) {
                android.util.Log.e("ChatDebug", "执行onsuccess方法");
                isLoading.postValue(false);
                if (response != null && response.getCode() == 1000 && response.getDataList() != null) {
                    android.util.Log.e("ChatDebug", "响应体不为空");
                    List<MessageProto.MsgFrame> serverList = response.getDataList();
                    if (serverList.isEmpty()) return;
                    Long myUserId = Long.valueOf(TokenManager.getUserId(ChatApplication.getContext()));
                    // 将增量数据存入 Room 数据库（如果之前收过了，Room会自动覆盖去重）
                    for (MessageProto.MsgFrame serverMsg : serverList) {
                        boolean isMe = serverMsg.getSenderId() == myUserId;
                        LocalMessage localMessage = new LocalMessage(
                                serverMsg.getMessageId(),
                                currentFriendId,
                                serverMsg.getContent(),
                                serverMsg.getTimestamp(),
                                isMe,
                                ChatMessage.STATUS_SUCCESS,
                                serverMsg.getSequence()
                        );
                        messageDao.insert(localMessage);
                    }

                    // 再次刷新 UI
                    refreshMessageListFromLocal();
                }
            }

            @Override
            public void onFailure(String error) {
                android.util.Log.e("ChatDebug", "执行onFailure方法");
                android.util.Log.e("ChatDebug", error);
                isLoading.postValue(false);
                errorMessage.postValue("增量同步失败: " + error);
            }
        });
    }

    /**
     * 根据消息 ID 物理删除本地 Room 缓存
     */
    public void deleteLocalMessage(Long messageId) {
        if (messageId == null) {
            android.util.Log.e("ChatViewModel", "【本地消息物理删除失败】消息ID: null");
            return;
        }
        // 在本地数据库中执行物理删除
        messageDao.deleteMessage(messageId);

        // 刷新内存列表并分发给ChatActivity
        refreshMessageListFromLocal();
        android.util.Log.e("ChatViewModel", "【本地消息物理删除成功】消息ID: " + messageId);
    }
}