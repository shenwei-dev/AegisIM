package com.family.chat.api;

import com.family.chat.common.ApiResponse;
import com.family.chat.model.FriendDetailVO;
import com.family.chat.model.FriendVO;
import com.family.chat.model.SearchFriendVO;
import java.util.List;
import retrofit2.Call;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import retrofit2.http.Query;

// 有关好友的Api
public interface FriendApi {

    // 查询好友
    @GET("/api/friends/search")
    Call<ApiResponse<List<SearchFriendVO>>> searchFriend(
            @Query("keyword") String keyword
    );

    // 添加好友
    @POST("/api/friends/add")
    Call<ApiResponse<Void>> addFriend(
            @Query("account") Long account
    );

    // 删除好友
    @DELETE("/api/friends/delete/{friendId}")
    Call<ApiResponse<Void>> deleteFriend(
            @Path("friendId") Long friendId
    );

    // 查询好友列表
    @GET("/api/friends/list")
    Call<ApiResponse<List<FriendVO>>> getFriendList();

    // 修改好友备注
    @PUT("/api/friends/remark")
    Call<ApiResponse<Void>> updateFriendRemark(
            @Query("account") Long account,
            @Query("remark") String remark
    );

    /** 查询好友详细信息 */
    @GET("/api/friends/detail/{friendId}")
    Call<ApiResponse<FriendDetailVO>> getFriendDetail(@Path("friendId") Long friendId);
}

