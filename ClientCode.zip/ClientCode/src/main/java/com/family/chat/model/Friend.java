package com.family.chat.model;

import androidx.annotation.NonNull;

/**
 * 联系人信息实体类（大厂规范）
 *
 * <p>该类用于描述一个联系人（好友）的基础信息，
 * 仅包含长期稳定的用户资料，不包含消息或会话相关字段。</p>
 *
 * 字段说明：
 * - id：本地数据库自增ID或雪花ID
 * - userCode：用户唯一标识码（类似微信号，可作为查询 key）
 * - displayName：对方的昵称（用户自己设置的名称）
 * - alias：备注名（优先展示）
 * - avatarUrl：头像地址
 */
public class Friend {

    /** 本地或服务端生成的全局唯一ID */
    private Long id;

    /** 用户唯一标识（类似微信号，可搜索用） */
    private String userCode;

    /** 对方的昵称（用户自己设置的昵称） */
    private String displayName;

    /** 备注名（如果为空则显示昵称） */
    private String alias;

    /** 头像 URL */
    private String avatarUrl;

    /** 构造方法 - 无参 */
    public Friend() {}

    /** 全参构造方法 */
    public Friend(Long id, String userCode, String displayName, String alias, String avatarUrl) {
        this.id = id;
        this.userCode = userCode;
        this.displayName = displayName;
        this.alias = alias;
        this.avatarUrl = avatarUrl;
    }

    // ------------------------
    // Getter / Setter
    // ------------------------

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUserCode() {
        return userCode;
    }

    public void setUserCode(String userCode) {
        this.userCode = userCode;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public String getAvatarUrl() {
        return avatarUrl;
    }

    public void setAvatarUrl(String avatarUrl) {
        this.avatarUrl = avatarUrl;
    }

    /**
     * 获取用于界面展示的最终名称。
     * <p>规则：优先显示备注 alias，没有备注则显示 displayName。</p>
     */
    @NonNull
    public String getShowName() {
        return (alias != null && !alias.isEmpty()) ? alias :
                (displayName != null ? displayName : "");
    }

    @Override
    public String toString() {
        return "Friend{" +
                "id=" + id +
                ", userCode='" + userCode + '\'' +
                ", displayName='" + displayName + '\'' +
                ", alias='" + alias + '\'' +
                ", avatarUrl='" + avatarUrl + '\'' +
                '}';
    }
}
