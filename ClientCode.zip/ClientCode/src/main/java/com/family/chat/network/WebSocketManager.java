package com.family.chat.network;

import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;
import androidx.annotation.NonNull;

import com.family.chat.protobuf.MessageProto;

import java.security.SecureRandom;
import java.security.cert.X509Certificate;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;

public class WebSocketManager {
    private static final String TAG = "WebSocketManager";
    private static WebSocketManager instance;

    private final Handler heartbeatHandler = new Handler(Looper.getMainLooper());
    private static final int HEARTBEAT_INTERVAL_MS = 30000; // 30秒心跳间隔

    private final OkHttpClient client;
    private WebSocket mWebSocket;

    private OnMessageReceivedListener globalListener;
    private OnMessageReceivedListener chatListener;
    // 1. 👈 【新增】：声明连接状态监听器
    private OnConnectionStateListener connectionStateListener;
    // ==================== 【新增：自动重连核心组件】 ====================
    private String mUrl;                               // 保存连接 URL，以便重连使用
    private boolean isManualClose = false;             // 是否是用户手动断开（如退出登录）
    private static final int RECONNECT_DELAY_MS = 5000; // 每次自动重连的等待间隔：5秒
    private final Handler reconnectHandler = new Handler(Looper.getMainLooper());
    // ==================================================================

    public interface OnMessageReceivedListener {
        void onMessageReceived(String text);
    }
    public interface OnConnectionStateListener {
        void onConnected();
    }

    public void setOnConnectionStateListener(OnConnectionStateListener listener) {
        this.connectionStateListener = listener;
    }

    private WebSocketManager() {
        // 👈 【核心修复一】：构建一个“信任所有证书”的垃圾证书管理器，专门用于开发调试
        final TrustManager[] trustAllCerts = new TrustManager[]{
                new X509TrustManager() {
                    @Override
                    public void checkClientTrusted(X509Certificate[] chain, String authType) {}

                    @Override
                    public void checkServerTrusted(X509Certificate[] chain, String authType) {}

                    @Override
                    public X509Certificate[] getAcceptedIssuers() {
                        return new X509Certificate[]{};
                    }
                }
        };

        try {
            // 2. 👈 【核心修复二】：初始化 SSL 上下文
            SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, trustAllCerts, new SecureRandom());
            SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

            // 3. 👈 【核心修复三】：为 OkHttpClient 挂载忽略安全校验的 SocketFactory 与域名验证器
            client = new OkHttpClient.Builder()
                    .sslSocketFactory(sslSocketFactory, (X509TrustManager) trustAllCerts[0])
                    .hostnameVerifier((hostname, session) -> true) // 忽略 IP 和域名的匹配校验，直接放行
                    .build();

            Log.d(TAG, ">>>> [WSS 客户端] 忽略 SSL 校验器配置成功，支持直连自签名服务端 <<<<");

        } catch (Exception e) {
            Log.e(TAG, "构建免密 SSL 客户端发生异常", e);
            throw new RuntimeException(e);
        }
    }

    public static synchronized WebSocketManager getInstance() {
        if (instance == null) {
            instance = new WebSocketManager();
        }
        return instance;
    }

    public void setGlobalListener(OnMessageReceivedListener listener) {
        this.globalListener = listener;
    }

    public void setChatListener(OnMessageReceivedListener listener) {
        this.chatListener = listener;
    }

    /**
     * 建立连接
     */
    public void connect(String url) {
        this.mUrl = url;
        this.isManualClose = false; // 每次新连接时，重置手动关闭状态

        if (mWebSocket != null) {
            Log.d(TAG, "WebSocket 已经连接，无需重复连接");
            return;
        }

        Request request = new Request.Builder().url(url).build();
        mWebSocket = client.newWebSocket(request, new WebSocketListener() {
            @Override
            public void onOpen(@NonNull WebSocket webSocket, @NonNull Response response) {
                Log.d(TAG, ">>>> WebSocket 物理长连接建立成功 <<<<");
                reconnectHandler.removeCallbacks(reconnectRunnable);
                heartbeatHandler.postDelayed(heartbeatRunnable, HEARTBEAT_INTERVAL_MS);
                if (connectionStateListener != null) {
                    connectionStateListener.onConnected();
                }
            }

            @Override
            public void onMessage(@NonNull WebSocket webSocket,  @NonNull okio.ByteString bytes) {
                try {
                    byte[] byteArray = bytes.toByteArray();
                    MessageProto.MsgFrame protoMsg = MessageProto.MsgFrame.parseFrom(byteArray);
                    Log.d(TAG, ">>>> [Protobuf 物理接收成功] 内容: " + protoMsg.getContent());
                    org.json.JSONObject mockJson = new org.json.JSONObject();
                    if (!TextUtils.isEmpty(protoMsg.getStatus())) {
                        mockJson.put("status", protoMsg.getStatus());
                        mockJson.put("tempId", protoMsg.getTempId());
                        mockJson.put("senderId", protoMsg.getSenderId());
                        mockJson.put("messageId", protoMsg.getMessageId());
                        mockJson.put("sequence", protoMsg.getSequence());
                    } else {
                        mockJson.put("type", protoMsg.getType());
                        mockJson.put("senderId", protoMsg.getSenderId());
                        mockJson.put("messageId", protoMsg.getMessageId());
                        mockJson.put("content", protoMsg.getContent());
                        mockJson.put("timestamp", protoMsg.getTimestamp());
                        mockJson.put("sequence", protoMsg.getSequence());
                    }
                    if (chatListener != null) chatListener.onMessageReceived(mockJson.toString());
                    if (globalListener != null) globalListener.onMessageReceived(mockJson.toString());

                } catch (Exception e) {
                    Log.e(TAG, "解析 Protobuf 二进制失败", e);
                }

            }

            @Override
            public void onClosed(@NonNull WebSocket webSocket, int code, @NonNull String reason) {
                Log.d(TAG, "WebSocket 已安全关闭: " + reason);
                mWebSocket = null;
                tryReconnect();
            }

            @Override
            public void onFailure(@NonNull WebSocket webSocket, @NonNull Throwable t, Response response) {
                Log.e(TAG, "WebSocket 发生连接异常或网络断开: " + t.getMessage());
                mWebSocket = null;
                tryReconnect();
                heartbeatHandler.removeCallbacks(heartbeatRunnable);
            }
        });
    }

    /**
     * 自动重连控制逻辑
     */
    private void tryReconnect() {
        // 如果是用户主动点击退出登录，或者手动关闭连接，绝对不能重连
        if (isManualClose) {
            Log.d(TAG, "用户手动断开连接或已登出，停止自动重连。");
            return;
        }

        Log.d(TAG, "网络异常断开，准备在 " + (RECONNECT_DELAY_MS / 1000) + " 秒后尝试自动重连...");

        // 移除队列里可能重复积压的重连任务，保证同一时间只有一个重连线程在运行
        reconnectHandler.removeCallbacks(reconnectRunnable);
        // 延迟执行重连，防止因服务器宕机导致客户端无限高频建连引发“重连风暴”
        reconnectHandler.postDelayed(reconnectRunnable, RECONNECT_DELAY_MS);
    }

    /**
     * 负责重连的线程任务
     */
    private final Runnable reconnectRunnable = new Runnable() {
        @Override
        public void run() {
            Log.d(TAG, "正在发起自动重连...");
            if (mUrl != null) {
                connect(mUrl);
            }
        }
    };

    /**
     * 手动/正常断开连接（如用户退出登录、App被销毁）
     */
    public void disconnect() {
        Log.d(TAG, "调用了手动断开连接");
        this.isManualClose = true; // 标记为手动关闭，切断自动重连机制
        heartbeatHandler.removeCallbacks(heartbeatRunnable);
        // 清空重连队列
        reconnectHandler.removeCallbacks(reconnectRunnable);

        if (mWebSocket != null) {
            mWebSocket.close(1000, "Normal closure");
            mWebSocket = null;
        }
    }

    public void sendText(String jsonText) {
        if (mWebSocket != null) mWebSocket.send(jsonText);
    }

    /**
     * 👈 【新增】：通过 WebSocket 物理长连接发送二进制字节流 (Protobuf 数据)
     * @param bytes 已经通过 Protobuf 序列化后的二进制字节数组
     */
    public void sendBinary(byte[] bytes) {
        if (mWebSocket != null && bytes != null) {
            try {
                okio.ByteString byteString = okio.ByteString.of(bytes);
                mWebSocket.send(byteString);
            } catch (Exception e) {
                Log.e(TAG, "发送二进制数据异常", e);
            }
        } else {
            Log.e(TAG, "物理发送失败：WebSocket 未建立连接，或数据为空！");
        }
    }

    // 定义心跳包的任务线程
    private final Runnable heartbeatRunnable = new Runnable() {
        @Override
        public void run() {
            Log.d(TAG, "正在往 Netty 发送心跳 Ping 包...");
            // 发送操作码为 99 的极简心跳包
            sendText("{\"type\":99,\"content\":\"Ping\"}");

            // 循环定时
            heartbeatHandler.postDelayed(this, HEARTBEAT_INTERVAL_MS);
        }
    };


}