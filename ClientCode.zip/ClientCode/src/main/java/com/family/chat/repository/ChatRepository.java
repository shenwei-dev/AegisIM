package com.family.chat.repository;

import android.os.Handler;
import android.os.Looper;
import com.family.chat.api.MessageApi;
import com.family.chat.api.RetrofitClient;
import com.family.chat.network.WebSocketManager;
import com.family.chat.protobuf.MessageProto;

import java.util.List;

public class ChatRepository {

    private final MessageApi messageApi;

    private final WebSocketManager webSocketManager;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    public interface OnNewMessageListener {
        void onNewMessage(String jsonText);
    }

    public ChatRepository() {
        messageApi = RetrofitClient.getInstance().create(MessageApi.class);
        this.webSocketManager = WebSocketManager.getInstance();
    }

    public void sendMessage(Long receiverId, Long tempId, String content, Integer messageType) {
        try {
            MessageProto.MsgFrame message = MessageProto.MsgFrame.newBuilder()
                    .setTempId(tempId)
                    .setReceiverId(receiverId)
                    .setContent(content)
                    .setType(messageType)
                    .build();
            byte[] bytes = message.toByteArray();
            webSocketManager.sendBinary(bytes);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public interface ChatCallback<T>{

        void onSuccess(T response);

        void onFailure(String error);
    }

    public void registerMessageReceiver(OnNewMessageListener listener) {
        // 指向专用的 chatListener
        webSocketManager.setChatListener(text -> {
            mainHandler.post(() -> {
                if (listener != null) {
                    listener.onNewMessage(text);
                }
            });
        });
    }

    /**
     * 通过网络请求拉取高水位线之后的增量消息数据
     * @param friendId 好友ID
     * @param localMaxSeq 本地算出的当前高水位线 (watermark)
     */
    public void syncDeltaMessages(Long friendId, Long localMaxSeq, final ChatCallback<MessageProto.QueryHistoryResponse> callback) {
        messageApi.syncDeltaMessages(friendId, localMaxSeq).enqueue(new retrofit2.Callback<>() {
            @Override
            public void onResponse(retrofit2.Call<MessageProto.QueryHistoryResponse> call, retrofit2.Response<MessageProto.QueryHistoryResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    callback.onSuccess(response.body());
                } else {
                    callback.onFailure("同步增量记录失败");
                }
            }

            @Override
            public void onFailure(retrofit2.Call<MessageProto.QueryHistoryResponse> call, Throwable t) {
                callback.onFailure(t.getMessage());
            }
        });
    }
}
