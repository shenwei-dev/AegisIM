package com.family.chat.ui.home;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;

import com.family.chat.ChatApplication;
import com.family.chat.R;
import com.family.chat.api.FriendApi;
import com.family.chat.api.RetrofitClient;
import com.family.chat.api.UserApi;
import com.family.chat.common.ApiResponse;
import com.family.chat.network.WebSocketManager;
import com.family.chat.ui.ChatActivity;
import com.family.chat.ui.ProfileDetailActivity;
import com.family.chat.ui.auth.LoginActivity;
import com.family.chat.util.TokenManager;
import com.google.android.material.imageview.ShapeableImageView;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MeFragment extends Fragment {

    private ConstraintLayout layoutProfileHeader;
    private ShapeableImageView ivProfileAvatar;
    private TextView tvProfileNickname;
    private TextView tvProfileWechatId;
    private final UserApi userApi;
    private ConstraintLayout layoutAiAssistant;
    private ConstraintLayout layoutSettings;
    public MeFragment() {
        this.userApi = RetrofitClient.getInstance().create(UserApi.class);
    }
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // 加载重构后的微信风格 xml 布局
        return inflater.inflate(R.layout.fragment_me, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initView(view);
        initData();
        initListener();
    }

    private void initView(View view) {
        layoutProfileHeader = view.findViewById(R.id.layout_profile_header);
        ivProfileAvatar = view.findViewById(R.id.iv_profile_avatar);
        tvProfileNickname = view.findViewById(R.id.tv_profile_nickname);
        tvProfileWechatId = view.findViewById(R.id.tv_profile_wechat_id);

        layoutAiAssistant = view.findViewById(R.id.layout_ai_assistant);
        layoutSettings = view.findViewById(R.id.layout_settings);
    }

    /**
     * 自动从本地缓存加载我自己的昵称和微信号并渲染
     */
    private void initData() {
        Long account = Long.valueOf(TokenManager.getAccount(ChatApplication.getContext()));
        String nickname = TokenManager.getNickname(ChatApplication.getContext());

        tvProfileNickname.setText(nickname);

        if (account != null) {
            tvProfileWechatId.setText("微信号: " + account);
        }

        // 提示：此处可以使用 Glide 加载我的真实头像
        // Glide.with(this).load(myAvatarUrl).into(ivProfileAvatar);
    }

    private void initListener() {
        layoutProfileHeader.setOnClickListener(v -> {
            // 点击个人卡片，跳转到个人资料设置页
            Intent intent = new Intent(getActivity(), ProfileDetailActivity.class);
            startActivity(intent);
        });

        // 智能助手点击事件
        layoutAiAssistant.setOnClickListener(v -> {
            // 一键拉起聊天页
            Intent intent = new Intent(getActivity(), ChatActivity.class);

            // 👈 核心参数：传入 AI 助手的全局系统 ID 和昵称
            intent.putExtra("friend_id", 99999L);
            intent.putExtra("nickname", "智能助手");

            startActivity(intent);
        });

        // 设置点击事件（对标微信：可在此处执行退出登录、彻底下线逻辑）
        layoutSettings.setOnClickListener(v -> {
            handleLogout();
        });
    }

    private void handleLogout() {
        // 1. 向后端发起 HTTP 请求通知下线（大模型和 Netty 通道异步处理）
        userApi.logout().enqueue(new Callback<ApiResponse<Void>>() {
            @Override
            public void onResponse(Call<ApiResponse<Void>> call, Response<ApiResponse<Void>> response) {
                // 无论网络返回成功还是失败，客户端都执行本地物理退登 (容灾设计)
                executeLocalLogout();
            }

            @Override
            public void onFailure(Call<ApiResponse<Void>> call, Throwable t) {
                // 网络异常（断网）时，依然强制执行本地物理退登
                executeLocalLogout();
            }
        });
    }

    /**
     * 👈 【大厂级客户端退登控制链】
     */
    private void executeLocalLogout() {
        WebSocketManager.getInstance().disconnect();
        TokenManager.clearAccessToken(requireContext());
        SharedPreferences sp = requireContext().getSharedPreferences("user_session", Context.MODE_PRIVATE);
        sp.edit().clear().apply();
        Intent intent = new Intent(getActivity(), LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        if (getActivity() != null) {
            getActivity().finish();
        }
    }
}
