package com.family.chat.model;


public class ChatMessage {
    private Long tempId;     // 本地临时ID
    private Long receiverId;   // 接收者 ID (好友ID)
    private String content;    // 消息内容
    private long timestamp;    // 发送时间戳 (本地)
    private int sendStatus;    // 状态：0-发送中，1-成功，2-失败
    private boolean isMe;      // 新增：是否由当前登录账户发送 (true 为右侧绿色气泡，false 为左侧白色气泡)

    public static final int STATUS_SENDING = 0;
    public static final int STATUS_SUCCESS = 1;
    public static final int STATUS_FAILED = 2;

    // 修改构造函数：引入 isMe
    public ChatMessage(Long tempId, Long receiverId, String content, long timestamp, int sendStatus, boolean isMe) {
        this.tempId = tempId;
        this.receiverId = receiverId;
        this.content = content;
        this.timestamp = timestamp;
        this.sendStatus = sendStatus;
        this.isMe = isMe;
    }

    // 提供 isMe 的 getter/setter
    public boolean isMe() {
        return isMe;
    }

    public void setMe(boolean me) {
        isMe = me;
    }

    public Long getTempId() { return tempId; }
    public Long getReceiverId() { return receiverId; }
    public String getContent() { return content; }
    public long getTimestamp() { return timestamp; }
    public int getSendStatus() { return sendStatus; }
    public void setSendStatus(int sendStatus) { this.sendStatus = sendStatus; }

    public void setTempId(Long tempId) {
        this.tempId = tempId;
    }

    public void setReceiverId(Long receiverId) {
        this.receiverId = receiverId;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }
}