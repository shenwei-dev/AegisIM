package com.family.chat.repository;

import com.family.chat.api.FriendApi;
import com.family.chat.api.RetrofitClient;
import com.family.chat.common.ApiResponse;
import com.family.chat.model.FriendDetailVO;
import com.family.chat.model.FriendVO;
import com.family.chat.model.SearchFriendVO;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import java.util.List;

public class FriendRepository {

    private final FriendApi friendApi;

    public FriendRepository() {
        friendApi = RetrofitClient.getInstance().create(FriendApi.class);
    }

    /**
     * 搜索好友
     */
    public void searchFriend(
            String keyword,
            FriendCallback<ApiResponse<List<SearchFriendVO>>> callback
    ){


        friendApi.searchFriend(keyword)
                .enqueue(
                        new Callback<ApiResponse<List<SearchFriendVO>>>() {


                            @Override
                            public void onResponse(
                                    Call<ApiResponse<List<SearchFriendVO>>> call,
                                    Response<ApiResponse<List<SearchFriendVO>>> response
                            ){


                                handleResponse(
                                        response,
                                        callback
                                );


                            }


                            @Override
                            public void onFailure(
                                    Call<ApiResponse<List<SearchFriendVO>>> call,
                                    Throwable t
                            ){

                                callback.onFailure(
                                        "网络异常"
                                );

                            }

                        });


    }



    /**
     * 添加好友
     */
    public void addFriend(
            Long account,
            FriendCallback<ApiResponse<Void>> callback
    ){


        friendApi.addFriend(account)
                .enqueue(
                        new Callback<ApiResponse<Void>>() {


                            @Override
                            public void onResponse(
                                    Call<ApiResponse<Void>> call,
                                    Response<ApiResponse<Void>> response
                            ){

                                handleResponse(
                                        response,
                                        callback
                                );

                            }


                            @Override
                            public void onFailure(
                                    Call<ApiResponse<Void>> call,
                                    Throwable t
                            ){

                                callback.onFailure(
                                        "网络异常"
                                );

                            }

                        });


    }



    /**
     * 删除好友
     */
    public void deleteFriend(
            Long friendId,
            FriendCallback<ApiResponse<Void>> callback
    ){
        friendApi.deleteFriend(friendId)
                .enqueue(
                        new Callback<ApiResponse<Void>>() {
                            @Override
                            public void onResponse(Call<ApiResponse<Void>> call, Response<ApiResponse<Void>> response){
                                handleResponse(response, callback);
                            }
                            @Override
                            public void onFailure(Call<ApiResponse<Void>> call, Throwable t){
                                callback.onFailure("网络异常");
                            }
                        });
    }



    /**
     * 查询好友列表
     */
    public void getFriendList(
            FriendCallback<ApiResponse<List<FriendVO>>> callback
    ){
        friendApi.getFriendList()
                .enqueue(
                        new Callback<ApiResponse<List<FriendVO>>>() {

                            // 收到HTTP响应时
                            @Override
                            public void onResponse(
                                    Call<ApiResponse<List<FriendVO>>> call,
                                    Response<ApiResponse<List<FriendVO>>> response
                            ){
                                handleResponse(response, callback);
                            }

                            // 未收到HTTP响应时
                            @Override
                            public void onFailure(
                                    Call<ApiResponse<List<FriendVO>>> call,
                                    Throwable t
                            ){
                                callback.onFailure("网络异常");

                            }
                        });
    }


    public void getFriendDetail(Long friendId, FriendCallback<ApiResponse<FriendDetailVO>> callback) {
        friendApi.getFriendDetail(friendId)
                .enqueue(
                        new Callback<ApiResponse<FriendDetailVO>>() {
                            @Override
                            public void onResponse(Call<ApiResponse<FriendDetailVO>> call, Response<ApiResponse<FriendDetailVO>> response){
                                handleResponse(response, callback);
                            }
                            @Override
                            public void onFailure(Call<ApiResponse<FriendDetailVO>> call, Throwable t){
                                callback.onFailure("网络异常");
                            }
                        });
    }


    /**
     * 修改好友备注
     */
    public void updateFriendRemark(
            Long friendAccount,
            String remark,
            FriendCallback<ApiResponse<Void>> callback
    ){


        friendApi.updateFriendRemark(
                        friendAccount,
                        remark
                )
                .enqueue(
                        new Callback<ApiResponse<Void>>() {


                            @Override
                            public void onResponse(
                                    Call<ApiResponse<Void>> call,
                                    Response<ApiResponse<Void>> response
                            ){

                                handleResponse(
                                        response,
                                        callback
                                );

                            }



                            @Override
                            public void onFailure(
                                    Call<ApiResponse<Void>> call,
                                    Throwable t
                            ){

                                callback.onFailure(
                                        "网络异常"
                                );

                            }

                        });


    }


    /** 统一处理响应 */
    private <T> void handleResponse(Response<ApiResponse<T>> response, FriendCallback<ApiResponse<T>> callback){
        // 如果HTTP请求状态码为200-299
        if(response.isSuccessful() && response.body()!=null){
            ApiResponse<T> result = response.body();
            // 如果业务状态码为1000(表示请求正常)
            if(result.getCode()==1000){
                callback.onSuccess(result);
            }else{
                callback.onFailure(result.getMessage());
            }
        }else{
            callback.onFailure("服务器异常");
        }
    }

    public interface FriendCallback<T>{

        void onSuccess(T response);

        void onFailure(String error);
    }
}