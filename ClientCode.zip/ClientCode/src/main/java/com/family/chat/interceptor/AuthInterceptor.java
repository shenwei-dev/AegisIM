package com.family.chat.interceptor;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.family.chat.network.WebSocketManager; // 确保导入您的 WebSocketManager 所在的包
import com.family.chat.ui.auth.LoginActivity;   // 确保导入您的 LoginActivity 所在的包
import com.family.chat.util.TokenManager;

import java.io.IOException;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

public class AuthInterceptor implements Interceptor {

    private final Context context;

    // 👈 【新增】：声明一个 Handler 用于在网络线程中切回 Android 主线程更新 UI
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    public AuthInterceptor(Context context) {
        this.context = context.getApplicationContext();
    }

    @NonNull
    @Override
    public Response intercept(Chain chain) throws IOException {
        // 获取原始的请求对象
        Request originalRequest = chain.request();

        // 获取请求路径
        String path = originalRequest.url().encodedPath();

        // 从本地取出保存的 token
        String token = TokenManager.getAccessToken(context);

        Response response;

        // ------------------ 1. 出站拦截：自动注入 Authorization 头部 ------------------
        if (TextUtils.isEmpty(token) || path.equals("/api/auth/login") || path.equals("/api/auth/register")) {
            // 如果 token 为空, 或者是登录/注册请求，直接放行发送原始请求
            response = chain.proceed(originalRequest);
        } else {
            // 防御性细节：安全剥离可能已经存在的 "Bearer " 前缀，防止重复叠加
            String cleanToken = token.startsWith("Bearer ") ? token.substring(7) : token;

            // 格式: "Authorization": Bearer xxxxxx...
            Request authorizedRequest = originalRequest.newBuilder()
                    .header("Authorization", "Bearer " + cleanToken)
                    .build();

            // 发送带有 Token 的认证请求
            response = chain.proceed(authorizedRequest);
        }

        // ------------------ 2. 👈【新加入：入站拦截：强制 401 安全退登】 ------------------
        if (response.code() == 401) {
            // 使用 Handler 切回 Android 主线程，安全执行 UI 弹窗和 Activity 销毁跳转
            mainHandler.post(() -> {
                Toast.makeText(context, "您的登录状态已失效，请重新登录", Toast.LENGTH_SHORT).show();

                // A. 物理切断手机端当前的 WebSocket 长连接（释放心跳与重连）
                WebSocketManager.getInstance().disconnect();

                // B. 清除本地缓存的 Token
                TokenManager.clearAccessToken(context);

                // C. 清除本地保存的用户 Session（如 userId、昵称等）
                SharedPreferences sp = context.getSharedPreferences("user_session", Context.MODE_PRIVATE);
                sp.edit().clear().apply();

                // D. 彻底销毁、清空手机当前的 Activity 内存栈，强制回到登录页
                Intent intent = new Intent(context, LoginActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                context.startActivity(intent);
            });
        }

        // 返回响应给上层业务
        return response;
    }
}