package com.family.chat.ui;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.family.chat.R;
import com.google.android.material.imageview.ShapeableImageView;

public class ProfileDetailActivity extends AppCompatActivity {

    private LinearLayout btnBackContainer;

    private ConstraintLayout layoutChangeAvatar;
    private ConstraintLayout layoutChangeName;

    private ShapeableImageView ivDetailAvatar;
    private TextView tvDetailName;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_detail);

        initView();
        //initData();
        initListener();
    }

    @Override
    protected void onResume() {
        super.onResume();
        initData(); // 在这里重新加载本地最新的名字并渲染
    }

    private void initView() {
        btnBackContainer = findViewById(R.id.btn_back_container);

        layoutChangeAvatar = findViewById(R.id.layout_change_avatar);
        layoutChangeName = findViewById(R.id.layout_change_name);

        ivDetailAvatar = findViewById(R.id.iv_detail_avatar);
        tvDetailName = findViewById(R.id.tv_detail_name);
    }

    private void initData() {
        // 从本地缓存加载我自己的昵称
        SharedPreferences sp = getSharedPreferences("user_session", Context.MODE_PRIVATE);
        String myNickname = sp.getString("my_nickname", "未设置昵称");

        tvDetailName.setText(myNickname);

        // 提示：此处可以使用 Glide 加载我的大头像预览
        // Glide.with(this).load(myAvatarUrl).into(ivDetailAvatar);
    }

    private void initListener() {
        // 返回键点击
        btnBackContainer.setOnClickListener(v -> finish());

        // 修改头像行点击事件
        layoutChangeAvatar.setOnClickListener(v -> {
            Toast.makeText(this, "修改头像功能研发中...", Toast.LENGTH_SHORT).show();
            // TODO: 未来可在此处调用系统相册选择器更换头像并上传服务器
        });

        // 修改名字行点击事件
        layoutChangeName.setOnClickListener(v -> {
            // 直接跳转到我们写好的更改名字页面 (ChangeNameActivity)
            Intent intent = new Intent(ProfileDetailActivity.this, ChangeNameActivity.class);
            startActivity(intent);
        });
    }
}